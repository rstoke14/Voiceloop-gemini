# English Answer Teller v1.1 — Persistent Answer Memory

Android voice assistant for Maharashtra State Board SSC Class 10 English exam practice. The user reads passages and questions aloud; no textbook PDF is required.

## Main behaviour

- Keeps the complete generated answer as a sentence queue, with the current sentence index and passage saved to local app state.
- Reads one numbered sentence or distinct web-diagram answer item, then listens again.
- `next sentence` / `next` advances; `repeat` repeats the current sentence; `sentence two`, `repeat sentence two`, or `two` replays an answer item.
- Keeps the answer queue during silence, recognition failures, short/incomplete speech, and passage updates.
- Requires an explicit `next question` handover before accepting another ordinary question while an answer is active. The previous answer is not replaced until a complete new answer has been received. `next question is ...` can include the new question in one utterance.
- Recognizer silence hints are 3500 ms for possibly-complete silence and 4000 ms for complete silence. Device speech services may interpret these as hints rather than hard guarantees.
- `next paragraph is ...` replaces the active passage; `next paragraph` alone asks for the new paragraph to be read next. `continue passage ...` or `append passage ...` appends an explicitly marked continuation.
- The AI answers seen/unseen passage questions, web diagrams, own-words questions, comprehension, language study/grammar, literature, and board-style writing tasks.

## Build

This source project is intended for the repository's GitHub Actions build workflow. Upload the contents as the root-level `voice-loop-source.zip` expected by the workflow, then check Actions and install the APK artifact only after a successful build.

## Setup and privacy

Enter your own Gemini API key in the app. The key is used for the current app session and is not saved by the app. Recognized passages and questions are sent to Google Gemini to generate answers. The answer queue and active passage are stored locally using Android SharedPreferences so the service can restore them if Android recreates it. This app cannot guarantee perfect exam marks; verify answers against your teacher or official marking scheme.

## Voice configuration

Uses English (India) (`en-IN`) speech recognition and chooses the best compatible installed English text-to-speech voice available on the device. Pause between thoughts for around two to three seconds if needed; the recognizer is given 3.5–4-second silence hints, although the installed recognition provider can override them.
