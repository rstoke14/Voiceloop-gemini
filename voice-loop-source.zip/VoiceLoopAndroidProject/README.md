# Geography Answer Teller v1.0 — Marathi Sentence Mode

Standalone Android voice assistant for Maharashtra State Board SSC Class 10 Geography exam practice. It uses Marathi speech recognition and Marathi text-to-speech. It is a separate app from the English, Marathi, and Mathematics builds.

## What it does

- Speaks answers in clear Marathi one sentence or one distinct answer item at a time.
- After speaking sentence one, it waits for a voice command. Say “पुढील वाक्य”/“पुढे” to continue, “पुन्हा”/“परत सांगा” to repeat the current line, or “वाक्य क्रमांक तीन”/“तिसरे वाक्य”/“तीन” to replay a specific saved line at any time.
- Keeps all answer lines and the current index in SharedPreferences. Silence, recognition retries, and repeat requests do not clear the answer.
- Keeps a read-aloud passage or question-paper extract active until the user says “पुढचा परिच्छेद”, “नवीन उतारा”, etc. and reads the replacement.
- Accepts an optional Geography textbook PDF. When a Geography question is asked, the selected PDF is uploaded through Gemini Files API once and reused for questions while the stored file remains available. The PDF is attached only if the question is not clearly about another subject.
- Without a PDF, the user can still ask Geography questions. The selected passage/question-paper text takes priority for passage-based tasks.
- Supports reasons, distinctions, short notes, web diagrams, flow charts, tables, figures, statistics, map work, field visits, and standard SSC Geography topics including India–Brazil comparative study.
- Waits for about 3.5–4 seconds of silence as a speech-recognition hint. Actual timing depends on the installed Android speech service.

## Build on GitHub Actions

The archive has the top-level folder `VoiceLoopAndroidProject/`, as expected by the existing workflow. Upload this ZIP to the repository root with the exact filename `voice-loop-source.zip`, then run the repository's existing Actions workflow. Install the APK artifact only after the build succeeds.

## Setup / privacy

Enter your own Gemini API key. The app does not save the API key. Recognized speech and selected PDF contents are sent to Google Gemini to answer questions. Google Gemini Files API files are generally retained for 48 hours. Remove the selected PDF in the app UI if you no longer want it attached to future Geography questions. PDF upload requires internet access and a model that supports PDF/file inputs.

## Marathi voice

The app requests `mr-IN` speech recognition and selects the best compatible installed Marathi text-to-speech voice. It will not intentionally substitute a Hindi or English voice. Quality depends on the voices installed on the phone; Android Settings can be opened to install Marathi voice data.

## Honest limitation

The source was checked for ZIP integrity and static invariants, but the final APK must be compiled and tested through GitHub Actions. No AI can guarantee 100% marks; verify answers against the textbook and official marking scheme.
