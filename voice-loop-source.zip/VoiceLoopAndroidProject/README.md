# Science Answer Teller v1.0 — Exam Answer Lock

An Android voice assistant for Maharashtra State Board SSC Class 10 Science and Technology (Part 1 and Part 2). It uses English (India) speech recognition and text-to-speech. It answers exam-style questions and dictates one answer sentence or one separate answer-sheet step at a time.

## What it does

- Answers the actual question instead of merely identifying whether it is Physics, Chemistry or Biology.
- Writes in clear, simple Indian English suitable for a Maharashtra SSC student. It aims for direct, marks-appropriate exam answers.
- Covers Physics, Chemistry, Biology, environmental and other relevant Science and Technology textbook topics.
- For definitions, explain-why questions, differences, short notes, experiments, diagrams, chemical equations and numerical problems, it uses the answer-sheet structure appropriate to the question.
- For numericals, it gives Given, To Find, Formula/Law, Substitution, calculation steps and a final answer with units.
- For textbook questions, it follows textbook terminology and the expected level. It does not invent page numbers, examples, observations or diagram details.

## Strict locked-answer system

- A new Science question is sent for solving only when there is no unfinished answer.
- The complete answer is split into individually spoken lines/sentences. The app locks the active question from the first sentence until the final sentence has finished speaking.
- While locked, another question or any unrelated speech cannot replace, interrupt, switch the answering mode, or queue a new question. It is rejected with a reminder to continue or replay the current answer.
- `next` / `next sentence` continues from the next line.
- `repeat` replays the current line.
- `previous` / `previous sentence` replays the preceding line without changing the progress pointer.
- **Number-only replay:** say just `1`, `2`, `3`, `4`, etc. (or `one`, `two`, `three`, `four`) to replay that numbered sentence. You do not need to say “sentence number one”. `repeat 3` and `number 3` are also accepted. A replay never moves the next-sentence position.
- The lock releases automatically only after the final answer sentence has finished. Then the next complete question can be asked directly.
- The current sentence queue and progress are saved locally so an unfinished answer can resume after a service restart.

## Optional textbook PDF

Select one Science and Technology Part 1 or Part 2 textbook PDF before starting. If selected, it is uploaded to Gemini Files and included with questions so the model can inspect relevant definitions, chapter explanations, figures, experiments, equations, formulae and worked examples. The app refreshes its cached remote upload after about 42 hours. Google automatically deletes Files API uploads after 48 hours. The app accepts PDFs up to 45 MB and waits for processing to finish. If no PDF is selected, it answers using standard Class 10 science knowledge. Only one PDF can be selected at a time; change the selected file to switch between Part 1 and Part 2.

The assistant should mention a chapter, page, activity or example only when it can verify that detail in the uploaded PDF. It must not claim to use a textbook method it did not find.

## Build with the existing GitHub Actions workflow

Upload this archive's project contents as the root-level `voice-loop-source.zip` file expected by the workflow. Run the APK build workflow in GitHub Actions. Download and install the APK artifact only after the workflow succeeds.

## Setup and privacy

Enter your own Gemini API key. The app uses it for the current session and does not save it. Spoken questions and the selected textbook PDF are sent to Google Gemini. The selected PDF URI and answer-sentence queue are stored locally; the API key is not. Choose a PDF only if you are comfortable sending it to Google for processing.

## Voice

Speech recognition requests English (India), and Android Text-to-speech is asked to use an English (India) voice. Voice availability and quality depend on the speech engine installed on the device. Check textbook facts, diagrams, equations and final calculations before copying an answer into an exam. AI cannot guarantee marks.
