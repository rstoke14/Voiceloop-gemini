# Math Notebook Guide v1.0

Android voice assistant for Maharashtra State Board SSC Class 10 mathematics. No textbook PDF is needed: speak a full math problem and the assistant gives a board-style, worked solution as numbered notebook lines.

## Notebook-first solution style

- Tells the student what to write and where: Given, To find, formula, substitution, each algebraic transformation, and the final answer with units when needed.
- Dictates maths symbols explicitly, including open bracket / close bracket, exponents, fractions, roots, negative signs and equals signs, so a spoken equation can be copied into a notebook.
- Covers school algebra, quadratic equations, simultaneous equations, arithmetic progressions, statistics, probability, coordinate geometry, trigonometry, geometry, mensuration, graphs and word problems.
- Gives each distinct notebook instruction or equation its own spoken line. Does not split an equation into separate TTS fragments.
- Checks arithmetic and transformations where possible, but cannot guarantee a perfect score or replace the official marking scheme.

## Voice controls

- `next line`, `next step`, or `next`: continue to the next stored solution line.
- `repeat`: replay the current line.
- `line three`, `step three`, `repeat line three`, or just `three`: replay a particular stored line.
- `next question`: prepare for a new problem. `next question is ...` can include the problem in the same utterance.
- If a recognized question is clearly incomplete, the assistant asks for the missing part and preserves the previous saved solution.
- Speech recognition is given 3.5–4 second silence hints so the user can pause briefly while speaking; device speech services may interpret these as hints rather than guarantees.

## Build

This source project is intended for the repository's GitHub Actions workflow. Upload this ZIP as the root-level `voice-loop-source.zip` expected by that workflow, then check Actions and install the APK artifact only after a successful build.

## Setup and privacy

Enter your own Gemini API key in the app. The key is used for the current session and is not saved by the app. Spoken math problems are sent to Google Gemini for solving. The saved solution lines and current line position are kept locally using Android SharedPreferences so the service can restore them if Android recreates it. Avoid speaking private information. No AI can guarantee 100% marks; check the final working against your teacher and official marking scheme.

## Voice

Uses English (India) (`en-IN`) speech recognition and the best compatible installed English TTS voice available on the phone. Select an English (India) voice in Android Text-to-speech settings for clearer math dictation.
