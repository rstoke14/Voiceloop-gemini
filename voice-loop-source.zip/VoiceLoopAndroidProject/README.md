# Geometry Answer Teller v1.1 — Locked Answer Mode

An Android voice assistant for Maharashtra State Board SSC Class 10 Geometry. It uses English (India) speech recognition and Text-to-speech, and speaks one complete answer sentence or one answer-sheet writing step at a time.

## What it does

- Solves the spoken Geometry problem instead of merely identifying its subject.
- Guides the student through what to write on the answer sheet: Given, To Find, theorem/formula, substitutions, proof statements with reasons, construction steps, calculations, and the final conclusion when relevant.
- Handles proof questions, numerical problems, theorem applications, constructions, triangle similarity, Pythagoras theorem, circle theorems, tangents, coordinate geometry, and related Class 10 Geometry topics.
- If an optional Geometry textbook PDF is selected, the app sends it to Gemini with the problem and asks Gemini to follow the relevant textbook theorem, worked example, and method where appropriate. When no PDF is selected, it uses standard valid Geometry methods.
- Each answer sentence or separate writing step is spoken individually and remains saved for replay.
- The app locks onto one problem from the first spoken answer sentence until the final sentence has finished. A new question cannot replace an unfinished answer.
- After the final sentence finishes, the lock automatically releases and the next Geometry problem can be spoken directly.

## Voice controls

- `next sentence`, `next`, or `continue`: speak the next sentence / solution step.
- `repeat` or `repeat current sentence`: replay the current sentence / step.
- `previous sentence` or `repeat previous`: replay the sentence before the current one without changing the next-step position.
- `sentence three` or `repeat sentence three`: replay a numbered sentence without changing progress.
- While the answer is locked, any different question is rejected with a reminder; it is not queued or substituted. Finish the active answer, then ask the new question again.
- The lock is released automatically only after the final answer sentence finishes speaking.

## Optional Geometry textbook PDF

Select one PDF in the app before starting a session. The PDF is uploaded to the Google Gemini Files service the first time a problem is answered and reused for later questions while the remote file remains available (the local cache is refreshed after about 42 hours). The app accepts PDFs up to 45 MB and waits for Google to finish processing the upload before using it. Google documents a 50 MB PDF limit and says Files API uploads are automatically deleted after 48 hours; the app refreshes its cached upload after about 42 hours. Choose the book only if you are comfortable sending it to Google for processing. If no PDF is selected, the app still answers using standard methods.

The assistant should mention a chapter, page or example only when it can verify that detail in the uploaded PDF. It must not invent textbook references. The actual question's givens and diagram labels take priority over any unrelated example in the book.

## Build with this repository's GitHub Actions workflow

Upload this archive's project contents as the root-level `voice-loop-source.zip` file expected by the workflow. Run the existing APK build workflow in GitHub Actions. Install the APK artifact only after the workflow completes successfully.

## Setup and privacy

Enter your own Gemini API key. The app uses it for the current session and does not save it. Spoken Geometry questions and the selected textbook PDF are sent to Google Gemini to generate answers. The selected PDF URI and the sentence queue are stored locally; the API key is not. Do not include private information in spoken questions or in the PDF.

## Voice

The app uses `en-IN` speech recognition and requests an English (India) Text-to-speech voice. The actual voice quality depends on the speech engine installed on the Android device. The app can guide answer-sheet writing, but the student should check theorem use, proof reasons, and final calculations against the teacher's method and official marking scheme.
