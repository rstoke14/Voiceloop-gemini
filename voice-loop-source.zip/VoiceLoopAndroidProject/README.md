# Science Answer Teller v1.1 — Bluetooth microphone and answer routing fix

Android source project for Maharashtra SSC Class 10 Science and Technology exam answering.

## v1.1 changes
- Requests Android's communication-audio route for connected Bluetooth headsets (BLE headset first, then classic Bluetooth SCO). Android selects the matching headset microphone when the communication output device is selected.
- Sets Text-to-Speech audio usage to voice communication so spoken answers use the headset route as well.
- Watches audio-device connect/disconnect events and rechecks routing.
- Shows the recognized transcript and active microphone route in the ongoing notification.
- Reports speech-recognizer timeout/no-match errors rather than silently restarting.
- Preserves the existing question lock, optional Science textbook PDF, and sentence replay/navigation system.

## Build
Open this project in Android Studio or use the repository's existing Gradle APK workflow. Application ID: `com.example.scienceanswerteller`. Version code: `2`. Version name: `1.1-bluetooth-audio-route`.

## Bluetooth usage
Pair and connect the earbuds before starting the session. Confirm Android shows them connected for calls/audio, not only media. In the ongoing notification, verify that it says the Bluetooth headset route was selected. The notification then displays a short recognized transcript when speech is detected. If it repeatedly reports no clear speech, move the phone closer or test with the phone microphone to distinguish headset routing from speech-recognition/network issues.

Note: Bluetooth microphone pickup is dependent on the headset firmware, noise reduction, radio conditions, and the speaking environment. This app can request the headset communication route, but cannot increase the physical microphone's sensitivity.
