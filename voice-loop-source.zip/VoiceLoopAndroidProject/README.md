# Marathi Answer Teller v1

Android voice assistant for Maharashtra State Board SSC Class 10 Marathi Kumarbharati (प्रथम भाषा).

## Features
- Default Gemini API model: `gemini-3.5-flash-lite` (verify your Google AI Studio API key has access to it).
- Select the Marathi Kumarbharati textbook PDF. The file is uploaded to Google's Gemini Files API once per session and attached to each answer request.
- Marathi is the sole spoken answer language. The app asks for answers aligned to the Maharashtra SSC exam pattern.
- Active-chapter locking: announce a chapter/poem first; the selected title is tracked across questions. The AI is instructed to search within the active chapter until the user announces a new chapter or explicitly switches to grammar/उपयोजित लेखन.
- Question-type instructions for आकृतिबंध/जाळे, घटनाक्रम, one-line answers, कारणे, स्वमत, poetry meaning and काव्यसौंदर्य, रसग्रहण, स्थूलवाचन, grammar, letters, ads, news, stories and essays.
- Marathi Android text-to-speech with a fallback voice if the device has no Marathi voice; one word at a time with a 4-second pause.
- Retries temporary HTTP 429/500/502/503/504 failures up to three times with 2/4/8-second backoff. Retries cannot prevent service outages or quota limits.
- Six-hour foreground session and a Stop action in the persistent notification.

## Build
Uses Android Gradle Plugin 8.7.3, Java 17, Android SDK 35. Run `gradle assembleDebug` in an Android build environment.

## Privacy and limitations
- No API key is bundled. Enter your own key for the session; the app clears the input after launch and does not intentionally save it.
- The selected textbook PDF is transmitted to Google Gemini; only select a PDF you are allowed to upload.
- Speech recognition and TTS quality depend on Android's installed speech services and Marathi language data. Screen-off recognition is not guaranteed on every Android phone.
- The source ZIP was not compiled in this environment, so let the GitHub Actions workflow build it and check the build result before installing.


## Marathi voice and pronunciation

This build hard-locks speech recognition and speech output to Marathi (India), locale `mr-IN`. It will not silently substitute a Hindi or English voice. It selects the highest-quality available Marathi (India) voice from the installed Android TTS engine. Clear pronunciation depends on the voice engine and Marathi voice data installed on the device; a 100% perfect accent cannot be guaranteed by app code alone. Open Android Text-to-speech settings from the app and install Marathi voice data when offered.
