# English Answer Teller v1.0

Android source project for a Maharashtra SSC Class 10 English voice exam assistant. No textbook PDF is required. The user reads the paper passage aloud; the app asks Gemini to store the spoken transcript for follow-up comprehension questions.

## Key behavior
- Speech recognition is configured for English (India), `en-IN`.
- Answers focus on SSC English seen/unseen passage work, web diagrams and boxes, “write in your own words”, comprehension, grammar/language study, poetry/textual questions, and writing skills.
- The question-paper passage is the primary source for questions that refer to it. The app stores, appends, or clears passage text according to AI metadata.
- The AI answer is divided into sentence/answer-item lines. The app speaks one numbered sentence per TTS utterance and then listens again.
- Say `next sentence` (or `next`) to continue. Say `repeat` to replay the current sentence. Say `sentence two`, `repeat sentence two`, or a bare number such as `two` to replay that numbered sentence.
- No 4-second delay is inserted between words.
- Uses Gemini API with the default model ID `gemini-3.5-flash-lite`; the user supplies their own API key.
- The API key is not stored by the app, and the selected spoken passage/questions are sent to Google Gemini for answering.

## Build
Open the `VoiceLoopAndroidProject` folder in Android Studio or use a compatible GitHub Actions workflow to run `gradle assembleDebug`. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Limitations
Speech-to-text accuracy depends on the device/service and environment. TTS voice availability depends on installed Android voice data. The app aims for exam-ready answers but cannot guarantee a perfect score; verify answers against the official marking scheme.
