# Sanskrit Answer Teller (VoiceLoop 2.0)

Android app for voice-based Maharashtra SSC Class 10 Sanskrit PYQ practice.

## Features
- Default Gemini API model: `gemini-3.5-flash-lite`.
- Optional Sanskrit textbook PDF picker. The selected PDF is uploaded once to Gemini Files API for the session, then attached to each answer request as a reference. The PDF is sent to Google; choose only a textbook you are allowed to upload.
- Explicit answer-language priority: Sanskrit is the default for Sanskrit lesson questions and grammar, even if the question is spoken in Marathi/Hindi/English. If the speaker explicitly says मातृभाषया / मातृभाषायाम् or asks for Marathi, the answer is in Marathi. The explicit output-language request always wins.
- Requests a language marker per answer so the app can select Sanskrit, Marathi, Hindi, or English Android TTS when installed. Sanskrit/Marathi speech falls back to Hindi if the device has no matching voice.
- Slower TTS default (`0.72`) and 4-second pause after each spoken word.
- Retries temporary HTTP 429/500/502/503/504 failures up to three times with 2/4/8-second backoff. API outages and free-tier quotas can still occur.
- Six-hour foreground session with Stop action in the persistent notification.

## Build
This project uses Android Gradle Plugin 8.7.3, Gradle 8.9, Java 17, and Android SDK 35. Run `gradle assembleDebug`.

## Notes
- The app does not bundle an API key. Enter your own key for the session; it is not saved by the app. Never share the key.
- Android speech recognition and TTS quality depend on the installed speech-service engine and language packs. Install/download Hindi and Marathi voices in Android Text-to-speech settings; Sanskrit TTS may not be available on a given phone.
- Lock-screen microphone recognition is not guaranteed by Android on every device. Test with the screen on before a long session.
