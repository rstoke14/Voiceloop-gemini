plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.voiceloop"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.englishanswerteller"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0-sentence-mode"
    }
}
