plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.voiceloop"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.marathianswerteller"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.2-build-fix"
    }
}
