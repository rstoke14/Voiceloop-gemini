plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.voiceloop"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.geographyanswertellermr"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "1.4-auto-question-fix"
    }
}
