plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.voiceloop"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.marathianswerteller"
        minSdk = 26
        targetSdk = 34
        versionCode = 4
        versionName = "1.3-seen-passage"
    }
}
