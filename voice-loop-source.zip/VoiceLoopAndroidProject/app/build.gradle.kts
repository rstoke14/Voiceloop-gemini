plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.voiceloop"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.geometryanswerteller"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "1.1-locked-answer-mode"
    }
}
