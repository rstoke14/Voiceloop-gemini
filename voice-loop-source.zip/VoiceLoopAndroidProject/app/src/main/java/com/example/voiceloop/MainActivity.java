package com.example.voiceloop;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 501;
    private static final int REQUEST_TEXTBOOK_PDF = 502;
    private EditText apiKeyEdit;
    private EditText modelEdit;
    private TextView pdfStatus;
    private Uri textbookPdfUri;
    private String pendingApiKey;
    private String pendingModel;
    private String pendingLanguage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Marathi Answer Teller v1.2");
        title.setTextSize(26);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        TextView description = new TextView(this);
        description.setText("महाराष्ट्र राज्य मंडळ SSC इयत्ता १० वी मराठी कुमारभारतीच्या सरावासाठी. तुमच्या मराठी पाठ्यपुस्तकाची PDF निवडा, सत्र सुरू करा आणि एका वेळी एक प्रश्न मराठीत विचारा. उत्तरं पाठ, कविता, स्वमत, व्याकरण आणि उपयोजित लेखनासाठी बोर्ड-पद्धतीने तयार केली जातील. आधी पाठाचे नाव सांगा; त्यानंतरचे प्रश्न त्याच पाठावर आधारित सोडवले जातील. उत्तर फक्त मराठी आवाजात ऐकवले जाईल. स्पष्ट उच्चारांसाठी फोनमध्ये मराठी Text-to-speech voice data उपलब्ध असणे आवश्यक आहे.");
        description.setTextSize(16);
        description.setPadding(0, 0, 0, dp(18));
        root.addView(description);

        addLabel(root, "Gemini API key (Google AI Studio)");
        apiKeyEdit = new EditText(this);
        apiKeyEdit.setSingleLine(true);
        apiKeyEdit.setHint("Paste Gemini API key");
        apiKeyEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(apiKeyEdit, matchWrap());

        TextView keyWarning = new TextView(this);
        keyWarning.setText("API key फक्त या सत्रासाठी वापरली जाते आणि अ‍ॅपमध्ये सेव्ह केली जात नाही. ती कोणाशीही शेअर करू नका. निवडलेली पाठ्यपुस्तक PDF उत्तरांसाठी Google Gemini कडे अपलोड केली जाते. मोफत वापराच्या मर्यादा किंवा सर्व्हरमधील अडचणींमुळे काही वेळा सेवा उपलब्ध नसेल.");
        keyWarning.setTextSize(13);
        keyWarning.setPadding(0, dp(4), 0, dp(12));
        root.addView(keyWarning);

        addLabel(root, "मराठी कुमारभारती पाठ्यपुस्तक PDF (आवश्यकतेनुसार निवडा)");
        Button choosePdf = new Button(this);
        choosePdf.setText("मराठी पाठ्यपुस्तकाची PDF निवडा");
        root.addView(choosePdf, matchWrap());
        choosePdf.setOnClickListener(v -> chooseTextbookPdf());

        pdfStatus = new TextView(this);
        pdfStatus.setText("अजून कोणतीही PDF निवडलेली नाही.");
        pdfStatus.setTextSize(14);
        pdfStatus.setPadding(0, dp(4), 0, dp(4));
        root.addView(pdfStatus);

        Button clearPdf = new Button(this);
        clearPdf.setText("निवडलेली PDF काढून टाका");
        root.addView(clearPdf, matchWrap());
        clearPdf.setOnClickListener(v -> {
            textbookPdfUri = null;
            pdfStatus.setText("अजून कोणतीही PDF निवडलेली नाही.");
            Toast.makeText(this, "PDF निवड काढून टाकली.", Toast.LENGTH_SHORT).show();
        });

        addLabel(root, "AI मॉडेल");
        modelEdit = new EditText(this);
        modelEdit.setSingleLine(true);
        modelEdit.setText("gemini-3.5-flash-lite");
        modelEdit.setHint("gemini-3.5-flash-lite");
        modelEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(modelEdit, matchWrap());

        TextView voiceInfo = new TextView(this);
        voiceInfo.setText("हा अ‍ॅप मराठीसाठीच आहे. तो हिंदी किंवा इंग्रजी आवाजावर बदलणार नाही. नैसर्गिक, स्पष्ट मराठी उच्चारांसाठी Android Text-to-speech सेटिंग्ज उघडा, Speech Services by Google निवडा आणि मराठी voice data उपलब्ध असल्यास डाउनलोड करा. आवाजाची गुणवत्ता फोनवरील उपलब्ध मराठी voice वर अवलंबून असते; कोणताही TTS आवाज १००% परिपूर्ण असल्याची हमी देता येत नाही.");
        voiceInfo.setTextSize(14);
        voiceInfo.setPadding(0, dp(12), 0, dp(12));
        root.addView(voiceInfo);

        Button ttsSettings = new Button(this);
        ttsSettings.setText("मराठी आवाज सेटिंग्ज उघडा");
        root.addView(ttsSettings, matchWrap());
        ttsSettings.setOnClickListener(v -> {
            try {
                startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
            } catch (Exception ex) {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                catch (Exception ignored) {
                    Toast.makeText(this, "फोनच्या Settings मध्ये Text-to-speech शोधा.", Toast.LENGTH_LONG).show();
                }
            }
        });

        TextView limitations = new TextView(this);
        limitations.setText("HTTP 503 किंवा 429 सारख्या तात्पुरत्या त्रुटींनंतर अ‍ॅप पुन्हा प्रयत्न करते; मात्र सर्व्हर बंद असणे किंवा मोफत वापराची मर्यादा टाळता येत नाही. दीर्घ सत्रापूर्वी स्क्रीन सुरू ठेवून तपासा आणि फोन चार्ज ठेवा. स्क्रीन लॉक असताना Android बोलणे ओळखणे थांबवू शकतो.");
        limitations.setTextSize(14);
        limitations.setPadding(0, 0, 0, dp(16));
        root.addView(limitations);

        Button start = new Button(this);
        start.setText("६ तासांचे सत्र सुरू करा");
        root.addView(start, matchWrap());
        start.setOnClickListener(v -> prepareStart());

        Button stop = new Button(this);
        stop.setText("सत्र थांबवा");
        root.addView(stop, matchWrap());
        stop.setOnClickListener(v -> {
            Intent intent = new Intent(this, VoiceLoopService.class);
            intent.setAction(VoiceLoopService.ACTION_STOP);
            startService(intent);
            Toast.makeText(this, "सत्र थांबवण्याची विनंती केली.", Toast.LENGTH_SHORT).show();
        });

        TextView foot = new TextView(this);
        foot.setText("पाठ किंवा कवितेचे प्रश्न विचारण्यापूर्वी त्याचे नाव सांगा. प्रश्नपत्रिकेतील पठित/दृश्य उताऱ्याचे प्रश्न असतील, तर आधी संपूर्ण उतारा एकदा वाचा; अ‍ॅप तो पुढील प्रश्नांसाठी लक्षात ठेवेल. मग प्रश्न क्रमांकासह विचारा. API key मोठ्याने बोलू नका.");
        foot.setTextSize(13);
        foot.setPadding(0, dp(14), 0, dp(8));
        root.addView(foot);
    }

    private void chooseTextbookPdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        startActivityForResult(intent, REQUEST_TEXTBOOK_PDF);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_TEXTBOOK_PDF || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Some document providers grant only a temporary read permission; keep the URI for this app session.
        }
        textbookPdfUri = uri;
        String displayName = "Selected PDF";
        try (android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameColumn = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (nameColumn >= 0) displayName = cursor.getString(nameColumn);
            }
        } catch (Exception ignored) { }
        pdfStatus.setText("निवडलेली PDF: " + displayName + "\nपहिल्या प्रश्नावेळी ती Google Gemini कडे अपलोड केली जाईल.");
        Toast.makeText(this, "पाठ्यपुस्तकाची PDF निवडली.", Toast.LENGTH_SHORT).show();
    }

    private void prepareStart() {
        String key = apiKeyEdit.getText().toString().trim();
        String model = modelEdit.getText().toString().trim();
        if (key.isEmpty()) {
            apiKeyEdit.setError("Enter your API key");
            apiKeyEdit.requestFocus();
            return;
        }
        if (model.isEmpty()) {
            modelEdit.setError("Enter an API model ID");
            return;
        }
        pendingApiKey = key;
        pendingModel = model;
        pendingLanguage = "mr-IN";

        ArrayList<String> missing = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
        } else {
            startSessionNow();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_PERMISSIONS) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "मायक्रोफोनची परवानगी आवश्यक आहे.", Toast.LENGTH_LONG).show();
            return;
        }
        startSessionNow();
    }

    private void startSessionNow() {
        if (pendingApiKey == null || pendingApiKey.isEmpty()) return;
        Intent intent = new Intent(this, VoiceLoopService.class);
        intent.setAction(VoiceLoopService.ACTION_START);
        intent.putExtra(VoiceLoopService.EXTRA_API_KEY, pendingApiKey);
        intent.putExtra(VoiceLoopService.EXTRA_MODEL, pendingModel);
        intent.putExtra(VoiceLoopService.EXTRA_LANGUAGE, pendingLanguage);
        if (textbookPdfUri != null) intent.putExtra(VoiceLoopService.EXTRA_TEXTBOOK_URI, textbookPdfUri.toString());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        apiKeyEdit.setText("");
        pendingApiKey = null;
        Toast.makeText(this, "मराठी Answer Teller सुरू होत आहे. सूचना दिसेपर्यंत अ‍ॅप उघडे ठेवा.", Toast.LENGTH_LONG).show();
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(15);
        label.setPadding(0, dp(8), 0, dp(4));
        root.addView(label);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
