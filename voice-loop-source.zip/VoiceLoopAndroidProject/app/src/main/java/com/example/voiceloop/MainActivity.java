package com.example.voiceloop;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 501;
    private static final int REQUEST_PICK_PDF = 502;
    private static final String APP_PREFS = "geography_answer_teller_ui";
    private static final String PDF_KEY = "selected_geography_pdf_uri";
    private EditText apiKeyEdit;
    private EditText modelEdit;
    private TextView pdfStatus;
    private String pendingApiKey;
    private String pendingModel;
    private String selectedPdfUri = "";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        selectedPdfUri = getSharedPreferences(APP_PREFS, MODE_PRIVATE).getString(PDF_KEY, "");
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("भूगोल उत्तरसहाय्यक v1.0");
        title.setTextSize(25);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        TextView description = new TextView(this);
        description.setText("महाराष्ट्र राज्य मंडळ इयत्ता दहावीच्या भूगोलाच्या प्रश्नपत्रिकांचा सराव करण्यासाठी. प्रश्न, उतारा, तक्ता किंवा आकडेवारी आवाजात वाचा. पुस्तकाची PDF देणे ऐच्छिक आहे. PDF दिल्यास भूगोलाच्या प्रश्नांसाठी अॅप ती वापरेल. उत्तर प्रत्येक वेळी एक मराठी वाक्य किंवा एक मुद्दा म्हणून सांगितले जाईल.");
        description.setTextSize(16);
        description.setPadding(0, 0, 0, dp(18));
        root.addView(description);

        addLabel(root, "Gemini API key (Google AI Studio)");
        apiKeyEdit = new EditText(this);
        apiKeyEdit.setSingleLine(true);
        apiKeyEdit.setHint("तुमची Gemini API key येथे टाका");
        apiKeyEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(apiKeyEdit, matchWrap());

        TextView warning = new TextView(this);
        warning.setText("API key फक्त या सत्रासाठी वापरली जाते; अॅप ती साठवत नाही. तुमची key कोणाशीही शेअर करू नका. बोललेले प्रश्न आणि निवडलेली PDF उत्तरे तयार करण्यासाठी Google Gemini कडे पाठवली जातात. PDF Google कडे अपलोड झाल्यावर ती Files API मध्ये साधारण ४८ तास उपलब्ध राहू शकते.");
        warning.setTextSize(13);
        warning.setPadding(0, dp(6), 0, dp(12));
        root.addView(warning);

        addLabel(root, "Gemini मॉडेल");
        modelEdit = new EditText(this);
        modelEdit.setSingleLine(true);
        modelEdit.setText("gemini-3.5-flash-lite");
        modelEdit.setHint("gemini-3.5-flash-lite");
        modelEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(modelEdit, matchWrap());

        Button pickPdf = new Button(this);
        pickPdf.setText("भूगोलाच्या पुस्तकाची PDF निवडा (ऐच्छिक)");
        root.addView(pickPdf, matchWrap());
        pickPdf.setOnClickListener(v -> choosePdf());

        Button removePdf = new Button(this);
        removePdf.setText("निवडलेली PDF काढून टाका");
        root.addView(removePdf, matchWrap());
        removePdf.setOnClickListener(v -> {
            selectedPdfUri = "";
            getSharedPreferences(APP_PREFS, MODE_PRIVATE).edit().putString(PDF_KEY, "").apply();
            refreshPdfStatus();
            Toast.makeText(this, "PDF काढून टाकली.", Toast.LENGTH_SHORT).show();
        });
        pdfStatus = new TextView(this);
        pdfStatus.setTextSize(14);
        pdfStatus.setPadding(0, dp(8), 0, dp(10));
        root.addView(pdfStatus);
        refreshPdfStatus();

        TextView controls = new TextView(this);
        controls.setText("वाक्यागणिक वापर:\nपुढील वाक्य किंवा पुढे म्हणा — पुढील वाक्य ऐका.\nपुन्हा किंवा परत सांगा म्हणा — चालू वाक्य ऐका.\nवाक्य क्रमांक तीन, तिसरे वाक्य किंवा फक्त तीन म्हणा — तिसरे वाक्य ऐका; तुम्ही सध्या तिसऱ्या वाक्यावर असलात तरी पहिले वाक्य पुन्हा ऐकू शकता.\nपुढील प्रश्न म्हणा आणि मग प्रश्न विचारा. एका वाक्यात 'पुढील प्रश्न आहे...' असे म्हणून पूर्ण प्रश्नही सांगू शकता.\nनवीन परिच्छेद आहे असे म्हणून नवीन उतारा वाचा; त्यावरचे पुढील प्रश्न त्याच उताऱ्यावर सोडवले जातील.\nविचार करताना थोडा विराम घेऊ शकता; आवाज थांबल्यावर ओळख-सेवा साधारण ३.५ ते ४ सेकंद थांबण्याचा प्रयत्न करते.");
        controls.setTextSize(15);
        controls.setPadding(0, dp(14), 0, dp(10));
        root.addView(controls);

        Button ttsSettings = new Button(this);
        ttsSettings.setText("मराठी आवाज सेटिंग्ज उघडा");
        root.addView(ttsSettings, matchWrap());
        ttsSettings.setOnClickListener(v -> {
            try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
            catch (Exception ex) {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                catch (Exception ignored) { Toast.makeText(this, "Android सेटिंग्जमध्ये Text-to-speech उघडा आणि मराठी आवाज निवडा.", Toast.LENGTH_LONG).show(); }
            }
        });

        TextView caution = new TextView(this);
        caution.setText("स्पष्ट उच्चारांसाठी Android Text-to-speech सेटिंग्जमध्ये Marathi (India) आवाज निवडा आणि मराठी voice data उपलब्ध असल्यास डाउनलोड करा. अॅप हिंदी किंवा इंग्रजी आवाजावर आपोआप बदलणार नाही. मात्र उपलब्ध आवाजानुसार उच्चारांची गुणवत्ता बदलू शकते. उत्तर शिक्षकांच्या पद्धतीशी आणि अधिकृत गुणदान योजनेशी तपासा; कोणतेही AI शंभर टक्के गुणांची हमी देऊ शकत नाही.");
        caution.setTextSize(14);
        caution.setPadding(0, dp(8), 0, dp(16));
        root.addView(caution);

        Button start = new Button(this);
        start.setText("६ तासांचे सत्र सुरू करा");
        root.addView(start, matchWrap());
        start.setOnClickListener(v -> prepareStart());

        Button stop = new Button(this);
        stop.setText("सत्र थांबवा");
        root.addView(stop, matchWrap());
        stop.setOnClickListener(v -> {
            Intent intent = new Intent(this, VoiceLoopService.class);
            intent.setAction(VoiceLoopService.ACTION_STOP);
            startService(intent);
            Toast.makeText(this, "सत्र थांबवण्याची विनंती केली.", Toast.LENGTH_SHORT).show();
        });

        TextView foot = new TextView(this);
        foot.setText("पद्धत: आधी उतारा, तक्ता किंवा प्रश्नातील माहिती पूर्ण वाचा. नंतर प्रश्न विचारा. जाळे/आकृतिबंधासाठी किती चौकटी रिकाम्या आहेत आणि कोणते मुद्दे आधी भरले आहेत ते सांगा. उत्तरातील प्रत्येक वाक्य स्वतंत्रपणे ऐकून वहीत लिहा.");
        foot.setTextSize(13);
        foot.setPadding(0, dp(14), 0, dp(8));
        root.addView(foot);
    }

    private void choosePdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, REQUEST_PICK_PDF); }
        catch (Exception e) { Toast.makeText(this, "PDF निवडण्यासाठी Files अॅप उघडता आले नाही.", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PICK_PDF || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (SecurityException ignored) { }
        selectedPdfUri = uri.toString();
        getSharedPreferences(APP_PREFS, MODE_PRIVATE).edit().putString(PDF_KEY, selectedPdfUri).apply();
        refreshPdfStatus();
        Toast.makeText(this, "भूगोलाची PDF निवडली.", Toast.LENGTH_SHORT).show();
    }

    private void refreshPdfStatus() {
        if (pdfStatus == null) return;
        if (selectedPdfUri == null || selectedPdfUri.trim().isEmpty()) {
            pdfStatus.setText("सध्याची स्थिती: कोणतीही PDF निवडलेली नाही. अॅप तरीही भूगोलाचे प्रश्न सोडवू शकते.");
        } else {
            pdfStatus.setText("सध्याची स्थिती: भूगोलाची PDF निवडलेली आहे. PDF मधील माहिती भूगोलाच्या प्रश्नांसाठी वापरली जाईल.");
        }
    }

    private void prepareStart() {
        String key = apiKeyEdit.getText().toString().trim();
        String model = modelEdit.getText().toString().trim();
        if (key.isEmpty()) { apiKeyEdit.setError("API key टाका"); apiKeyEdit.requestFocus(); return; }
        if (model.isEmpty()) { modelEdit.setError("Gemini मॉडेलचे नाव टाका"); return; }
        pendingApiKey = key;
        pendingModel = model;
        ArrayList<String> missing = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
        else startSessionNow();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_PERMISSIONS) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "मायक्रोफोनची परवानगी आवश्यक आहे.", Toast.LENGTH_LONG).show();
            return;
        }
        startSessionNow();
    }

    private void startSessionNow() {
        if (pendingApiKey == null || pendingApiKey.isEmpty()) return;
        Intent intent = new Intent(this, VoiceLoopService.class);
        intent.setAction(VoiceLoopService.ACTION_START);
        intent.putExtra(VoiceLoopService.EXTRA_API_KEY, pendingApiKey);
        intent.putExtra(VoiceLoopService.EXTRA_MODEL, pendingModel);
        intent.putExtra(VoiceLoopService.EXTRA_LANGUAGE, "mr-IN");
        intent.putExtra(VoiceLoopService.EXTRA_TEXTBOOK_URI, selectedPdfUri == null ? "" : selectedPdfUri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
        apiKeyEdit.setText("");
        pendingApiKey = null;
        pendingModel = null;
        Toast.makeText(this, "भूगोल उत्तरसहाय्यक सुरू होत आहे. सूचना दिसेपर्यंत अॅप उघडे ठेवा.", Toast.LENGTH_LONG).show();
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(15);
        label.setPadding(0, dp(8), 0, dp(4));
        root.addView(label);
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
