package com.example.voiceloop;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 501;
    private static final int REQUEST_TEXTBOOK_PDF = 502;
    private EditText apiKeyEdit;
    private EditText modelEdit;
    private Spinner languageSpinner;
    private TextView pdfStatus;
    private Uri textbookPdfUri;
    private String pendingApiKey;
    private String pendingModel;
    private String pendingLanguage;

    private final String[] languageNames = {
            "Hindi / हिन्दी (recommended for spoken questions)",
            "Marathi / मराठी",
            "English (India)"
    };
    private final String[] languageCodes = {"hi-IN", "mr-IN", "en-IN"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Sanskrit Answer Teller");
        title.setTextSize(26);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        TextView description = new TextView(this);
        description.setText("For Maharashtra SSC Class 10 Sanskrit PYQs. Select your textbook PDF, tap Start, and speak one question at a time. Answers follow the question's required language: Sanskrit for Sanskrit tasks and Marathi for माध्यमभाषया explanations. The app speaks slowly, one word at a time, with a 4-second pause, then listens for the next question. Stop from the notification at any time.");
        description.setTextSize(16);
        description.setPadding(0, 0, 0, dp(18));
        root.addView(description);

        addLabel(root, "Gemini API key (Google AI Studio)");
        apiKeyEdit = new EditText(this);
        apiKeyEdit.setSingleLine(true);
        apiKeyEdit.setHint("Paste Gemini API key");
        apiKeyEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(apiKeyEdit, matchWrap());

        TextView keyWarning = new TextView(this);
        keyWarning.setText("The key is used for this session and is not saved by this app. Never share it. Free-tier quotas and availability vary; changing models cannot guarantee that HTTP 503 will never occur. Your selected textbook PDF is uploaded to Google Gemini so it can be used as a reference.");
        keyWarning.setTextSize(13);
        keyWarning.setPadding(0, dp(4), 0, dp(12));
        root.addView(keyWarning);

        addLabel(root, "Sanskrit textbook PDF (recommended)");
        Button choosePdf = new Button(this);
        choosePdf.setText("CHOOSE TEXTBOOK PDF");
        root.addView(choosePdf, matchWrap());
        choosePdf.setOnClickListener(v -> chooseTextbookPdf());

        pdfStatus = new TextView(this);
        pdfStatus.setText("No textbook selected. You can still ask general Sanskrit questions.");
        pdfStatus.setTextSize(14);
        pdfStatus.setPadding(0, dp(4), 0, dp(4));
        root.addView(pdfStatus);

        Button clearPdf = new Button(this);
        clearPdf.setText("CLEAR SELECTED PDF");
        root.addView(clearPdf, matchWrap());
        clearPdf.setOnClickListener(v -> {
            textbookPdfUri = null;
            pdfStatus.setText("No textbook selected. You can still ask general Sanskrit questions.");
            Toast.makeText(this, "Textbook cleared.", Toast.LENGTH_SHORT).show();
        });

        addLabel(root, "AI model (default selected for you)");
        modelEdit = new EditText(this);
        modelEdit.setSingleLine(true);
        modelEdit.setText("gemini-3.5-flash-lite");
        modelEdit.setHint("gemini-3.5-flash-lite");
        modelEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(modelEdit, matchWrap());

        addLabel(root, "Language you speak your questions in");
        languageSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, languageNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(adapter);
        root.addView(languageSpinner, matchWrap());

        TextView voiceInfo = new TextView(this);
        voiceInfo.setText("Voice clarity: the app asks Gemini to label the answer language, then selects the matching Android text-to-speech voice. Sanskrit speech falls back to Hindi if your phone has no Sanskrit voice. For clearer pronunciation, install/update Speech Services by Google and download Hindi and Marathi voice data in Android Text-to-speech settings. Voice quality depends on the voices available on your phone.");
        voiceInfo.setTextSize(14);
        voiceInfo.setPadding(0, dp(12), 0, dp(12));
        root.addView(voiceInfo);

        TextView limitations = new TextView(this);
        limitations.setText("The app retries temporary Gemini errors such as HTTP 503 and 429 with increasing delays. It cannot eliminate server outages or free-tier limits. For a long session, test first with the screen on and keep the phone charged. Android may interrupt speech recognition while the screen is locked.");
        limitations.setTextSize(14);
        limitations.setPadding(0, 0, 0, dp(16));
        root.addView(limitations);

        Button start = new Button(this);
        start.setText("START 6-HOUR SESSION");
        root.addView(start, matchWrap());
        start.setOnClickListener(v -> prepareStart());

        Button stop = new Button(this);
        stop.setText("STOP SESSION");
        root.addView(stop, matchWrap());
        stop.setOnClickListener(v -> {
            Intent intent = new Intent(this, VoiceLoopService.class);
            intent.setAction(VoiceLoopService.ACTION_STOP);
            startService(intent);
            Toast.makeText(this, "Stop requested.", Toast.LENGTH_SHORT).show();
        });

        TextView foot = new TextView(this);
        foot.setText("Best results: speak one question clearly, mention the question number, and say whether the answer must be in Sanskrit or Marathi if the paper's requirement is not obvious. Do not speak your API key aloud.");
        foot.setTextSize(13);
        foot.setPadding(0, dp(14), 0, dp(8));
        root.addView(foot);
    }

    private void chooseTextbookPdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        startActivityForResult(intent, REQUEST_TEXTBOOK_PDF);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_TEXTBOOK_PDF || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(uri, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Some document providers grant only a temporary read permission; keep the URI for this app session.
        }
        textbookPdfUri = uri;
        String displayName = "Selected PDF";
        try (android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int nameColumn = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (nameColumn >= 0) displayName = cursor.getString(nameColumn);
            }
        } catch (Exception ignored) { }
        pdfStatus.setText("Selected textbook: " + displayName + "\nIt will be uploaded to Gemini at the first question in this session.");
        Toast.makeText(this, "Textbook selected.", Toast.LENGTH_SHORT).show();
    }

    private void prepareStart() {
        String key = apiKeyEdit.getText().toString().trim();
        String model = modelEdit.getText().toString().trim();
        if (key.isEmpty()) {
            apiKeyEdit.setError("Enter your API key");
            apiKeyEdit.requestFocus();
            return;
        }
        if (model.isEmpty()) {
            modelEdit.setError("Enter an API model ID");
            return;
        }
        pendingApiKey = key;
        pendingModel = model;
        pendingLanguage = languageCodes[languageSpinner.getSelectedItemPosition()];

        ArrayList<String> missing = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
        } else {
            startSessionNow();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_PERMISSIONS) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission is required.", Toast.LENGTH_LONG).show();
            return;
        }
        startSessionNow();
    }

    private void startSessionNow() {
        if (pendingApiKey == null || pendingApiKey.isEmpty()) return;
        Intent intent = new Intent(this, VoiceLoopService.class);
        intent.setAction(VoiceLoopService.ACTION_START);
        intent.putExtra(VoiceLoopService.EXTRA_API_KEY, pendingApiKey);
        intent.putExtra(VoiceLoopService.EXTRA_MODEL, pendingModel);
        intent.putExtra(VoiceLoopService.EXTRA_LANGUAGE, pendingLanguage);
        if (textbookPdfUri != null) intent.putExtra(VoiceLoopService.EXTRA_TEXTBOOK_URI, textbookPdfUri.toString());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        apiKeyEdit.setText("");
        pendingApiKey = null;
        Toast.makeText(this, "Sanskrit Answer Teller starting. Keep the app open until its notification appears.", Toast.LENGTH_LONG).show();
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(15);
        label.setPadding(0, dp(8), 0, dp(4));
        root.addView(label);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
