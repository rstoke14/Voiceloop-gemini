package com.example.voiceloop;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 501;
    private EditText apiKeyEdit;
    private EditText modelEdit;
    private String pendingApiKey;
    private String pendingModel;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("English Answer Teller v1.0");
        title.setTextSize(26);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        TextView description = new TextView(this);
        description.setText("For Maharashtra State Board SSC Class 10 English exam practice. Read the question or passage aloud; no textbook PDF is needed. The AI is configured for seen and unseen passages, web diagrams, answers in your own words, comprehension, grammar and writing skills. It speaks one complete answer sentence, then stops and listens. Say ‘next sentence’ to continue, ‘repeat’ to hear the current sentence again, or say ‘sentence three’ to replay a numbered sentence.");
        description.setTextSize(16);
        description.setPadding(0, 0, 0, dp(18));
        root.addView(description);

        addLabel(root, "Gemini API key (Google AI Studio)");
        apiKeyEdit = new EditText(this);
        apiKeyEdit.setSingleLine(true);
        apiKeyEdit.setHint("Paste your Gemini API key");
        apiKeyEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(apiKeyEdit, matchWrap());

        TextView warning = new TextView(this);
        warning.setText("The API key is used for this session and is not saved by this app. Never share your key. Spoken questions and passages are sent to Google Gemini to generate answers. Free-tier limits and temporary server failures may still occur.");
        warning.setTextSize(13);
        warning.setPadding(0, dp(6), 0, dp(12));
        root.addView(warning);

        addLabel(root, "Gemini model");
        modelEdit = new EditText(this);
        modelEdit.setSingleLine(true);
        modelEdit.setText("gemini-3.5-flash-lite");
        modelEdit.setHint("gemini-3.5-flash-lite");
        modelEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(modelEdit, matchWrap());

        TextView controls = new TextView(this);
        controls.setText("Voice commands after each sentence:\nSay ‘next sentence’ or ‘next’ to continue.\nSay ‘repeat’ to replay the current sentence.\nSay ‘sentence two’, ‘repeat sentence two’, or just ‘two’ to replay that sentence.\nAfter a passage is saved, ask its questions normally. Say ‘new passage’ to clear it before reading another passage.");
        controls.setTextSize(15);
        controls.setPadding(0, dp(14), 0, dp(10));
        root.addView(controls);

        Button ttsSettings = new Button(this);
        ttsSettings.setText("Open English voice settings");
        root.addView(ttsSettings, matchWrap());
        ttsSettings.setOnClickListener(v -> {
            try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
            catch (Exception ex) {
                try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
                catch (Exception ignored) { Toast.makeText(this, "Find Text-to-speech in Android Settings.", Toast.LENGTH_LONG).show(); }
            }
        });

        TextView caution = new TextView(this);
        caution.setText("For clearest speech, select an installed English (India) voice in Android Text-to-speech settings. The app reads one sentence in a single natural TTS utterance—there is no four-second pause between words. It then listens for your next-sentence or repeat command. Check answers against your teacher or marking scheme; no AI can guarantee 100% marks.");
        caution.setTextSize(14);
        caution.setPadding(0, dp(8), 0, dp(16));
        root.addView(caution);

        Button start = new Button(this);
        start.setText("Start 6-hour session");
        root.addView(start, matchWrap());
        start.setOnClickListener(v -> prepareStart());

        Button stop = new Button(this);
        stop.setText("Stop session");
        root.addView(stop, matchWrap());
        stop.setOnClickListener(v -> {
            Intent intent = new Intent(this, VoiceLoopService.class);
            intent.setAction(VoiceLoopService.ACTION_STOP);
            startService(intent);
            Toast.makeText(this, "Stop requested.", Toast.LENGTH_SHORT).show();
        });

        TextView foot = new TextView(this);
        foot.setText("Suggested workflow: read the complete paper passage aloud, wait for ‘Passage saved’, then ask each question. For a web diagram, say the central prompt and identify any boxes already filled. Answer points will be spoken one at a time.");
        foot.setTextSize(13);
        foot.setPadding(0, dp(14), 0, dp(8));
        root.addView(foot);
    }

    private void prepareStart() {
        String key = apiKeyEdit.getText().toString().trim();
        String model = modelEdit.getText().toString().trim();
        if (key.isEmpty()) { apiKeyEdit.setError("Enter your API key"); apiKeyEdit.requestFocus(); return; }
        if (model.isEmpty()) { modelEdit.setError("Enter a Gemini model ID"); return; }
        pendingApiKey = key;
        pendingModel = model;
        ArrayList<String> missing = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
        else startSessionNow();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_PERMISSIONS) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission is required.", Toast.LENGTH_LONG).show();
            return;
        }
        startSessionNow();
    }

    private void startSessionNow() {
        if (pendingApiKey == null || pendingApiKey.isEmpty()) return;
        Intent intent = new Intent(this, VoiceLoopService.class);
        intent.setAction(VoiceLoopService.ACTION_START);
        intent.putExtra(VoiceLoopService.EXTRA_API_KEY, pendingApiKey);
        intent.putExtra(VoiceLoopService.EXTRA_MODEL, pendingModel);
        intent.putExtra(VoiceLoopService.EXTRA_LANGUAGE, "en-IN");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
        apiKeyEdit.setText("");
        pendingApiKey = null;
        pendingModel = null;
        Toast.makeText(this, "English Answer Teller is starting. Keep the app open until the notification appears.", Toast.LENGTH_LONG).show();
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(15);
        label.setPadding(0, dp(8), 0, dp(4));
        root.addView(label);
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
