package com.example.voiceloop;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 601;
    private static final int REQUEST_PICK_PDF = 602;
    private static final String APP_PREFS = "science_answer_teller_ui";
    private static final String PDF_KEY = "selected_science_pdf_uri";

    private EditText apiKeyEdit;
    private EditText modelEdit;
    private TextView pdfStatus;
    private String pendingApiKey;
    private String pendingModel;
    private String selectedPdfUri = "";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        selectedPdfUri = getSharedPreferences(APP_PREFS, MODE_PRIVATE).getString(PDF_KEY, "");

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("Science Answer Teller v1.1 — Bluetooth Mic Fix + Exam Answer Lock");
        title.setTextSize(26);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        TextView description = new TextView(this);
        description.setText("For Maharashtra State Board SSC Class 10 Science and Technology (Part 1 and Part 2). Ask exam-style questions from Physics, Chemistry, Biology and related textbook chapters. The AI gives a student-style, marks-appropriate answer and tells you exactly what to write on the answer sheet, one sentence or answer step at a time. An optional textbook PDF can be selected so the answer follows the book’s terminology, methods, examples and diagrams where relevant.");
        description.setTextSize(16);
        description.setPadding(0, 0, 0, dp(18));
        root.addView(description);

        addLabel(root, "Gemini API key (Google AI Studio)");
        apiKeyEdit = new EditText(this);
        apiKeyEdit.setSingleLine(true);
        apiKeyEdit.setHint("Paste your Gemini API key");
        apiKeyEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(apiKeyEdit, matchWrap());

        TextView warning = new TextView(this);
        warning.setText("The API key is used only for this session and is not saved by the app. Never share your key. Spoken Science questions and, when selected, the textbook PDF are sent to Google Gemini to prepare exam answers. Google may retain an uploaded PDF in its Files service for a limited period. Choose a PDF only if you are comfortable sending it to Google.");
        warning.setTextSize(13);
        warning.setPadding(0, dp(6), 0, dp(12));
        root.addView(warning);

        addLabel(root, "Gemini model");
        modelEdit = new EditText(this);
        modelEdit.setSingleLine(true);
        modelEdit.setText("gemini-3.5-flash-lite");
        modelEdit.setHint("gemini-3.5-flash-lite");
        modelEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        root.addView(modelEdit, matchWrap());

        Button pickPdf = new Button(this);
        pickPdf.setText("Choose Science & Technology textbook PDF (optional)");
        root.addView(pickPdf, matchWrap());
        pickPdf.setOnClickListener(v -> choosePdf());

        Button removePdf = new Button(this);
        removePdf.setText("Remove selected Science textbook PDF");
        root.addView(removePdf, matchWrap());
        removePdf.setOnClickListener(v -> removePdf());

        pdfStatus = new TextView(this);
        pdfStatus.setTextSize(14);
        pdfStatus.setPadding(0, dp(8), 0, dp(10));
        root.addView(pdfStatus);
        refreshPdfStatus();

        TextView controls = new TextView(this);
        controls.setText("LOCKED answer mode — one answer at a time:\nThe app locks onto each Science question and keeps that exact answer active until its final sentence has finished speaking. It will not switch to a new question or change the answering mode while any answer sentence is still left.\nSay ‘next’ or ‘next sentence’ to continue. Say ‘repeat’ to hear the current sentence again. Say ‘previous’ to replay the preceding sentence without changing your place.\nTo replay ANY numbered sentence, say ONLY its number: ‘1’, ‘2’, ‘3’, ‘4’, etc. You can also say ‘one’, ‘two’, ‘three’, ‘four’, or ‘repeat 3’. You do NOT need to say ‘sentence number one’. Replaying a number never moves your place in the answer.\nWhile the answer is locked, any other words or a different question are not accepted as a new question and are not queued. The app reminds you to continue, repeat, or choose a number. Ask the new question again after the final sentence has finished.\nThe lock releases automatically only when the final answer sentence has finished speaking. Pause briefly while speaking; recognition waits about 3.5–4 seconds of silence. Bluetooth earbuds are supported: connect them before starting the session. The app tries to select the headset call-audio route for both microphone input and spoken answers. Check the active-session notification to see whether the Bluetooth microphone route was selected and whether your question was transcribed.");
        controls.setTextSize(15);
        controls.setPadding(0, dp(14), 0, dp(10));
        root.addView(controls);

        Button ttsSettings = new Button(this);
        ttsSettings.setText("Open English voice settings");
        root.addView(ttsSettings, matchWrap());
        ttsSettings.setOnClickListener(v -> openEnglishVoiceSettings());

        TextView caution = new TextView(this);
        caution.setText("For clear speech, select an English (India) voice in Android Text-to-speech settings. Connect Bluetooth earbuds before starting if you want the app to use their microphone and play answers through them. During an active answer, only sentence navigation and replay commands are accepted. A new problem is accepted only after the final answer sentence has finished speaking. Check scientific facts, equations, diagrams and calculations against your textbook and teacher’s marking guidance; AI cannot guarantee full marks.");
        caution.setTextSize(14);
        caution.setPadding(0, dp(8), 0, dp(16));
        root.addView(caution);

        Button start = new Button(this);
        start.setText("Start 6-hour session");
        root.addView(start, matchWrap());
        start.setOnClickListener(v -> prepareStart());

        Button stop = new Button(this);
        stop.setText("Stop session");
        root.addView(stop, matchWrap());
        stop.setOnClickListener(v -> {
            Intent intent = new Intent(this, VoiceLoopService.class);
            intent.setAction(VoiceLoopService.ACTION_STOP);
            startService(intent);
            Toast.makeText(this, "Stop requested.", Toast.LENGTH_SHORT).show();
        });

        TextView foot = new TextView(this);
        foot.setText("Suggested use: optionally select your Science and Technology Part 1 or Part 2 textbook PDF. Then start the session and speak one complete exam question, including all values, units, chemical formulae and diagram labels. The assistant will consult the selected book where relevant and guide you through a complete answer-sheet response one sentence at a time.");
        foot.setTextSize(13);
        foot.setPadding(0, dp(14), 0, dp(8));
        root.addView(foot);
    }

    private void choosePdf() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(intent, REQUEST_PICK_PDF); }
        catch (Exception e) { Toast.makeText(this, "Could not open the file picker.", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PICK_PDF || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (SecurityException ignored) { }
        selectedPdfUri = uri.toString();
        getSharedPreferences(APP_PREFS, MODE_PRIVATE).edit().putString(PDF_KEY, selectedPdfUri).apply();
        refreshPdfStatus();
        Toast.makeText(this, "Science textbook PDF selected.", Toast.LENGTH_SHORT).show();
    }

    private void removePdf() {
        if (selectedPdfUri != null && !selectedPdfUri.isEmpty()) {
            try { getContentResolver().releasePersistableUriPermission(Uri.parse(selectedPdfUri), Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) { }
        }
        selectedPdfUri = "";
        getSharedPreferences(APP_PREFS, MODE_PRIVATE).edit().putString(PDF_KEY, "").apply();
        refreshPdfStatus();
        Toast.makeText(this, "Textbook PDF removed.", Toast.LENGTH_SHORT).show();
    }

    private void refreshPdfStatus() {
        if (pdfStatus == null) return;
        if (selectedPdfUri == null || selectedPdfUri.trim().isEmpty()) {
            pdfStatus.setText("Current status: No textbook PDF selected. The app can still answer Science questions using standard Class 10 methods.");
        } else {
            pdfStatus.setText("Current status: A Science textbook PDF is selected. Gemini will consult it for each question and reuse its uploaded copy during this session.");
        }
    }

    private void openEnglishVoiceSettings() {
        try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
        catch (Exception ex) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            catch (Exception ignored) { Toast.makeText(this, "Find Text-to-speech output in Android Settings.", Toast.LENGTH_LONG).show(); }
        }
    }

    private void prepareStart() {
        String key = apiKeyEdit.getText().toString().trim();
        String model = modelEdit.getText().toString().trim();
        if (key.isEmpty()) { apiKeyEdit.setError("Enter your API key"); apiKeyEdit.requestFocus(); return; }
        if (model.isEmpty()) { modelEdit.setError("Enter a Gemini model ID"); return; }
        pendingApiKey = key;
        pendingModel = model;
        ArrayList<String> missing = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
        else startSessionNow();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQUEST_PERMISSIONS) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission is required.", Toast.LENGTH_LONG).show();
            return;
        }
        startSessionNow();
    }

    private void startSessionNow() {
        if (pendingApiKey == null || pendingApiKey.isEmpty()) return;
        Intent intent = new Intent(this, VoiceLoopService.class);
        intent.setAction(VoiceLoopService.ACTION_START);
        intent.putExtra(VoiceLoopService.EXTRA_API_KEY, pendingApiKey);
        intent.putExtra(VoiceLoopService.EXTRA_MODEL, pendingModel);
        intent.putExtra(VoiceLoopService.EXTRA_LANGUAGE, "en-IN");
        intent.putExtra(VoiceLoopService.EXTRA_TEXTBOOK_URI, selectedPdfUri == null ? "" : selectedPdfUri);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent);
        else startService(intent);
        apiKeyEdit.setText("");
        pendingApiKey = null;
        pendingModel = null;
        Toast.makeText(this, "Science Answer Teller is starting. Keep the app open until its notification appears.", Toast.LENGTH_LONG).show();
    }

    private void addLabel(LinearLayout root, String text) {
        TextView label = new TextView(this);
        label.setText(text);
        label.setTextSize(15);
        label.setPadding(0, dp(8), 0, dp(4));
        root.addView(label);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
