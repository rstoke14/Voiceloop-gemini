package com.example.voiceloop;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.media.AudioAttributes;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.content.Intent;
import android.content.ContentResolver;
import android.net.Uri;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VoiceLoopService extends Service {
    public static final String ACTION_START = "com.example.voiceloop.START";
    public static final String ACTION_STOP = "com.example.voiceloop.STOP";
    public static final String EXTRA_API_KEY = "api_key";
    public static final String EXTRA_MODEL = "model";
    public static final String EXTRA_LANGUAGE = "language";
    public static final String EXTRA_TEXTBOOK_URI = "science_textbook_pdf_uri";

    private static final String TAG = "ScienceAnswerTeller";
    private static final String CHANNEL_ID = "science_answer_teller_session";
    private static final String STATE_PREFS = "science_answer_teller_saved_session";
    private static final int NOTIFICATION_ID = 2462;
    private static final long SESSION_LIMIT_MS = 6L * 60L * 60L * 1000L;
    private static final int MAX_RETRIES = 3;

    private static final String INSTRUCTIONS =
            "You are Science Answer Teller, a careful Maharashtra State Board SSC Class 10 Science and Technology (Part 1 and Part 2) exam answerer. Your job is to ANSWER the student's actual spoken exam question and guide the student exactly what to write on the answer sheet. Do not classify the subject, merely restate the question, say that it was saved, or ask for a new question instead of answering. Treat each complete spoken input as an exam question unless it is clearly a sentence-control command.\n" +
            "LANGUAGE AND STYLE: Answer in clear, simple Indian English suitable for a Maharashtra SSC Class 10 student in a semi-English classroom. Use the terminology and depth expected in the Maharashtra State Board textbook. Write as a student would write in an exam: direct, accurate, concise, and complete for the marks. If marks are given, match the answer length. If no marks are given, provide the essential scoring points without unnecessary background. No greeting, filler, Markdown tables, code fences, LaTeX, decorative formatting, or meta-commentary. Every complete answer sentence or separate answer-sheet step must be on its own line.\n" +
            "OPTIONAL TEXTBOOK PDF: A Science and Technology Part 1 or Part 2 textbook PDF may be attached. When present, search it for the exact question or the closest matching exercise, worked example, chapter section, definition, diagram, activity, formula, chemical equation, scientific term, and numerical method. Identify the solution method that the uploaded book actually uses and follow its terminology, sequence, and level when it fits the question. Inspect relevant pages and figures rather than relying only on the chapter title. Use only information actually visible or reliably extracted from the PDF. Mention a chapter, page, activity, figure, or example only when you can verify it in the uploaded book; never invent references. If the PDF is unrelated, incomplete, unreadable, or does not contain the method, answer with correct standard Class 10 science knowledge without pretending the book supports it. With no PDF, answer normally; never ask the student to upload one just to receive an answer.\n" +
            "EXAM ANSWER FORMAT: Match the command and question type. For define/state/name/list questions, give the exact definition, fact, name, or points requested. For explain/describe questions, give a short logical sequence with the scientific principle and outcome. For 'give scientific reason' questions, state the reason directly and connect it to the relevant law, property, process, or concept. For differences, present matched pairs as clearly numbered comparison points, with both sides identified on each line so the student can reproduce a two-column table. For short notes, give a suitable heading and the main textbook points. For diagrams, tell the student to draw a neat labelled diagram and list the essential labels in order; do not claim to draw it. For experiments, state aim, apparatus/materials only if asked, procedure, observation, and conclusion in the order appropriate to the marks. For activity-based questions, give the expected observation and inference.\n" +
            "NUMERICALS: For every numerical, guide the student in answer-sheet order: Given; To Find; relevant formula or law; substitution with values and units; calculation in clear steps; and final answer with correct SI unit. Preserve powers, signs, prefixes, decimal places, and units. Convert units before substitution when needed. Check dimensional consistency and arithmetic. Do not omit intermediate working that earns marks. If a required value is genuinely missing, ask one precise clarification rather than inventing it.\n" +
            "PHYSICS: Handle Class 10 textbook concepts and numericals such as gravitation, periodic motion, heat, refraction, lenses, electric current, electric circuits, magnetic effects of electric current, energy and related applications where present in the syllabus. State laws accurately, define symbols, use correct units, show formula substitutions, and explain ray diagrams or circuit diagrams through clearly ordered drawing and labelling instructions. Never assume a diagram is to scale.\n" +
            "CHEMISTRY: Handle periodic classification, chemical reactions and equations, acids/bases/salts, metals/non-metals, carbon compounds, metallurgy, and other relevant textbook topics. Write correct chemical formulae and balance equations by conserving each element's atoms and, where applicable, charge. Include reaction conditions, catalysts, heat/light, gas or precipitate observations, and state symbols only when relevant and known. Do not fabricate products or reaction conditions. Distinguish physical and chemical properties precisely.\n" +
            "BIOLOGY AND ENVIRONMENT: Handle life processes, heredity and evolution, classification, environmental management, social health, disaster management, green energy, space-related textbook topics, and related Science and Technology content. Explain processes in correct biological order, use textbook terms, distinguish structures and functions, and describe diagrams with accurate labels. Avoid replacing an exact textbook term with a vague synonym.\n" +
            "MULTI-PART QUESTIONS AND MARKS: Answer every visible or spoken sub-question in order. Keep each point on its own line. Use numbering when the question asks for multiple points. Do not skip a subpart or add unrelated material. Do not give only a hint or merely explain how the student could find an answer; provide the actual answer and the writing steps.\n" +
            "ACCURACY AND UNCERTAINTY: Preserve every value, unit, chemical symbol, subscript, superscript, sign, and named term. Do not invent observations, diagram labels, values, or assumptions. If speech recognition makes a minor error but the intended scientific meaning is clear, correct it silently. If two interpretations would materially change the answer, ask one short clarification. Do not state a guessed fact confidently.\n" +
            "QUESTION LOCK — CRITICAL: The Android app locks the complete answer after it receives the question. It will speak and retain one answer sentence at a time. While any sentence remains, the user can only continue, repeat the current sentence, replay a previous sentence, or say a sentence number. Any other spoken words, including an entirely new exam question, must NOT change the active question, replace the answer, start another subject, or be queued. The app itself enforces this lock; do not attempt to interpret non-command speech as a new question during an active answer. The lock ends automatically only after the final answer sentence has finished speaking. After that, accept the next complete exam question directly.\n" +
            "SENTENCE NUMBER REPLAY: The student may speak only a number such as '1', '2', '3', '4', or the number word 'one', 'two', 'three', 'four' to replay that answer sentence. The student does not need to say 'sentence one' or 'repeat sentence one'. Replaying any numbered sentence must not change the current progress pointer. Keep sentences short, self-contained, and suitable for dictation. Put each distinct fact, reason, equation, calculation, observation, or instruction on its own line.\n" +
            "MANDATORY MACHINE FORMAT: Output exactly these two metadata lines first: [[VOICE=en-IN]] and [[PASSAGE=UNCHANGED]]. After them, output only the complete solved exam answer in English, with each sentence or separate answer-sheet step on its own line. Do not output subject classification, internal reasoning, or commentary about these instructions.\n";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService networkExecutor;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private AudioManager audioManager;
    private AudioDeviceCallback audioDeviceCallback;
    private int originalAudioMode = AudioManager.MODE_NORMAL;
    private boolean originalAudioModeSaved = false;
    private boolean communicationRouteRequested = false;
    private long communicationRouteRequestedAt = 0L;
    private int communicationDeviceId = -1;
    private String communicationDeviceName = "";
    private String lastPartialTranscript = "";
    private PowerManager.WakeLock wakeLock;
    private String apiKey;
    private String model = "gemini-3.5-flash-lite";
    private String recognitionLanguageTag = "en-IN";
    private String activePassage = "";
    private String textbookPdfUri = "";
    private String uploadedPdfUri = "";
    private String uploadedPdfSourceUri = "";
    private long uploadedPdfTimestamp = 0L;
    private ArrayList<String> answerSentences = new ArrayList<>();
    private int currentSentenceIndex = -1;
    private int questionCount = 0;
    private long answerGeneration = 0L;
    private boolean ttsReady = false;
    private boolean isProcessing = false;
    private boolean isSpeaking = false;
    private boolean stopping = false;
    private boolean started = false;
    private boolean awaitingNextParagraph = false;
    private boolean awaitingNextQuestion = false;
    private boolean answerLocked = false;
    private String lastAnsweredQuestion = "";
    private NotificationManager notificationManager;

    @Override public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        createNotificationChannel();
        networkExecutor = Executors.newSingleThreadExecutor();
        restoreSessionState();
    }

    private void persistSessionState() {
        try {
            JSONArray sentences = new JSONArray();
            if (answerSentences != null) {
                for (String sentence : answerSentences) sentences.put(sentence == null ? "" : sentence);
            }
            getSharedPreferences(STATE_PREFS, MODE_PRIVATE).edit()
                    .putString("active_passage", activePassage == null ? "" : activePassage)
                    .putString("answer_sentences", sentences.toString())
                    .putInt("current_sentence_index", currentSentenceIndex)
                    .putBoolean("awaiting_next_question", awaitingNextQuestion)
                    .putBoolean("answer_locked", answerLocked)
                    .putBoolean("awaiting_next_paragraph", awaitingNextParagraph)
                    .putString("last_answered_question", lastAnsweredQuestion == null ? "" : lastAnsweredQuestion)
                    .putString("textbook_pdf_uri", textbookPdfUri == null ? "" : textbookPdfUri)
                    .putString("uploaded_pdf_uri", uploadedPdfUri == null ? "" : uploadedPdfUri)
                    .putString("uploaded_pdf_source_uri", uploadedPdfSourceUri == null ? "" : uploadedPdfSourceUri)
                    .putLong("uploaded_pdf_timestamp", uploadedPdfTimestamp)
                    .apply();
        } catch (Exception e) {
            Log.w(TAG, "Could not persist session state", e);
        }
    }

    private void restoreSessionState() {
        try {
            SharedPreferences prefs = getSharedPreferences(STATE_PREFS, MODE_PRIVATE);
            activePassage = prefs.getString("active_passage", "");
            awaitingNextQuestion = prefs.getBoolean("awaiting_next_question", false);
            awaitingNextParagraph = prefs.getBoolean("awaiting_next_paragraph", false);
            lastAnsweredQuestion = prefs.getString("last_answered_question", "");
            textbookPdfUri = prefs.getString("textbook_pdf_uri", "");
            uploadedPdfUri = prefs.getString("uploaded_pdf_uri", "");
            uploadedPdfSourceUri = prefs.getString("uploaded_pdf_source_uri", "");
            uploadedPdfTimestamp = prefs.getLong("uploaded_pdf_timestamp", 0L);
            answerSentences = new ArrayList<>();
            String saved = prefs.getString("answer_sentences", "[]");
            JSONArray sentences = new JSONArray(saved == null ? "[]" : saved);
            for (int i = 0; i < sentences.length(); i++) {
                String sentence = sentences.optString(i, "").trim();
                if (!sentence.isEmpty()) answerSentences.add(sentence);
            }
            currentSentenceIndex = prefs.getInt("current_sentence_index", -1);
            if (answerSentences.isEmpty() || currentSentenceIndex < 0 || currentSentenceIndex >= answerSentences.size()) {
                if (answerSentences.isEmpty()) currentSentenceIndex = -1;
                else currentSentenceIndex = Math.max(0, Math.min(currentSentenceIndex, answerSentences.size() - 1));
            }
            answerLocked = prefs.getBoolean("answer_locked",
                    !answerSentences.isEmpty() && currentSentenceIndex < answerSentences.size() - 1);
            if (answerSentences.isEmpty()) answerLocked = false;
            Log.i(TAG, "Restored saved session: passageChars=" + (activePassage == null ? 0 : activePassage.length())
                    + ", answerSentences=" + answerSentences.size() + ", currentIndex=" + currentSentenceIndex);
        } catch (Exception e) {
            Log.w(TAG, "Could not restore saved session; starting with fresh state", e);
            activePassage = "";
            answerSentences = new ArrayList<>();
            currentSentenceIndex = -1;
            awaitingNextQuestion = false;
            awaitingNextParagraph = false;
            answerLocked = false;
            lastAnsweredQuestion = "";
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopLoop();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        apiKey = intent.getStringExtra(EXTRA_API_KEY);
        model = intent.getStringExtra(EXTRA_MODEL);
        recognitionLanguageTag = "en-IN";
        String incomingPdf = intent.getStringExtra(EXTRA_TEXTBOOK_URI);
        if (incomingPdf != null) {
            incomingPdf = incomingPdf.trim();
            if (!incomingPdf.equals(textbookPdfUri)) {
                textbookPdfUri = incomingPdf;
                uploadedPdfUri = "";
                uploadedPdfSourceUri = "";
                uploadedPdfTimestamp = 0L;
                persistSessionState();
            }
        }
        if (apiKey == null || apiKey.trim().isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (model == null || model.trim().isEmpty()) model = "gemini-3.5-flash-lite";
        started = true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
                startForeground(NOTIFICATION_ID, buildNotification("Starting Science Answer Teller…"), types);
            } else {
                startForeground(NOTIFICATION_ID, buildNotification("Starting Science Answer Teller…"));
            }
        } catch (SecurityException | IllegalArgumentException ex) {
            Log.e(TAG, "Could not start foreground service", ex);
            stopLoop();
            return START_NOT_STICKY;
        }
        acquireWakeLock();
        registerAudioDeviceCallback();
        rememberOriginalAudioMode();
        boolean bluetoothSelected = selectBluetoothCommunicationDevice(true);
        handler.postDelayed(this::stopLoop, SESSION_LIMIT_MS);
        initialiseTts();
        if (!bluetoothSelected) {
            updateStatus("No Bluetooth headset microphone route detected yet. Using Android's current microphone; connect the earbuds before speaking if you want to use their mic.");
        }
        return START_NOT_STICKY;
    }

    private void initialiseTts() {
        tts = new TextToSpeech(getApplicationContext(), status -> handler.post(() -> {
            if (stopping) return;
            if (status != TextToSpeech.SUCCESS || tts == null) {
                updateStatus("Text-to-speech could not start. Check Android speech settings.");
                handler.postDelayed(this::initialiseTts, 3000L);
                return;
            }
            try {
                // Route spoken answers through the active Bluetooth communication device
                // (and its matching headset output), rather than leaving TTS on A2DP/phone audio.
                tts.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build());
            } catch (Exception audioException) {
                Log.w(TAG, "Could not set voice-communication audio attributes", audioException);
            }
            tts.setSpeechRate(0.88f);
            tts.setPitch(1.0f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { handler.post(() -> handleUtteranceDone(utteranceId)); }
                @Override public void onError(String utteranceId) { handler.post(() -> handleUtteranceFinishedWithError(utteranceId)); }
                @Override public void onError(String utteranceId, int errorCode) { handler.post(() -> handleUtteranceFinishedWithError(utteranceId)); }
            });
            ttsReady = configureEnglishVoice();
            if (ttsReady) {
                if (answerLocked && hasAnswer()) {
                    updateStatus("English voice ready. Resuming the unfinished Science answer…");
                    if (communicationRouteRequested) handler.postDelayed(() -> speakCurrentSentence(answerGeneration), 900L);
                    else speakCurrentSentence(answerGeneration);
                } else {
                    updateStatus(communicationRouteRequested
                            ? "English voice ready. Bluetooth headset microphone and audio route selected; starting listening…"
                            : "English voice ready. Listening for your first question…");
                    if (communicationRouteRequested) handler.postDelayed(this::startListening, 900L);
                    else startListening();
                }
            } else {
                updateStatus("An English voice is unavailable. Install English voice data in Android Text-to-speech settings.");
            }
        }));
    }

    private boolean configureEnglishVoice() {
        if (tts == null) return false;
        Locale preferred = Locale.forLanguageTag("en-IN");
        int result;
        try { result = tts.setLanguage(preferred); }
        catch (Exception e) { Log.w(TAG, "Could not select en-IN voice", e); return false; }
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.ERROR) {
            Log.w(TAG, "English voice data unavailable. result=" + result);
            return false;
        }
        try {
            Set<Voice> voices = tts.getVoices();
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            if (voices != null) {
                for (Voice voice : voices) {
                    Locale vl = voice.getLocale();
                    if (vl == null || !"en".equalsIgnoreCase(vl.getLanguage())) continue;
                    int score = voice.getQuality() * 10;
                    if ("IN".equalsIgnoreCase(vl.getCountry())) score += 100;
                    else if ("GB".equalsIgnoreCase(vl.getCountry())) score += 10;
                    if (voice.isNetworkConnectionRequired()) score += 2;
                    if (score > bestScore) { bestScore = score; best = voice; }
                }
            }
            if (best != null && tts.setVoice(best) == TextToSpeech.ERROR) {
                Log.w(TAG, "Could not set a specific English voice; keeping en-IN language setting");
            }
        } catch (Exception e) { Log.w(TAG, "Could not choose best installed English voice", e); }
        tts.setSpeechRate(0.88f);
        tts.setPitch(1.0f);
        return true;
    }

    private void rememberOriginalAudioMode() {
        if (audioManager == null || originalAudioModeSaved) return;
        try {
            originalAudioMode = audioManager.getMode();
            originalAudioModeSaved = true;
        } catch (Exception e) {
            Log.w(TAG, "Could not read the original audio mode", e);
        }
    }

    private void registerAudioDeviceCallback() {
        if (audioManager == null || audioDeviceCallback != null) return;
        audioDeviceCallback = new AudioDeviceCallback() {
            @Override public void onAudioDevicesAdded(AudioDeviceInfo[] addedDevices) {
                handler.post(() -> {
                    boolean selected = selectBluetoothCommunicationDevice(true);
                    if (selected && ttsReady && !isProcessing && !isSpeaking) {
                        handler.postDelayed(VoiceLoopService.this::startListening, 700L);
                    }
                });
            }

            @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] removedDevices) {
                handler.post(() -> {
                    selectBluetoothCommunicationDevice(true);
                    if (ttsReady && !isProcessing && !isSpeaking) {
                        handler.postDelayed(VoiceLoopService.this::startListening, 350L);
                    }
                });
            }
        };
        try {
            audioManager.registerAudioDeviceCallback(audioDeviceCallback, handler);
        } catch (Exception e) {
            Log.w(TAG, "Could not register audio-device callback", e);
        }
    }

    /**
     * Selects the Bluetooth headset communication route. On Android 12+, Android
     * automatically selects the matching headset microphone when its communication
     * output device is selected. This is the supported route for HFP and BLE headsets.
     */
    private boolean selectBluetoothCommunicationDevice(boolean announce) {
        if (audioManager == null) return false;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                List<AudioDeviceInfo> devices = audioManager.getAvailableCommunicationDevices();
                AudioDeviceInfo target = null;
                // Prefer BLE headset audio when available; otherwise use classic Bluetooth SCO.
                for (AudioDeviceInfo device : devices) {
                    if (device.getType() == AudioDeviceInfo.TYPE_BLE_HEADSET) {
                        target = device;
                        break;
                    }
                }
                if (target == null) {
                    for (AudioDeviceInfo device : devices) {
                        if (device.getType() == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
                            target = device;
                            break;
                        }
                    }
                }
                if (target == null) {
                    if (communicationRouteRequested) {
                        try { audioManager.clearCommunicationDevice(); } catch (Exception ignored) { }
                        communicationRouteRequested = false;
                        communicationDeviceId = -1;
                        communicationDeviceName = "";
                        restoreAudioModeAfterRoute();
                    }
                    if (announce) updateStatus("No Bluetooth headset call-audio route is available. Using the phone's current microphone and audio route.");
                    Log.i(TAG, "No Bluetooth communication device available; using platform default route.");
                    return false;
                }

                rememberOriginalAudioMode();
                if (audioManager.getMode() != AudioManager.MODE_IN_COMMUNICATION) {
                    audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
                }
                AudioDeviceInfo active = audioManager.getCommunicationDevice();
                if (active != null && active.getId() == target.getId()) {
                    communicationRouteRequested = true;
                    communicationDeviceId = target.getId();
                    communicationDeviceName = String.valueOf(target.getProductName());
                    return true;
                }
                boolean accepted = audioManager.setCommunicationDevice(target);
                if (accepted) {
                    communicationRouteRequested = true;
                    communicationRouteRequestedAt = System.currentTimeMillis();
                    communicationDeviceId = target.getId();
                    communicationDeviceName = String.valueOf(target.getProductName());
                    Log.i(TAG, "Bluetooth communication route requested: " + communicationDeviceName + " type=" + target.getType());
                    if (announce) updateStatus("Bluetooth headset audio route selected: " + communicationDeviceName + ". Using its microphone and headset audio.");
                    return true;
                }
                Log.w(TAG, "Android rejected Bluetooth communication route: " + target.getProductName());
                restoreAudioModeAfterRoute();
                if (announce) updateStatus("Android could not select the Bluetooth headset microphone. Check its call-audio connection; using the current route.");
                return false;
            }

            // Compatibility path for Android 8–11. Newer Android versions use setCommunicationDevice above.
            AudioDeviceInfo[] inputs = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS);
            boolean hasBluetoothScoInput = false;
            for (AudioDeviceInfo input : inputs) {
                if (input.getType() == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) {
                    hasBluetoothScoInput = true;
                    break;
                }
            }
            if (!hasBluetoothScoInput) {
                if (announce) updateStatus("No Bluetooth headset microphone input is available. Using the phone's current microphone.");
                return false;
            }
            rememberOriginalAudioMode();
            audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
            audioManager.startBluetoothSco();
            audioManager.setBluetoothScoOn(true);
            communicationRouteRequested = true;
            communicationRouteRequestedAt = System.currentTimeMillis();
            communicationDeviceId = -1;
            communicationDeviceName = "Bluetooth headset";
            if (announce) updateStatus("Bluetooth headset microphone route requested. Waiting for audio connection…");
            return true;
        } catch (Exception e) {
            if (!communicationRouteRequested) restoreAudioModeAfterRoute();
            Log.w(TAG, "Could not select Bluetooth microphone/audio route", e);
            if (announce) updateStatus("Bluetooth audio routing could not be selected. Using the phone's current audio route.");
            return false;
        }
    }

    private String speechErrorLabel(int error) {
        switch (error) {
            case SpeechRecognizer.ERROR_AUDIO: return "audio capture failed";
            case SpeechRecognizer.ERROR_CLIENT: return "recognition client reset";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "microphone permission missing";
            case SpeechRecognizer.ERROR_NETWORK: return "speech recognition network error";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "speech recognition network timeout";
            case SpeechRecognizer.ERROR_NO_MATCH: return "no words were recognized";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "speech service busy";
            case SpeechRecognizer.ERROR_SERVER: return "speech recognition server error";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "no speech reached the recognizer";
            case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED: return "English (India) recognition not supported";
            case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE: return "English (India) recognition data unavailable";
            default: return "speech recognition error " + error;
        }
    }

    private String microphoneRouteLabel() {
        if (!communicationRouteRequested || communicationDeviceName == null || communicationDeviceName.trim().isEmpty()) {
            return "Android default microphone";
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && audioManager != null && communicationDeviceId >= 0) {
            try {
                AudioDeviceInfo active = audioManager.getCommunicationDevice();
                if (active == null || active.getId() != communicationDeviceId) {
                    return "Bluetooth headset route requested but not yet active (" + communicationDeviceName + ")";
                }
            } catch (Exception ignored) { }
        }
        return "Bluetooth headset (" + communicationDeviceName + ")";
    }

    private void restoreAudioModeAfterRoute() {
        if (audioManager == null || !originalAudioModeSaved) return;
        try {
            if (audioManager.getMode() == AudioManager.MODE_IN_COMMUNICATION) {
                audioManager.setMode(originalAudioMode);
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not restore original audio mode", e);
        }
    }

    private void releaseAudioRouting() {
        if (audioManager == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (communicationRouteRequested) audioManager.clearCommunicationDevice();
            } else if (communicationRouteRequested) {
                audioManager.setBluetoothScoOn(false);
                audioManager.stopBluetoothSco();
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not clear Bluetooth communication route", e);
        }
        communicationRouteRequested = false;
        communicationDeviceId = -1;
        communicationDeviceName = "";
        restoreAudioModeAfterRoute();
        if (audioDeviceCallback != null) {
            try { audioManager.unregisterAudioDeviceCallback(audioDeviceCallback); } catch (Exception ignored) { }
            audioDeviceCallback = null;
        }
    }

    private void startListening() {
        if (stopping || !started || isProcessing || isSpeaking) return;
        if (!ttsReady) { handler.postDelayed(this::startListening, 500L); return; }
        if (!communicationRouteRequested) selectBluetoothCommunicationDevice(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && communicationRouteRequested && communicationDeviceId >= 0) {
            AudioDeviceInfo active = null;
            try { active = audioManager == null ? null : audioManager.getCommunicationDevice(); }
            catch (Exception ignored) { }
            if ((active == null || active.getId() != communicationDeviceId)
                    && System.currentTimeMillis() - communicationRouteRequestedAt < 4000L) {
                handler.postDelayed(this::startListening, 300L);
                return;
            }
            if (active == null || active.getId() != communicationDeviceId) {
                updateStatus("Android has not confirmed the Bluetooth headset route yet. Continuing with the available microphone; check the headset's call-audio connection.");
            }
        }
        destroyRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Speech recognition unavailable. Enable an Android speech service; retrying…");
            handler.postDelayed(this::startListening, 5000L);
            return;
        }
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { updateStatus("Listening for question or sentence command…"); }
                @Override public void onBeginningOfSpeech() { updateStatus("Listening…"); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { updateStatus("Recognizing speech…"); }
                @Override public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> partials = partialResults == null ? null : partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String partial = (partials == null || partials.isEmpty()) ? "" : partials.get(0).trim();
                    if (!partial.isEmpty() && !partial.equals(lastPartialTranscript)) {
                        lastPartialTranscript = partial;
                        updateStatus("Hearing through " + microphoneRouteLabel() + ": " + abbreviate(partial, 95));
                    }
                }
                @Override public void onEvent(int eventType, Bundle params) { }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String heard = (matches == null || matches.isEmpty()) ? "" : matches.get(0).trim();
                    lastPartialTranscript = "";
                    destroyRecognizer();
                    // Empty/noisy recognition must not clear the saved Science answer.
                    if (heard.isEmpty()) {
                        updateStatus("No complete speech transcript received from " + microphoneRouteLabel() + ". Keep the earbuds connected and speak clearly; listening again…");
                        handler.postDelayed(VoiceLoopService.this::startListening, 900L);
                    } else if (handleSentenceCommand(heard)) {
                        // Only permitted navigation commands can affect an active answer.
                    } else if (answerLocked) {
                        // Do not replace the active problem while any answer sentences remain.
                        speakControlNotice("This answer is still in progress. Say next sentence to continue, repeat to hear the current sentence again, or previous sentence to replay the preceding one. Ask a different question after the final sentence has finished.");
                    } else if (handleClearlyIncompleteInput(heard)) {
                        // Keep the completed answer available and wait for a complete new problem.
                    } else {
                        Log.i(TAG, "Recognized speech from " + microphoneRouteLabel() + ": " + abbreviate(heard, 180));
                        updateStatus("Heard from " + microphoneRouteLabel() + ": " + abbreviate(heard, 100) + " — preparing the Science answer…");
                        awaitingNextQuestion = false;
                        awaitingNextParagraph = false;
                        processQuestion(heard);
                    }
                }
                @Override public void onError(int error) {
                    destroyRecognizer();
                    if (stopping || isProcessing || isSpeaking) return;
                    long delay = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1500L : 900L;
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        updateStatus("No clear speech received from " + microphoneRouteLabel() + ". Check that the earbuds are connected for calls, then speak clearly; retrying…");
                    } else {
                        updateStatus("Microphone/recognition issue: " + speechErrorLabel(error) + " via " + microphoneRouteLabel() + ". Reopening microphone…");
                        Log.w(TAG, "SpeechRecognizer error=" + speechErrorLabel(error) + " code=" + error + " route=" + microphoneRouteLabel());
                    }
                    handler.postDelayed(VoiceLoopService.this::startListening, delay);
                }
            });
            Intent speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            // Allow a 2–3 second thinking/pronunciation pause; finalize after about 3.5–4 seconds of silence.
            speechIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3500L);
            speechIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L);
            recognizer.startListening(speechIntent);
        } catch (Exception e) {
            Log.e(TAG, "Could not start speech recognition", e);
            destroyRecognizer();
            updateStatus("Could not start listening; retrying…");
            handler.postDelayed(this::startListening, 1500L);
        }
    }

    private boolean handleSentenceCommand(String raw) {
        String q = raw == null ? "" : raw.toLowerCase(Locale.ROOT).trim();
        q = q.replaceAll("[.!?,;:]+$", "").replaceAll("\\s+", " ").trim();
        if (q.isEmpty()) return false;

        boolean next = q.matches("(?:please )?(?:next|continue|go on)(?: sentence| line| point)?")
                || q.matches("(?:please )?(?:read|say) (?:the )?next sentence")
                || q.equals("sentence after this") || q.equals("next one");
        if (next) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready yet. Ask a question first.");
            else if (currentSentenceIndex + 1 < answerSentences.size()) {
                currentSentenceIndex++;
                persistSessionState();
                speakCurrentSentence(answerGeneration);
            } else {
                answerLocked = false;
                awaitingNextQuestion = false;
                persistSessionState();
                speakControlNotice("This answer is complete. You can ask your next Science question.");
            }
            return true;
        }

        boolean repeatPrevious = q.matches("(?:please )?(?:repeat|replay|read|say) (?:the )?(?:previous|prior) sentence")
                || q.matches("(?:please )?(?:previous|prior) sentence")
                || q.matches("(?:please )?go back (?:one|a) sentence")
                || q.matches("(?:please )?repeat previous")
                || q.matches("(?:please )?previous");
        if (repeatPrevious) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready to replay yet.");
            else if (currentSentenceIndex <= 0) speakControlNotice("This is the first sentence. Say next sentence or repeat.");
            else speakSentenceAt(currentSentenceIndex - 1, answerGeneration, true);
            return true;
        }

        boolean repeatCurrent = q.matches("(?:please )?(?:repeat|again|replay)(?: that| it| this)?")
                || q.matches("(?:please )?(?:repeat|read|say) (?:the )?(?:current|last|same) sentence")
                || q.equals("say it again") || q.equals("read that again") || q.equals("repeat that sentence");
        if (repeatCurrent) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready to repeat. Ask a question first.");
            else speakCurrentSentence(answerGeneration);
            return true;
        }

        Integer requested = parseSentenceNumberCommand(q);
        if (requested != null) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready yet. Ask a question first.");
            else if (requested >= 1 && requested <= answerSentences.size()) {
                speakSentenceAt(requested - 1, answerGeneration, true);
            } else speakControlNotice("That sentence number is not in the current answer. Say a number between one and " + answerSentences.size() + ".");
            return true;
        }

        if (answerLocked) return false;

        Matcher inlineNextQuestion = Pattern.compile("^(?:please )?(?:next|new) question(?:\\s+(?:is|says))?\\s*[:,-]?\\s*(.+)$", Pattern.CASE_INSENSITIVE).matcher(raw == null ? "" : raw.trim());
        if (inlineNextQuestion.matches()) {
            String embeddedQuestion = inlineNextQuestion.group(1) == null ? "" : inlineNextQuestion.group(1).trim();
            if (embeddedQuestion.equalsIgnoreCase("is") || embeddedQuestion.equalsIgnoreCase("says")) embeddedQuestion = "";
            awaitingNextQuestion = true;
            awaitingNextParagraph = false;
            persistSessionState();
            if (embeddedQuestion.isEmpty()) {
                speakControlNotice("Ready. Please say the complete next question.");
            } else if (handleClearlyIncompleteInput(embeddedQuestion)) {
                // Prompt for completion while retaining the prior answer.
            } else {
                processQuestion(embeddedQuestion);
            }
            return true;
        }

        if (q.matches("(?:please )?(?:next question|new question|ask next question|ready for next question)")) {
            // Do not clear the saved answer until a complete new answer has been returned.
            awaitingNextQuestion = true;
            awaitingNextParagraph = false;
            persistSessionState();
            speakControlNotice("Ready. Please say the complete next question.");
            return true;
        }
        return false;
    }

    private boolean handleClearlyIncompleteInput(String raw) {
        if (raw == null) return false;
        String q = raw.toLowerCase(Locale.ROOT).trim().replaceAll("[.!?,;:]+$", "").replaceAll("\\s+", " ");
        if (q.isEmpty()) {
            speakControlNotice("Please say the complete question.");
            return true;
        }

        // Truly clipped interrogatives: do not reject grammatically complete short questions.
        if (q.matches("(?:what|who|where|when|why|how|which)(?:\\s+(?:is|are|was|were|do|does|did|can|could|would|will|should|has|have|had))?")) {
            speakControlNotice("Please say the complete question, including all details and options.");
            return true;
        }
        String last = q.substring(q.lastIndexOf(' ') + 1);
        Set<String> dangling = Set.of("because", "and", "or", "but", "if", "that", "who", "whom", "whose", "which", "what", "when", "where", "why", "how", "is", "are", "was", "were", "do", "does", "did", "has", "have", "had", "can", "could", "would", "will", "should", "to", "of", "for", "from", "with", "in", "on", "at", "by", "the", "an", "complete", "fill", "write", "give", "explain", "find", "because of");
        boolean clippedInstruction = q.matches("(?:please )?(?:complete|fill(?: in)?|write|give|find|explain|state|tell me|change|convert|identify|correct)\\s+(?:the\\s+)?(?:answer|reason|meaning|word|sentence|boxes|web|diagram|following|correct|into|from)?\\s*");
        boolean barePrompt = q.matches("(?:passage|grammar|meaning|tense|voice|punctuation|summary|answer|question|explain|write|complete|correct|translate|pronunciation)");
        if (dangling.contains(last) || clippedInstruction || barePrompt) {
            speakControlNotice("Please say the complete question, including all details and options.");
            return true;
        }
        return false;
    }

    private Integer parseSentenceNumberCommand(String q) {
        String numberText = null;
        Matcher m = Pattern.compile("^(?:please )?(?:repeat|read|say|replay) (?:the )?(?:sentence )?(?:number )?([a-z0-9]+)$").matcher(q);
        if (m.matches()) numberText = m.group(1);
        if (numberText == null) {
            m = Pattern.compile("^(?:please )?(?:sentence|number|line|no) (?:number )?([a-z0-9]+)$").matcher(q);
            if (m.matches()) numberText = m.group(1);
        }
        if (numberText == null && q.matches("[0-9]{1,2}")) numberText = q;
        // Fast replay: the student can say only "1", "2", "3" or "one", "two", "three".
        if (numberText == null && WORD_NUMBERS.containsKey(q)) numberText = q;
        if (numberText == null) {
            Matcher bareNo = Pattern.compile("^(?:it\\s+is\\s+|it'?s\\s+)?(?:no|number)\\s*([a-z0-9]+)$", Pattern.CASE_INSENSITIVE).matcher(q);
            if (bareNo.matches()) numberText = bareNo.group(1);
        }
        if (numberText == null) return null;
        if (numberText.matches("[0-9]{1,2}")) {
            try { return Integer.parseInt(numberText); } catch (NumberFormatException ignored) { return null; }
        }
        return WORD_NUMBERS.get(numberText);
    }

    private static final Map<String, Integer> WORD_NUMBERS = createWordNumbers();
    private static Map<String, Integer> createWordNumbers() {
        Map<String, Integer> map = new HashMap<>();
        String[] words = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"};
        for (int i = 0; i < words.length; i++) map.put(words[i], i);
        map.put("first", 1); map.put("second", 2); map.put("third", 3); map.put("fourth", 4); map.put("fifth", 5);
        map.put("sixth", 6); map.put("seventh", 7); map.put("eighth", 8); map.put("ninth", 9); map.put("tenth", 10);
        map.put("eleventh", 11); map.put("twelfth", 12); map.put("thirteenth", 13); map.put("fourteenth", 14); map.put("fifteenth", 15);
        map.put("sixteenth", 16); map.put("seventeenth", 17); map.put("eighteenth", 18); map.put("nineteenth", 19); map.put("twentieth", 20);
        map.put("twenty-first", 21); map.put("twenty-second", 22); map.put("twenty-third", 23); map.put("twenty-fourth", 24); map.put("twenty-fifth", 25);
        return map;
    }

    private boolean hasAnswer() { return answerSentences != null && !answerSentences.isEmpty() && currentSentenceIndex >= 0; }

    private void processQuestion(String question) {
        if (stopping || isProcessing) return;
        isProcessing = true;
        isSpeaking = false;
        questionCount++;
        updateStatus("Recognized question: " + abbreviate(question, 105) + " — sending to Gemini for an exam answer…");
        final String submittedQuestion = question;
        final String selectedModel = model;
        final String selectedKey = apiKey;
        final String passageAtQuestionTime = activePassage;
        if (networkExecutor == null || networkExecutor.isShutdown()) networkExecutor = Executors.newSingleThreadExecutor();
        networkExecutor.execute(() -> {
            try {
                String answer = requestAnswerWithRetry(selectedKey, selectedModel, submittedQuestion, passageAtQuestionTime);
                String visible = stripMachineMetadata(answer);
                if (isNonAnswerAcknowledgement(visible) || isPassageAcknowledgement(visible)) {
                    Log.w(TAG, "Model returned an acknowledgement instead of solving; retrying with a direct-solution instruction.");
                    String forced = "Answer the following Maharashtra SSC Class 10 Science exam question now. Do not classify it, save it, or describe its subject. Give the actual student-style exam answer with all required definitions, explanations, reasons, equations, numerical working, and answer-sheet points, one distinct sentence or step per line.\nOriginal problem: " + submittedQuestion;
                    answer = requestAnswerWithRetry(selectedKey, selectedModel, forced, passageAtQuestionTime);
                    visible = stripMachineMetadata(answer);
                }
                final String finalAnswer = answer;
                final String finalVisible = visible;
                handler.post(() -> {
                    if (stopping) return;
                    if (finalAnswer == null || finalAnswer.trim().isEmpty() || isNonAnswerAcknowledgement(finalVisible) || isPassageAcknowledgement(finalVisible)) {
                        playErrorAndResume("I did not receive a complete Science exam answer. Please repeat the full question, including all values, units, chemical formulae and diagram labels.");
                    } else {
                        setAnswerAndSpeak(finalAnswer, submittedQuestion);
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Gemini request failed", e);
                handler.post(() -> { if (!stopping) playErrorAndResume(userFacingError(e)); });
            }
        });
    }

    private String requestAnswerWithRetry(String key, String selectedModel, String question, String passageContext) throws Exception {
        int retryNumber = 0;
        while (true) {
            try { return requestAnswerOnce(key, selectedModel, question, passageContext); }
            catch (HttpApiException e) {
                boolean retryable = e.httpCode == 429 || e.httpCode == 500 || e.httpCode == 502 || e.httpCode == 503 || e.httpCode == 504;
                if (!retryable || retryNumber >= MAX_RETRIES) throw e;
                long delay = 2000L << retryNumber;
                retryNumber++;
                updateStatus("Gemini temporarily unavailable (HTTP " + e.httpCode + "). Retry " + retryNumber + " of " + MAX_RETRIES + " in " + (delay / 1000L) + " seconds…");
                try { Thread.sleep(delay); }
                catch (InterruptedException ex) { Thread.currentThread().interrupt(); throw new Exception("Request cancelled during retry.", ex); }
            }
        }
    }

    private String requestAnswerOnce(String key, String selectedModel, String question, String passageContext) throws Exception {
        String safeModel = selectedModel == null ? "" : selectedModel.trim();
        if (!safeModel.matches("[A-Za-z0-9._-]+")) throw new Exception("Invalid Gemini model ID. Use a valid model ID from Google AI Studio.");
        HttpURLConnection connection = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + safeModel + ":generateContent");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(120000);
            connection.setDoOutput(true);
            connection.setRequestProperty("x-goog-api-key", key);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            JSONObject payload = new JSONObject();
            JSONObject systemInstruction = new JSONObject();
            JSONArray systemParts = new JSONArray();
            systemParts.put(new JSONObject().put("text", INSTRUCTIONS));
            systemInstruction.put("parts", systemParts);
            payload.put("systemInstruction", systemInstruction);

            String userText = "Answer this Maharashtra State Board SSC Class 10 Science and Technology exam question. Give the actual solution, not a subject label, classification, hint, or summary. "
                    + "If a Science textbook PDF is attached, search for the same or a closely matching textbook question, then follow its relevant definitions, explanations, diagrams, equations, formulae, and worked-example method when appropriate. "
                    + "The spoken transcript may contain minor speech-recognition mistakes; correct them only when the scientific meaning is clear. "
                    + "Do not invent diagram labels, values, or assumptions. If critical information is missing, ask one precise clarification. "
                    + "Guide the student exactly what to write on the answer sheet, one complete sentence or one separate answer step per line. "
                    + "Current spoken Science exam question:\n" + question + "\n"
                    + "No passage needs to be stored. Output exactly [[VOICE=en-IN]] and [[PASSAGE=UNCHANGED]] first, followed by the complete answer only.";

            JSONArray parts = new JSONArray();
            if (textbookPdfUri != null && !textbookPdfUri.trim().isEmpty()) {
                String uploadedUri = ensureTextbookPdfUploaded(key);
                if (uploadedUri != null && !uploadedUri.trim().isEmpty()) {
                    parts.put(new JSONObject().put("fileData", new JSONObject()
                            .put("mimeType", "application/pdf")
                            .put("fileUri", uploadedUri)));
                }
            }
            parts.put(new JSONObject().put("text", userText));
            JSONArray contents = new JSONArray();
            contents.put(new JSONObject().put("role", "user").put("parts", parts));
            payload.put("contents", contents);
            JSONObject config = new JSONObject();
            config.put("maxOutputTokens", 3072);
            config.put("temperature", 0.12);
            payload.put("generationConfig", config);

            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(body); }
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            String responseText = readStream(stream);
            if (code < 200 || code >= 300) throw makeHttpError(code, responseText);
            JSONObject response = new JSONObject(responseText);
            JSONArray candidates = response.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) throw new Exception("Gemini returned no answer. Ask the science problem again.");
            JSONObject candidate = candidates.optJSONObject(0);
            JSONObject content = candidate == null ? null : candidate.optJSONObject("content");
            JSONArray responseParts = content == null ? null : content.optJSONArray("parts");
            StringBuilder output = new StringBuilder();
            if (responseParts != null) {
                for (int i = 0; i < responseParts.length(); i++) {
                    JSONObject part = responseParts.optJSONObject(i);
                    String text = part == null ? "" : part.optString("text", "").trim();
                    if (!text.isEmpty()) { if (output.length() > 0) output.append('\n'); output.append(text); }
                }
            }
            return output.toString().trim();
        } finally { if (connection != null) connection.disconnect(); }
    }

    private String ensureTextbookPdfUploaded(String key) throws Exception {
        if (textbookPdfUri == null || textbookPdfUri.trim().isEmpty()) return "";
        if (textbookPdfUri.equals(uploadedPdfSourceUri) && uploadedPdfUri != null && !uploadedPdfUri.isEmpty()
                && System.currentTimeMillis() - uploadedPdfTimestamp < 42L * 60L * 60L * 1000L) {
            return uploadedPdfUri;
        }
        updateStatus("Uploading Science textbook PDF to Gemini…");
        byte[] pdfBytes = readSelectedPdfBytes(textbookPdfUri);
        if (pdfBytes.length == 0) throw new Exception("The selected textbook PDF is empty.");
        if (pdfBytes.length > 45 * 1024 * 1024) throw new Exception("The PDF is larger than 45 MB. Choose a smaller file.");
        String uploadUrl = beginPdfUpload(key, pdfBytes.length);
        String remoteUri = finishPdfUpload(uploadUrl, pdfBytes, key);
        if (remoteUri == null || remoteUri.trim().isEmpty()) throw new Exception("The PDF uploaded, but Gemini did not return a file reference.");
        uploadedPdfUri = remoteUri;
        uploadedPdfSourceUri = textbookPdfUri;
        uploadedPdfTimestamp = System.currentTimeMillis();
        persistSessionState();
        updateStatus("Science textbook PDF is ready. Solving the problem…");
        return remoteUri;
    }

    private byte[] readSelectedPdfBytes(String uriString) throws Exception {
        ContentResolver resolver = getContentResolver();
        try (InputStream in = resolver.openInputStream(Uri.parse(uriString));
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception("Could not open the selected PDF. Please select it again.");
            byte[] buffer = new byte[8192];
            int total = 0;
            int count;
            while ((count = in.read(buffer)) != -1) {
                total += count;
                if (total > 45 * 1024 * 1024) throw new Exception("The PDF is larger than 45 MB. Choose a smaller file.");
                out.write(buffer, 0, count);
            }
            return out.toByteArray();
        }
    }

    private String beginPdfUpload(String key, int byteCount) throws Exception {
        HttpURLConnection connection = null;
        try {
            String encodedKey = URLEncoder.encode(key, "UTF-8");
            URL url = new URL("https://generativelanguage.googleapis.com/upload/v1beta/files?key=" + encodedKey);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(30000);
            connection.setDoOutput(true);
            connection.setRequestProperty("X-Goog-Upload-Protocol", "resumable");
            connection.setRequestProperty("X-Goog-Upload-Command", "start");
            connection.setRequestProperty("X-Goog-Upload-Header-Content-Length", String.valueOf(byteCount));
            connection.setRequestProperty("X-Goog-Upload-Header-Content-Type", "application/pdf");
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] metadata = new JSONObject().put("file", new JSONObject().put("display_name", "Maharashtra_SSC_Class_10_Science_Textbook.pdf"))
                    .toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(metadata.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(metadata); }
            int code = connection.getResponseCode();
            String response = readStream(code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream());
            if (code < 200 || code >= 300) throw makeHttpError(code, response);
            String uploadUrl = connection.getHeaderField("X-Goog-Upload-URL");
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) uploadUrl = connection.getHeaderField("x-goog-upload-url");
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) {
                Map<String, java.util.List<String>> headers = connection.getHeaderFields();
                if (headers != null) for (Map.Entry<String, java.util.List<String>> h : headers.entrySet()) {
                    if (h.getKey() != null && "x-goog-upload-url".equalsIgnoreCase(h.getKey()) && h.getValue() != null && !h.getValue().isEmpty()) {
                        uploadUrl = h.getValue().get(0); break;
                    }
                }
            }
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) throw new Exception("Gemini did not return a PDF upload URL.");
            return uploadUrl.trim();
        } finally { if (connection != null) connection.disconnect(); }
    }

    private String finishPdfUpload(String uploadUrl, byte[] pdfBytes, String key) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(uploadUrl).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(90000);
            connection.setDoOutput(true);
            connection.setRequestProperty("X-Goog-Upload-Offset", "0");
            connection.setRequestProperty("X-Goog-Upload-Command", "upload, finalize");
            connection.setRequestProperty("Content-Type", "application/pdf");
            connection.setFixedLengthStreamingMode(pdfBytes.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(pdfBytes); }
            int code = connection.getResponseCode();
            String response = readStream(code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream());
            if (code < 200 || code >= 300) throw makeHttpError(code, response);
            JSONObject root = new JSONObject(response);
            JSONObject file = root.optJSONObject("file");
            if (file == null) file = root;
            String uri = file.optString("uri", "").trim();
            String name = file.optString("name", "").trim();
            if (uri.isEmpty()) throw new Exception("Gemini did not return the uploaded PDF URI.");
            if (!name.isEmpty()) waitForPdfProcessing(name, key);
            return uri;
        } finally { if (connection != null) connection.disconnect(); }
    }

    // Gemini can return a file reference before PDF processing is complete.
    // Poll its metadata before using the URI in a generateContent request.
    private void waitForPdfProcessing(String fileName, String key) throws Exception {
        if (!fileName.matches("files/[A-Za-z0-9_-]+")) throw new Exception("Gemini returned an invalid PDF file reference.");
        long deadline = System.currentTimeMillis() + 90000L;
        String state = "PROCESSING";
        while ("PROCESSING".equalsIgnoreCase(state) && System.currentTimeMillis() < deadline) {
            try { Thread.sleep(2000L); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new Exception("PDF processing was interrupted.", e); }
            HttpURLConnection metadataConnection = null;
            try {
                URL metadataUrl = new URL("https://generativelanguage.googleapis.com/v1beta/" + fileName);
                metadataConnection = (HttpURLConnection) metadataUrl.openConnection();
                metadataConnection.setRequestMethod("GET");
                metadataConnection.setConnectTimeout(20000);
                metadataConnection.setReadTimeout(30000);
                metadataConnection.setRequestProperty("x-goog-api-key", key);
                int metadataCode = metadataConnection.getResponseCode();
                String metadataText = readStream(metadataCode >= 200 && metadataCode < 300 ? metadataConnection.getInputStream() : metadataConnection.getErrorStream());
                if (metadataCode < 200 || metadataCode >= 300) throw makeHttpError(metadataCode, metadataText);
                JSONObject metadata = new JSONObject(metadataText);
                state = metadata.optString("state", "").trim().toUpperCase(Locale.ROOT);
                if ("FAILED".equals(state)) throw new Exception("Gemini could not process the selected textbook PDF. Try a clearer or smaller PDF.");
                if (state.isEmpty() || "ACTIVE".equals(state)) return;
            } finally { if (metadataConnection != null) metadataConnection.disconnect(); }
        }
        if ("PROCESSING".equalsIgnoreCase(state)) throw new Exception("The textbook PDF is still processing. Please try the Science problem again in a moment.");
        if (!state.isEmpty() && !"ACTIVE".equalsIgnoreCase(state)) throw new Exception("The textbook PDF is not ready (" + state + "). Please select it again or continue without the PDF.");
    }

    private String applyPassageMarker(String response, String submittedQuestion) {
        if (response == null) return "UNCHANGED";
        Matcher matcher = Pattern.compile("(?m)^\\s*\\[\\[PASSAGE=(STORE_CURRENT_INPUT|APPEND_CURRENT_INPUT|CLEAR|UNCHANGED)\\]\\]\\s*$", Pattern.CASE_INSENSITIVE).matcher(response);
        if (!matcher.find()) return "UNCHANGED";
        String value = matcher.group(1) == null ? "UNCHANGED" : matcher.group(1).trim().toUpperCase(Locale.ROOT);
        if ("STORE_CURRENT_INPUT".equals(value)) {
            String incoming = submittedQuestion == null ? "" : submittedQuestion.trim();
            if (activePassage == null || activePassage.trim().isEmpty()) {
                activePassage = incoming;
                persistSessionState();
                Log.i(TAG, "Initial question-paper passage stored; characters=" + activePassage.length());
            } else {
                // Science input is never stored as passage text.
                Log.i(TAG, "Ignored unintended passage replacement because an active passage is already locked.");
                value = "UNCHANGED";
            }
        } else if ("APPEND_CURRENT_INPUT".equals(value)) {
            String addition = submittedQuestion == null ? "" : submittedQuestion.trim();
            String lowerAddition = addition.toLowerCase(Locale.ROOT);
            boolean explicitContinuation = lowerAddition.matches("(?s)^(?:please )?(?:continue|append) (?:the )?passage.*")
                    || lowerAddition.matches("(?s)^next part of (?:the )?passage.*");
            if (explicitContinuation && !addition.isEmpty()) {
                String continuationText = addition.replaceFirst("(?i)^(?:please )?(?:continue|append) (?:the )?passage\\s*[:,-]?\\s*", "")
                        .replaceFirst("(?i)^next part of (?:the )?passage\\s*[:,-]?\\s*", "").trim();
                if (!continuationText.isEmpty()) {
                    activePassage = activePassage == null || activePassage.trim().isEmpty()
                            ? continuationText : activePassage.trim() + " " + continuationText;
                    persistSessionState();
                }
                Log.i(TAG, "Explicit question-paper passage continuation appended; characters=" + (activePassage == null ? 0 : activePassage.length()));
            } else {
                Log.i(TAG, "Ignored unintended passage append because no explicit continuation command was given.");
                value = "UNCHANGED";
            }
        } else if ("CLEAR".equals(value)) {
            activePassage = "";
            persistSessionState();
            Log.i(TAG, "Question-paper passage cleared");
        }
        return value;
    }

    private String stripMachineMetadata(String answer) {
        if (answer == null) return "";
        return answer.replaceAll("(?m)^\\s*\\[\\[(?:VOICE|PASSAGE)=.*?\\]\\]\\s*$", "").trim();
    }

    private boolean isPassageAcknowledgement(String answer) {
        String normalized = answer == null ? "" : answer.trim().replaceAll("\\s+", " ");
        return normalized.matches("(?i)(?:(?:the )?(?:new )?passage (?:has been )?(?:successfully )?(?:saved|stored|updated)(?:[.! ]+.*)?|please read the passage(?: from the question paper)? first)[.! ]*");
    }


    private boolean isNonAnswerAcknowledgement(String answer) {
        String value = answer == null ? "" : answer.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
        if (value.isEmpty()) return true;
        if (value.matches("(?is)^(?:your )?question (?:(?:has been)|was|is) (?:saved|stored)(?:[.! ]+.*)?$")) return true;
        if (value.contains("tumche prashna jatan kele") || value.contains("navin prashna sanga")
                || value.contains("प्रश्न जतन") || value.contains("नवीन प्रश्न सांगा")) return true;
        if (value.matches("(?is)^(?:please )?(?:say|tell me|ask) (?:a |the |your )?(?:new |next )?question[.! ]*$")) return true;
        if (value.matches("(?is)^(?:this is|that is) (?:a |an )?(?:science|physics|chemistry|biology|mathematics|maths) question[.! ]*$")) return true;
        if (value.matches("(?is)^(?:the )?(?:topic|subject) (?:is|appears to be) (?:science|physics|chemistry|biology|mathematics|maths)[.! ]*$")) return true;
        if (value.matches("(?is)^(?:this question is about|it is about|this is about) (?:science|physics|chemistry|biology)[.! ]*$")) return true;
        if (value.matches("(?is)^(?:i have|i've) saved (?:your )?question[.! ]*$")) return true;
        return false;
    }

    private void setAnswerAndSpeak(String rawAnswer, String answeredQuestion) {
        ArrayList<String> parsed = splitAnswerIntoSentences(rawAnswer);
        if (parsed.isEmpty()) { playErrorAndResume("Gemini returned an empty answer. Please ask again."); return; }
        answerSentences = parsed;
        currentSentenceIndex = 0;
        lastAnsweredQuestion = answeredQuestion == null ? "" : answeredQuestion.trim();
        awaitingNextQuestion = false;
        answerLocked = true;
        answerGeneration++;
        persistSessionState();
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Speaking sentence 1 of " + answerSentences.size() + ". Say 'next sentence' to continue.");
        speakCurrentSentence(answerGeneration);
    }

    private ArrayList<String> splitAnswerIntoSentences(String rawAnswer) {
        ArrayList<String> result = new ArrayList<>();
        if (rawAnswer == null) return result;
        String clean = rawAnswer.replaceAll("(?m)^\\s*\\[\\[(?:VOICE|PASSAGE)=.*?\\]\\]\\s*$", "")
                .replace("```", "").replace("**", "").replace("__", "").replace("*", "").replace("`", "").trim();
        if (clean.isEmpty()) return result;
        String[] lines = clean.split("\\r?\\n");
        Pattern numberedLine = Pattern.compile("^\\s*(?:sentence\\s*)?(\\d{1,2})\\s*[.):-]\\s*(.+?)\\s*$", Pattern.CASE_INSENSITIVE);
        int numberedCount = 0;
        for (String line : lines) if (numberedLine.matcher(line.trim()).matches()) numberedCount++;
        if (numberedCount > 0) {
            for (String original : lines) {
                String line = original.trim();
                if (line.isEmpty()) continue;
                Matcher m = numberedLine.matcher(line);
                if (m.matches()) line = m.group(2).trim();
                else line = line.replaceFirst("^(?:[-•]+|[A-Z][.)])\\s*", "").trim();
                addSentenceFragments(result, line);
            }
        } else {
            for (String original : lines) {
                String line = original.trim().replaceFirst("^(?:[-•]+)\\s*", "").trim();
                if (!line.isEmpty()) addSentenceFragments(result, line);
            }
        }
        return result;
    }

    private void addSentenceFragments(ArrayList<String> target, String line) {
        if (line == null || line.trim().isEmpty()) return;
        BreakIterator iterator = BreakIterator.getSentenceInstance(Locale.US);
        iterator.setText(line.trim());
        int start = iterator.first();
        for (int end = iterator.next(); end != BreakIterator.DONE; start = end, end = iterator.next()) {
            String part = line.trim().substring(start, end).trim();
            if (!part.isEmpty()) target.add(part);
        }
    }

    private void speakCurrentSentence(long generation) {
        speakSentenceAt(currentSentenceIndex, generation, false);
    }

    // A replay uses its own utterance ID and does not move the progress pointer.
    // This means "next sentence" still continues from the point where the student paused.
    private void speakSentenceAt(int sentenceIndex, long generation, boolean preserveProgress) {
        if (stopping || generation != answerGeneration) return;
        if (answerSentences == null || sentenceIndex < 0 || sentenceIndex >= answerSentences.size()) {
            isSpeaking = false;
            startListening();
            return;
        }
        if (tts == null || !ttsReady || !configureEnglishVoice()) {
            isSpeaking = false;
            updateStatus("English voice unavailable. Check speech settings.");
            handler.postDelayed(this::startListening, 1000L);
            return;
        }
        isSpeaking = true;
        String text = "Sentence " + (sentenceIndex + 1) + ". " + answerSentences.get(sentenceIndex);
        String prefix = preserveProgress ? "replay_" : "sentence_";
        String utteranceId = prefix + generation + "_" + sentenceIndex;
        updateStatus((preserveProgress ? "Replaying sentence " : "Speaking sentence ")
                + (sentenceIndex + 1) + " of " + answerSentences.size() + "…");
        int spoken = tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), utteranceId);
        if (spoken == TextToSpeech.ERROR) {
            isSpeaking = false;
            updateStatus("Could not speak this sentence. Try repeating its sentence number.");
            handler.postDelayed(this::startListening, 500L);
        }
    }

    private void speakControlNotice(String message) {
        if (stopping) return;
        if (tts == null || !ttsReady || !configureEnglishVoice()) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 500L);
            return;
        }
        isSpeaking = true;
        String id = "notice_" + answerGeneration + "_" + System.currentTimeMillis();
        updateStatus("Speaking instruction…");
        int spoken = tts.speak(message, TextToSpeech.QUEUE_FLUSH, new Bundle(), id);
        if (spoken == TextToSpeech.ERROR) { isSpeaking = false; handler.postDelayed(this::startListening, 500L); }
    }

    private void handleUtteranceDone(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("replay_")) {
            String[] bits = utteranceId.split("_");
            if (bits.length >= 3) {
                try {
                    long generation = Long.parseLong(bits[1]);
                    int replayedIndex = Integer.parseInt(bits[2]);
                    if (generation != answerGeneration || replayedIndex < 0 || replayedIndex >= answerSentences.size()) return;
                } catch (NumberFormatException ignored) { return; }
            }
            isSpeaking = false;
            isProcessing = false;
            updateStatus(answerLocked
                    ? "Replayed. Current answer remains locked. Say next sentence, repeat, or previous sentence."
                    : "Replayed. The answer is complete; you may ask another Science question.");
            startListening();
            return;
        }
        if (utteranceId.startsWith("sentence_")) {
            String[] bits = utteranceId.split("_");
            if (bits.length >= 3) {
                try {
                    long generation = Long.parseLong(bits[1]);
                    int sentenceIndex = Integer.parseInt(bits[2]);
                    if (generation != answerGeneration || sentenceIndex != currentSentenceIndex) return;
                } catch (NumberFormatException ignored) { return; }
            }
            isSpeaking = false;
            isProcessing = false;
            if (currentSentenceIndex >= answerSentences.size() - 1) {
                answerLocked = false;
                awaitingNextQuestion = false;
                persistSessionState();
                updateStatus("Answer complete. You may ask the next Science question.");
            } else {
                answerLocked = true;
                persistSessionState();
                updateStatus("Sentence " + (currentSentenceIndex + 1) + " read. Answer locked. Say 'next sentence', 'repeat', or 'previous sentence'.");
            }
            startListening();
            return;
        }
        if (utteranceId.startsWith("notice_") || utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            updateStatus("Listening for your next instruction…");
            handler.postDelayed(this::startListening, 200L);
        }
    }

    private void handleUtteranceFinishedWithError(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("sentence_") || utteranceId.startsWith("replay_") || utteranceId.startsWith("notice_") || utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            updateStatus("Speech playback ended. Listening again…");
            handler.postDelayed(this::startListening, 500L);
        }
    }

    private void playErrorAndResume(String message) {
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Question could not be answered; speaking a short notice.");
        speakControlNotice(errorMessageInEnglish(message));
    }

    private String errorMessageInEnglish(String message) {
        String value = message == null ? "" : message.toLowerCase(Locale.ROOT);
        if (value.contains("503") || value.contains("temporarily busy") || value.contains("unavailable")) return "The AI service is temporarily unavailable. Please try again shortly.";
        if (value.contains("429") || value.contains("quota") || value.contains("request limit")) return "The free usage limit may have been reached. Please wait before trying again.";
        if (value.contains("401") || value.contains("403") || value.contains("api key") || value.contains("authorize")) return "Please check the Gemini API key and its permissions.";
        if (value.contains("400") || value.contains("model name") || value.contains("model id")) return "Please check the Gemini model name and request settings.";
        return "I could not get an answer. Check your internet connection and API key, then ask again.";
    }

    private HttpApiException makeHttpError(int code, String responseText) {
        String message = "";
        try { JSONObject err = new JSONObject(responseText).optJSONObject("error"); if (err != null) message = err.optString("message", "").trim(); }
        catch (Exception ignored) { }
        return new HttpApiException(code, message);
    }

    private String userFacingError(Exception e) {
        if (e instanceof HttpApiException) {
            HttpApiException apiError = (HttpApiException) e;
            if (apiError.httpCode == 503) return "The AI server is temporarily busy (HTTP 503) after retries. Please try again later.";
            if (apiError.httpCode == 429) return "The free-tier quota or request limit was reached (HTTP 429). Wait before asking again.";
            if (apiError.httpCode == 400) return "The AI rejected the request (HTTP 400). Check the model name.";
            if (apiError.httpCode == 401 || apiError.httpCode == 403) return "The API key could not be authorized (HTTP " + apiError.httpCode + "). Check the key and API access.";
            if (apiError.httpCode >= 500) return "The AI server is unavailable (HTTP " + apiError.httpCode + ") after retries. Please try again later.";
            return "AI request failed with HTTP " + apiError.httpCode + (apiError.apiMessage.isEmpty() ? "." : ". " + abbreviate(apiError.apiMessage, 130));
        }
        String reason = e.getMessage();
        return (reason == null || reason.trim().isEmpty()) ? "I could not get an answer. Check internet access and your Gemini API settings." : abbreviate(reason, 210);
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private String abbreviate(String text, int max) { if (text == null) return ""; return text.length() <= max ? text : text.substring(0, max) + "…"; }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getPackageName() + ":ScienceAnswerTeller");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(SESSION_LIMIT_MS + 30000L);
            }
        } catch (Exception e) { Log.w(TAG, "Could not acquire wakelock", e); }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Science Answer Teller session", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows Science listening and sentence-by-sentence answer status, with a Stop action.");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String status) {
        Intent stopIntent = new Intent(this, VoiceLoopService.class);
        stopIntent.setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 992, stopIntent, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Science Answer Teller active")
                .setContentText(status)
                .setStyle(new Notification.BigTextStyle().bigText(status))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "STOP", stopPendingIntent).build());
        return builder.build();
    }

    private void updateStatus(String status) {
        if (stopping || notificationManager == null) return;
        try { notificationManager.notify(NOTIFICATION_ID, buildNotification(status)); }
        catch (Exception e) { Log.w(TAG, "Could not update notification", e); }
    }

    private void stopLoop() {
        if (stopping) { stopSelf(); return; }
        stopping = true;
        started = false;
        answerGeneration++;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        releaseAudioRouting();
        if (tts != null) { try { tts.stop(); } catch (Exception ignored) { } try { tts.shutdown(); } catch (Exception ignored) { } tts = null; }
        ttsReady = false;
        if (networkExecutor != null) { networkExecutor.shutdownNow(); networkExecutor = null; }
        if (wakeLock != null && wakeLock.isHeld()) { try { wakeLock.release(); } catch (Exception ignored) { } }
        wakeLock = null;
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override public void onDestroy() { if (!stopping) stopLoop(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }

    private static class HttpApiException extends Exception {
        final int httpCode;
        final String apiMessage;
        HttpApiException(int httpCode, String apiMessage) {
            super("Gemini HTTP " + httpCode + (apiMessage == null || apiMessage.isEmpty() ? "" : ": " + apiMessage));
            this.httpCode = httpCode;
            this.apiMessage = apiMessage == null ? "" : apiMessage;
        }
    }
}
