package com.example.voiceloop;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VoiceLoopService extends Service {
    public static final String ACTION_START = "com.example.voiceloop.START";
    public static final String ACTION_STOP = "com.example.voiceloop.STOP";
    public static final String EXTRA_API_KEY = "api_key";
    public static final String EXTRA_MODEL = "model";
    public static final String EXTRA_LANGUAGE = "language";

    private static final String TAG = "MathNotebookGuide";
    private static final String CHANNEL_ID = "math_notebook_guide_session";
    private static final String STATE_PREFS = "math_notebook_guide_saved_session";
    private static final int NOTIFICATION_ID = 2462;
    private static final long SESSION_LIMIT_MS = 6L * 60L * 60L * 1000L;
    private static final int MAX_RETRIES = 3;

    private static final String INSTRUCTIONS =
            "You are Math Notebook Guide, an exacting Maharashtra State Board SSC Class 10 mathematics solver and a patient voice tutor. The student is writing by hand in a notebook and cannot rely on seeing the answer on-screen. Solve the spoken problem correctly and guide the student through exactly what to write, in order. Strive for high accuracy, but do not claim that any solution is guaranteed perfect. Recheck arithmetic and algebra before responding.\n" +
            "LANGUAGE AND VOICE-FIRST FORMAT: Use clear, simple Indian English suitable for a student. Use natural, speakable words, not visual formatting. Do not use Markdown, tables, code fences, LaTeX, asterisks, hashtags, bullets, pipes, or decorative headings. Avoid greetings and filler. The app will add a spoken line number automatically. Do not put manual line numbers at the start of your answer. Put every distinct notebook-writing action or equation on its own output line. Never make one output line contain multiple separate notebook lines.\n" +
            "NO PDF NEEDED: The user speaks the full problem aloud. Treat the recognized transcript as the problem. Correct small speech-to-text errors only when mathematical context makes the intended wording clear. If a value, sign, exponent, denominator, bracket, unit, or instruction is ambiguous and could change the answer, ask one brief clarification instead of guessing. Do not invent missing values.\n" +
            "NOTEBOOK-WRITING PROTOCOL: Give a board-exam style, line-by-line solution that can be copied into a notebook. Each output line must tell the student what to write and where it belongs, then dictate the exact mathematical content in an unambiguous spoken order. For example, use directions such as ‘On the first working line, write Given: ...’, ‘On the next line, write the formula: ...’, ‘On a new line, substitute the given values: ...’, ‘On the next line, simplify: ...’, and ‘On the final line, write Therefore, the answer is ...’. Include the literal heading only when it belongs in the notebook. Do not say only a vague instruction such as ‘solve it’; dictate the actual equation or values the student must write. Do not skip intermediate transformations. Do not repeat long explanations unnecessarily.\n" +
            "SPOKEN MATHEMATICAL NOTATION IS MANDATORY: Since the user hears rather than sees the answer, say every symbol clearly and in order. For parentheses use ‘open bracket’ and ‘close bracket’, then say the contents exactly; if nested, identify each opening and closing bracket in sequence. Example: (x + 2) squared must be dictated as ‘open bracket, x plus two, close bracket, all squared’. Do not silently omit brackets or treat their contents as optional. Say plus, minus, multiplied by, divided by, equals, is less than, is greater than, approximately equals, square root of, cube root of, squared, to the power of, numerator, denominator, absolute value, and decimal point explicitly where needed. Identify negative numbers as ‘negative three’, not merely ‘minus three’, when they are standalone values. Say fractions in a way that makes numerator and denominator unmistakable. Speak variable names and subscripts clearly, for example ‘x sub one’. Dictate the exact terms, signs, exponents, brackets and equal signs in the order the student should write them.\n" +
            "SOLUTION METHOD: First identify the given information and what is asked. Choose a method appropriate for Maharashtra SSC Class 10 mathematics. For algebra, show each valid equivalent transformation on a new line, preserving signs and brackets. For word problems, define the variable, form the equation, solve it, and finish with a line answering the question. For quadratic equations, show the appropriate factorisation, formula or completing-the-square steps and both valid roots when applicable. For simultaneous equations, show elimination or substitution clearly. For arithmetic progressions, state the relevant formula and substitute values before calculating. For statistics, show the formula, values substituted and final value. For probability, state favourable outcomes over total equally likely outcomes where applicable. For coordinate geometry, dictate ordered pairs and substituted formula. For trigonometry, identify the ratio, sides and angle carefully. For geometry proofs, tell the student to write Given, To Prove, Construction if needed, and Proof on separate lines; explain the reason for each key step. For constructions or graphs, describe where to draw the figure, labels, axes, scale, points and table entries. Do not pretend a drawing has been completed; guide the student to draw it.\n" +
            "NOTEBOOK LAYOUT: Keep the work orderly. Start with ‘Given’ and ‘To find’ when useful. Write formulas before substituting numbers. Keep each equality or algebraic transformation on a new line. Align calculations vertically where possible. Tell the student when to start a new line, write a heading, draw a labelled figure, make a table, or put the final answer at the end. Include units in the final answer where required. Do not tell the student to write all steps on one line. For a simple one-step problem, keep the solution short; for a multi-step problem, include all essential steps.\n" +
            "BRACKETS AND EXPRESSIONS: For every expression containing brackets, say ‘open bracket’, dictate every item inside in order, and say ‘close bracket’. For multiple or nested brackets, say each opening and closing mark. Make clear whether an exponent applies to a variable alone, a number, or a whole bracket. For fractions, identify the numerator and denominator or clearly say ‘all over’. For roots, dictate the entire expression under the root. For a negative sign outside a bracket, say ‘negative’ or ‘minus sign outside the bracket’ as appropriate. Avoid readings that could confuse 2x with x squared or minus x with negative x squared.\n" +
            "ACCURACY CHECK: Calculate independently when possible, check arithmetic, preserve every negative sign, use exact fractions until decimal form is required, round only when instructed, and verify a solution by substitution or reverse calculation when useful. If there are several roots, cases, or possible answers, include all that are required and state restrictions such as a nonzero denominator. Do not skip an answer because one method is shorter. If the user specifies marks or a required method, follow that method and depth.\n" +
            "QUESTION HANDLING: If the transcript is a complete math problem, solve it; do not ask for it again just because it is brief if it contains a clear equation or expression. If the user says ‘next question is’ and then speaks the problem, solve that embedded problem. If the question is clearly unfinished or a key number/sign is missing, preserve the prior saved answer and say in one short line what part needs to be completed. Do not overwrite the active answer when input is incomplete. The user must say ‘next question’ before starting another problem once an answer is active. The previous solution remains saved until a complete new solution is generated.\n" +
            "LINE-BY-LINE VOICE CONTROL: The app speaks one complete output line as ‘Line one’, ‘Line two’, and so on, then listens. Keep every remaining line stored. Do not assume silence means the user has finished writing or wants to discard anything. The user can say ‘next line’, ‘next step’ or ‘next’ to continue; ‘repeat’ to replay the current line; ‘line three’, ‘step three’, ‘repeat line three’, or simply ‘three’ to replay a specific stored line. To make replay useful, each output line must be self-contained enough to write. Do not include manual numeric line labels because the app reads the line number.\n" +
            "MANDATORY MACHINE FORMAT: Output these metadata lines first, exactly once each: [[VOICE=en-IN]] and [[PASSAGE=UNCHANGED]]. After them, output only the solution, with one notebook-writing action or equation on each separate line. Do not include any other metadata, source references, internal reasoning, or comments about these rules.";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService networkExecutor;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;
    private String apiKey;
    private String model = "gemini-3.5-flash-lite";
    private String recognitionLanguageTag = "en-IN";
    private String activePassage = "";
    private ArrayList<String> answerLines = new ArrayList<>();
    private int currentLineIndex = -1;
    private int questionCount = 0;
    private long answerGeneration = 0L;
    private boolean ttsReady = false;
    private boolean isProcessing = false;
    private boolean isSpeaking = false;
    private boolean stopping = false;
    private boolean started = false;
    private boolean awaitingNextParagraph = false;
    private boolean awaitingNextQuestion = false;
    private String lastAnsweredQuestion = "";
    private NotificationManager notificationManager;

    @Override public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();
        networkExecutor = Executors.newSingleThreadExecutor();
        restoreSessionState();
    }

    private void persistSessionState() {
        try {
            JSONArray solutionLines = new JSONArray();
            if (answerLines != null) {
                for (String line : answerLines) solutionLines.put(line == null ? "" : line);
            }
            getSharedPreferences(STATE_PREFS, MODE_PRIVATE).edit()
                    .putString("active_passage", activePassage == null ? "" : activePassage)
                    .putString("answer_lines", solutionLines.toString())
                    .putInt("current_line_index", currentLineIndex)
                    .putBoolean("awaiting_next_question", awaitingNextQuestion)
                    .putBoolean("awaiting_next_paragraph", awaitingNextParagraph)
                    .putString("last_answered_question", lastAnsweredQuestion == null ? "" : lastAnsweredQuestion)
                    .apply();
        } catch (Exception e) {
            Log.w(TAG, "Could not persist session state", e);
        }
    }

    private void restoreSessionState() {
        try {
            SharedPreferences prefs = getSharedPreferences(STATE_PREFS, MODE_PRIVATE);
            activePassage = prefs.getString("active_passage", "");
            awaitingNextQuestion = prefs.getBoolean("awaiting_next_question", false);
            awaitingNextParagraph = prefs.getBoolean("awaiting_next_paragraph", false);
            lastAnsweredQuestion = prefs.getString("last_answered_question", "");
            answerLines = new ArrayList<>();
            String saved = prefs.getString("answer_lines", "[]");
            JSONArray solutionLines = new JSONArray(saved == null ? "[]" : saved);
            for (int i = 0; i < solutionLines.length(); i++) {
                String line = solutionLines.optString(i, "").trim();
                if (!line.isEmpty()) answerLines.add(line);
            }
            currentLineIndex = prefs.getInt("current_line_index", -1);
            if (answerLines.isEmpty() || currentLineIndex < 0 || currentLineIndex >= answerLines.size()) {
                if (answerLines.isEmpty()) currentLineIndex = -1;
                else currentLineIndex = Math.max(0, Math.min(currentLineIndex, answerLines.size() - 1));
            }
            Log.i(TAG, "Restored saved session: passageChars=" + (activePassage == null ? 0 : activePassage.length())
                    + ", answerLines=" + answerLines.size() + ", currentIndex=" + currentLineIndex);
        } catch (Exception e) {
            Log.w(TAG, "Could not restore saved session; starting with fresh state", e);
            activePassage = "";
            answerLines = new ArrayList<>();
            currentLineIndex = -1;
            awaitingNextQuestion = false;
            awaitingNextParagraph = false;
            lastAnsweredQuestion = "";
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopLoop();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        apiKey = intent.getStringExtra(EXTRA_API_KEY);
        model = intent.getStringExtra(EXTRA_MODEL);
        recognitionLanguageTag = "en-IN";
        if (apiKey == null || apiKey.trim().isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (model == null || model.trim().isEmpty()) model = "gemini-3.5-flash-lite";
        started = true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
                startForeground(NOTIFICATION_ID, buildNotification("Starting Math Notebook Guide…"), types);
            } else {
                startForeground(NOTIFICATION_ID, buildNotification("Starting Math Notebook Guide…"));
            }
        } catch (SecurityException | IllegalArgumentException ex) {
            Log.e(TAG, "Could not start foreground service", ex);
            stopLoop();
            return START_NOT_STICKY;
        }
        acquireWakeLock();
        handler.postDelayed(this::stopLoop, SESSION_LIMIT_MS);
        initialiseTts();
        updateStatus("Preparing Math Notebook Guide voice and speech recognition…");
        return START_NOT_STICKY;
    }

    private void initialiseTts() {
        tts = new TextToSpeech(getApplicationContext(), status -> handler.post(() -> {
            if (stopping) return;
            if (status != TextToSpeech.SUCCESS || tts == null) {
                updateStatus("Text-to-speech could not start. Check Android speech settings.");
                handler.postDelayed(this::initialiseTts, 3000L);
                return;
            }
            tts.setSpeechRate(0.88f);
            tts.setPitch(1.0f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { handler.post(() -> handleUtteranceDone(utteranceId)); }
                @Override public void onError(String utteranceId) { handler.post(() -> handleUtteranceFinishedWithError(utteranceId)); }
                @Override public void onError(String utteranceId, int errorCode) { handler.post(() -> handleUtteranceFinishedWithError(utteranceId)); }
            });
            ttsReady = configureEnglishVoice();
            if (ttsReady) {
                updateStatus("Voice ready. Say your math problem…");
                startListening();
            } else {
                updateStatus("An English voice is unavailable. Install English voice data in Android Text-to-speech settings.");
            }
        }));
    }

    private boolean configureEnglishVoice() {
        if (tts == null) return false;
        Locale preferred = Locale.forLanguageTag("en-IN");
        int result;
        try { result = tts.setLanguage(preferred); }
        catch (Exception e) { Log.w(TAG, "Could not select en-IN voice", e); return false; }
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.ERROR) {
            Log.w(TAG, "English voice data unavailable. result=" + result);
            return false;
        }
        try {
            Set<Voice> voices = tts.getVoices();
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            if (voices != null) {
                for (Voice voice : voices) {
                    Locale vl = voice.getLocale();
                    if (vl == null || !"en".equalsIgnoreCase(vl.getLanguage())) continue;
                    int score = voice.getQuality() * 10;
                    if ("IN".equalsIgnoreCase(vl.getCountry())) score += 100;
                    else if ("GB".equalsIgnoreCase(vl.getCountry())) score += 10;
                    if (voice.isNetworkConnectionRequired()) score += 2;
                    if (score > bestScore) { bestScore = score; best = voice; }
                }
            }
            if (best != null && tts.setVoice(best) == TextToSpeech.ERROR) {
                Log.w(TAG, "Could not set a specific English voice; keeping en-IN language setting");
            }
        } catch (Exception e) { Log.w(TAG, "Could not choose best installed English voice", e); }
        tts.setSpeechRate(0.88f);
        tts.setPitch(1.0f);
        return true;
    }

    private void startListening() {
        if (stopping || !started || isProcessing || isSpeaking) return;
        if (!ttsReady) { handler.postDelayed(this::startListening, 500L); return; }
        destroyRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Speech recognition unavailable. Enable an Android speech service; retrying…");
            handler.postDelayed(this::startListening, 5000L);
            return;
        }
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { updateStatus("Listening for a math problem or line command…"); }
                @Override public void onBeginningOfSpeech() { updateStatus("Listening…"); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { updateStatus("Recognizing speech…"); }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String heard = (matches == null || matches.isEmpty()) ? "" : matches.get(0).trim();
                    destroyRecognizer();
                    // Empty or noisy recognition must never clear the saved math solution.
                    if (heard.isEmpty()) {
                        // Silence, no-match, or an empty recognizer result never changes saved output.
                        handler.postDelayed(VoiceLoopService.this::startListening, 450L);
                    } else if (handleLineCommand(heard)) {
                        // Navigation changes only the current line pointer, never the saved solution.
                    } else if (handlePassageCommand(heard)) {
                        // This app does not need a passage; preserved compatibility branch does not change solution lines.
                    } else if (handleClearlyIncompleteInput(heard)) {
                        // Keep the saved answer and wait for the user to complete the question.
                    } else if (hasAnswer() && !awaitingNextQuestion) {
                        // The current math solution is locked until the user explicitly says "next question".
                        speakControlNotice("Your current solution is saved. Say next question before giving another problem.");
                    } else {
                        processQuestion(heard);
                    }
                }
                @Override public void onError(int error) {
                    destroyRecognizer();
                    if (stopping || isProcessing || isSpeaking) return;
                    long delay = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1500L : 800L;
                    updateStatus("Speech recognition reset; listening again…");
                    handler.postDelayed(VoiceLoopService.this::startListening, delay);
                }
            });
            Intent speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            // Allow a 2–3 second thinking/pronunciation pause; finalize after about 3.5–4 seconds of silence.
            speechIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3500L);
            speechIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L);
            recognizer.startListening(speechIntent);
        } catch (Exception e) {
            Log.e(TAG, "Could not start speech recognition", e);
            destroyRecognizer();
            updateStatus("Could not start listening; retrying…");
            handler.postDelayed(this::startListening, 1500L);
        }
    }

    private boolean handleLineCommand(String raw) {
        String q = raw == null ? "" : raw.toLowerCase(Locale.ROOT).trim();
        q = q.replaceAll("[.!?,;:]+$", "").replaceAll("\\s+", " ").trim();
        if (q.isEmpty()) return false;

        boolean next = q.matches("(?:please )?(?:next|continue|go on)(?: line| step| sentence| point)?")
                || q.matches("(?:please )?(?:read|say) (?:the )?next (?:line|step|sentence)")
                || q.equals("line after this") || q.equals("sentence after this") || q.equals("step after this") || q.equals("next one");
        if (next) {
            if (!hasAnswer()) speakControlNotice("There is no solution ready yet. Say a complete math problem first.");
            else if (currentLineIndex + 1 < answerLines.size()) {
                currentLineIndex++;
                persistSessionState();
                speakCurrentLine(answerGeneration);
            } else speakControlNotice("There are no more solution lines in this answer. Ask your next question.");
            return true;
        }

        boolean repeatCurrent = q.matches("(?:please )?(?:repeat|again|replay)(?: that| it| this)?")
                || q.matches("(?:please )?(?:repeat|read|say) (?:the )?(?:current|last|same) (?:line|step|sentence)")
                || q.equals("say it again") || q.equals("read that again") || q.equals("repeat that line") || q.equals("repeat that sentence") || q.equals("repeat that step");
        if (repeatCurrent) {
            if (!hasAnswer()) speakControlNotice("There is no solution line ready to repeat. Give a math problem first.");
            else speakCurrentLine(answerGeneration);
            return true;
        }

        Integer requested = parseLineNumberCommand(q);
        if (requested != null) {
            if (!hasAnswer()) speakControlNotice("There is no solution ready yet. Say a complete math problem first.");
            else if (requested >= 1 && requested <= answerLines.size()) {
                currentLineIndex = requested - 1;
                persistSessionState();
                speakCurrentLine(answerGeneration);
            } else speakControlNotice("That line number is not in the current solution. Say a number between one and " + answerLines.size() + ".");
            return true;
        }

        Matcher inlineNextQuestion = Pattern.compile("^(?:please )?(?:next|new) question(?:\\s+(?:is|says))?\\s*[:,-]?\\s*(.+)$", Pattern.CASE_INSENSITIVE).matcher(raw == null ? "" : raw.trim());
        if (inlineNextQuestion.matches()) {
            String embeddedQuestion = inlineNextQuestion.group(1) == null ? "" : inlineNextQuestion.group(1).trim();
            if (embeddedQuestion.equalsIgnoreCase("is") || embeddedQuestion.equalsIgnoreCase("says")) embeddedQuestion = "";
            awaitingNextQuestion = true;
            awaitingNextParagraph = false;
            persistSessionState();
            if (embeddedQuestion.isEmpty()) {
                speakControlNotice("Ready. Please say the complete next math problem.");
            } else if (handleClearlyIncompleteInput(embeddedQuestion)) {
                // Prompt for completion while retaining the prior answer.
            } else {
                processQuestion(embeddedQuestion);
            }
            return true;
        }

        if (q.matches("(?:please )?(?:next question|new question|ask next question|ready for next question)")) {
            // Do not clear the saved answer until a complete new answer has been returned.
            awaitingNextQuestion = true;
            awaitingNextParagraph = false;
            persistSessionState();
            speakControlNotice("Ready. Please say the complete next math problem.");
            return true;
        }
        return false;
    }

    private boolean handlePassageCommand(String raw) {
        if (raw == null || raw.trim().isEmpty()) return false;
        String q = raw.trim().replaceAll("\\s+", " ");

        Matcher newPassage = Pattern.compile("^(?:please )?(?:new|next) passage(?:\\s+(?:is|says|goes like this))?\\s*[:,-]?\\s*(.*)$", Pattern.CASE_INSENSITIVE).matcher(q);
        Matcher clearPassage = Pattern.compile("^(?:please )?(?:clear|reset) (?:the )?passage$", Pattern.CASE_INSENSITIVE).matcher(q);
        if (clearPassage.matches() || newPassage.matches()) {
            String body = clearPassage.matches() ? "" : (newPassage.group(1) == null ? "" : newPassage.group(1).trim());
            activePassage = body;
            awaitingNextParagraph = body.isEmpty();
            persistSessionState();
            if (body.isEmpty()) speakControlNotice("The old passage is cleared. Please read the new passage now.");
            else speakControlNotice("New passage saved. Ask your question.");
            return true;
        }

        Matcher nextParagraph = Pattern.compile("^(?:please )?(?:(?:read|use|replace with) )?(?:the )?(?:next|new) paragraph(?:\\s+(?:is|says|goes like this))?\\s*[:,-]?\\s*(.*)$", Pattern.CASE_INSENSITIVE).matcher(q);
        if (nextParagraph.matches()) {
            String body = nextParagraph.group(1) == null ? "" : nextParagraph.group(1).trim();
            if (body.isEmpty()) {
                awaitingNextParagraph = true;
                persistSessionState();
                speakControlNotice("Please read the new paragraph now.");
            } else {
                activePassage = body;
                awaitingNextParagraph = false;
                persistSessionState();
                Log.i(TAG, "Active passage replaced from explicit next-paragraph input; characters=" + activePassage.length());
                speakControlNotice("New paragraph saved. Ask your question.");
            }
            return true;
        }

        Matcher continuation = Pattern.compile("^(?:please )?(?:continue|append) (?:the )?(?:paragraph|passage)(?:\\s+(?:is|with|says))?\\s*[:,-]?\\s*(.*)$", Pattern.CASE_INSENSITIVE).matcher(q);
        if (continuation.matches()) {
            String body = continuation.group(1) == null ? "" : continuation.group(1).trim();
            if (body.isEmpty()) {
                awaitingNextParagraph = true;
                persistSessionState();
                speakControlNotice("Please read the continuation now.");
            } else {
                activePassage = (activePassage == null || activePassage.trim().isEmpty()) ? body : activePassage.trim() + " " + body;
                awaitingNextParagraph = false;
                persistSessionState();
                speakControlNotice("Passage continuation saved. Ask your question.");
            }
            return true;
        }

        if (awaitingNextParagraph) {
            activePassage = q;
            awaitingNextParagraph = false;
            persistSessionState();
            Log.i(TAG, "Active passage replaced from explicit next-paragraph input; characters=" + activePassage.length());
            speakControlNotice("New paragraph saved. Ask your question.");
            return true;
        }
        return false;
    }

    private boolean handleClearlyIncompleteInput(String raw) {
        if (raw == null) return false;
        String q = raw.toLowerCase(Locale.ROOT).trim().replaceAll("[.!?,;:]+$", "").replaceAll("\\s+", " ");
        if (q.isEmpty()) {
            speakControlNotice("Please say the complete question.");
            return true;
        }

        // A bare but mathematically complete expression such as x=2, 2+2, or 3x-5=7 is valid input.
        if (looksLikeMathExpression(q)) return false;

        // Truly clipped interrogatives: do not reject grammatically complete short questions.
        if (q.matches("(?:what|who|where|when|why|how|which)(?:\\s+(?:is|are|was|were|do|does|did|can|could|would|will|should|has|have|had))?")) {
            speakControlNotice("Please say the complete question, including all details and options.");
            return true;
        }
        String last = q.substring(q.lastIndexOf(' ') + 1);
        String[] words = q.split(" ");
        Set<String> compactCompleteQuestions = Set.of(
                "what happened", "what changed", "who won", "who came", "who helped him", "who helped her", "who helped them",
                "who is he", "who is she", "what is this", "what is that", "what is it", "where were they",
                "what did he do", "what did she do", "what did they do");
        if (words.length <= 2 && !compactCompleteQuestions.contains(q)) {
            speakControlNotice("Please say the complete question, including all details and options.");
            return true;
        }
        Set<String> dangling = Set.of("because", "and", "or", "but", "if", "that", "who", "whom", "whose", "which", "what", "when", "where", "why", "how", "is", "are", "was", "were", "do", "does", "did", "has", "have", "had", "can", "could", "would", "will", "should", "to", "of", "for", "from", "with", "in", "on", "at", "by", "the", "a", "an", "complete", "fill", "write", "give", "explain", "find", "because of");
        boolean clippedInstruction = q.matches("(?:please )?(?:complete|fill(?: in)?|write|give|find|explain|state|tell me|change|convert|identify|correct)\\s+(?:the\\s+)?(?:answer|reason|meaning|word|line|boxes|web|diagram|following|correct|into|from)?\\s*");
        boolean barePrompt = q.matches("(?:passage|grammar|meaning|tense|voice|punctuation|summary|answer|question|explain|write|complete|correct|translate|pronunciation)");
        if (dangling.contains(last) || clippedInstruction || barePrompt) {
            speakControlNotice("Please say the complete question, including all details and options.");
            return true;
        }
        return false;
    }

    private boolean looksLikeMathExpression(String q) {
        if (q == null || q.trim().isEmpty()) return false;
        String value = q.trim().toLowerCase(Locale.ROOT);
        boolean hasDigit = value.matches("(?s).*\\d.*");
        boolean hasOperator = value.matches("(?s).*(?:=|\\+|\\*|/|\\^|√|×|÷|<|>|≤|≥|\\bplus\\b|\\bminus\\b|\\btimes\\b|\\bequals?\\b|\\bsquared\\b|\\bdivided by\\b|\\bsquare root\\b).*");
        if (hasDigit && hasOperator) return true;
        if (value.matches("(?s).*(?:\\bsolve\\b|\\bsimplify\\b|\\bfactor(?:ise|ize)?\\b|\\bevaluate\\b|\\bcalculate\\b|\\bfind the value\\b|\\bfind x\\b|\\bprove that\\b|\\bshow that\\b).*")) {
            return value.split("\\s+").length >= 3;
        }
        return false;
    }

    private Integer parseLineNumberCommand(String q) {
        String numberText = null;
        Matcher m = Pattern.compile("^(?:please )?(?:repeat|read|say|replay) (?:the )?(?:(?:line|step|sentence) )?(?:number )?([a-z0-9]+)$").matcher(q);
        if (m.matches()) numberText = m.group(1);
        if (numberText == null) {
            m = Pattern.compile("^(?:please )?(?:repeat|read|say|replay) (?:the )?([a-z0-9]+) (?:line|step|sentence)$").matcher(q);
            if (m.matches()) numberText = m.group(1);
        }
        if (numberText == null) {
            m = Pattern.compile("^(?:please )?(?:line|number|step|sentence|no) (?:number )?([a-z0-9]+)$").matcher(q);
            if (m.matches()) numberText = m.group(1);
        }
        if (numberText == null && q.matches("[0-9]{1,2}")) numberText = q;
        if (numberText == null && WORD_NUMBERS.containsKey(q)) numberText = q;
        if (numberText == null) return null;
        if (numberText.matches("[0-9]{1,2}")) {
            try { return Integer.parseInt(numberText); } catch (NumberFormatException ignored) { return null; }
        }
        return WORD_NUMBERS.get(numberText);
    }

    private static final Map<String, Integer> WORD_NUMBERS = createWordNumbers();
    private static Map<String, Integer> createWordNumbers() {
        Map<String, Integer> map = new HashMap<>();
        String[] words = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"};
        for (int i = 0; i < words.length; i++) map.put(words[i], i);
        map.put("first", 1); map.put("second", 2); map.put("third", 3); map.put("fourth", 4); map.put("fifth", 5);
        map.put("sixth", 6); map.put("seventh", 7); map.put("eighth", 8); map.put("ninth", 9); map.put("tenth", 10);
        return map;
    }

    private boolean hasAnswer() { return answerLines != null && !answerLines.isEmpty() && currentLineIndex >= 0; }

    private void processQuestion(String question) {
        if (stopping || isProcessing) return;
        isProcessing = true;
        isSpeaking = false;
        questionCount++;
        updateStatus("Math problem " + questionCount + ": checking and preparing notebook steps…");
        final String submittedQuestion = question;
        final String selectedModel = model;
        final String selectedKey = apiKey;
        final String passageAtQuestionTime = "";
        if (networkExecutor == null || networkExecutor.isShutdown()) networkExecutor = Executors.newSingleThreadExecutor();
        networkExecutor.execute(() -> {
            try {
                String answer = requestAnswerWithRetry(selectedKey, selectedModel, submittedQuestion, passageAtQuestionTime);
                handler.post(() -> {
                    if (stopping) return;
                    if (answer == null || answer.trim().isEmpty()) playErrorAndResume("The model returned an empty solution. Please say the math problem again.");
                    else {
                        applyPassageMarker(answer, submittedQuestion);
                        String visibleAnswer = stripMachineMetadata(answer);
                        if (isPassageAcknowledgement(visibleAnswer)) {
                            // Keep the old solution if the model unexpectedly returns a passage notice.
                            speakControlNotice(visibleAnswer.replace('\n', ' ').trim());
                        } else {
                            setAnswerAndSpeak(answer, submittedQuestion);
                        }
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Gemini request failed", e);
                handler.post(() -> { if (!stopping) playErrorAndResume(userFacingError(e)); });
            }
        });
    }

    private String requestAnswerWithRetry(String key, String selectedModel, String question, String passageContext) throws Exception {
        int retryNumber = 0;
        while (true) {
            try { return requestAnswerOnce(key, selectedModel, question, passageContext); }
            catch (HttpApiException e) {
                boolean retryable = e.httpCode == 429 || e.httpCode == 500 || e.httpCode == 502 || e.httpCode == 503 || e.httpCode == 504;
                if (!retryable || retryNumber >= MAX_RETRIES) throw e;
                long delay = 2000L << retryNumber;
                retryNumber++;
                updateStatus("Gemini temporarily unavailable (HTTP " + e.httpCode + "). Retry " + retryNumber + " of " + MAX_RETRIES + " in " + (delay / 1000L) + " seconds…");
                try { Thread.sleep(delay); }
                catch (InterruptedException ex) { Thread.currentThread().interrupt(); throw new Exception("Request cancelled during retry.", ex); }
            }
        }
    }

    private String requestAnswerOnce(String key, String selectedModel, String question, String passageContext) throws Exception {
        String safeModel = selectedModel == null ? "" : selectedModel.trim();
        if (!safeModel.matches("[A-Za-z0-9._-]+")) throw new Exception("Invalid Gemini model ID. Use gemini-3.5-flash-lite.");
        HttpURLConnection connection = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + safeModel + ":generateContent");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(90000);
            connection.setDoOutput(true);
            connection.setRequestProperty("x-goog-api-key", key);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            JSONObject payload = new JSONObject();
            JSONObject systemInstruction = new JSONObject();
            JSONArray systemParts = new JSONArray();
            systemParts.put(new JSONObject().put("text", INSTRUCTIONS));
            systemInstruction.put("parts", systemParts);
            payload.put("systemInstruction", systemInstruction);

            String userText = "Solve this Maharashtra State Board SSC Class 10 mathematics problem using the system instructions. No textbook PDF is required.\n"
                    + "Current spoken problem transcript (may contain small speech-recognition errors):\n" + question + "\n"
                    + "Interpret spoken operators and brackets carefully. Calculate and verify the result. Provide a fully worked, notebook-ready solution. Each separate notebook-writing instruction or equation must be on its own line, dictated so the student can write it by listening. Include all brackets, values, signs and the final answer. Output exactly [[VOICE=en-IN]] and [[PASSAGE=UNCHANGED]] first, then the answer only.";
            JSONArray parts = new JSONArray();
            parts.put(new JSONObject().put("text", userText));
            JSONArray contents = new JSONArray();
            contents.put(new JSONObject().put("role", "user").put("parts", parts));
            payload.put("contents", contents);
            JSONObject config = new JSONObject();
            config.put("maxOutputTokens", 2048);
            config.put("temperature", 0.12);
            payload.put("generationConfig", config);

            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(body); }
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            String responseText = readStream(stream);
            if (code < 200 || code >= 300) throw makeHttpError(code, responseText);
            JSONObject response = new JSONObject(responseText);
            JSONArray candidates = response.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) throw new Exception("Gemini returned no answer. Ask the question again.");
            JSONObject candidate = candidates.optJSONObject(0);
            JSONObject content = candidate == null ? null : candidate.optJSONObject("content");
            JSONArray responseParts = content == null ? null : content.optJSONArray("parts");
            StringBuilder output = new StringBuilder();
            if (responseParts != null) {
                for (int i = 0; i < responseParts.length(); i++) {
                    JSONObject part = responseParts.optJSONObject(i);
                    String text = part == null ? "" : part.optString("text", "").trim();
                    if (!text.isEmpty()) { if (output.length() > 0) output.append('\n'); output.append(text); }
                }
            }
            return output.toString().trim();
        } finally { if (connection != null) connection.disconnect(); }
    }

    private String applyPassageMarker(String response, String submittedQuestion) {
        if (response == null) return "UNCHANGED";
        Matcher matcher = Pattern.compile("(?m)^\\s*\\[\\[PASSAGE=(STORE_CURRENT_INPUT|APPEND_CURRENT_INPUT|CLEAR|UNCHANGED)\\]\\]\\s*$", Pattern.CASE_INSENSITIVE).matcher(response);
        if (!matcher.find()) return "UNCHANGED";
        String value = matcher.group(1) == null ? "UNCHANGED" : matcher.group(1).trim().toUpperCase(Locale.ROOT);
        if ("STORE_CURRENT_INPUT".equals(value)) {
            String incoming = submittedQuestion == null ? "" : submittedQuestion.trim();
            if (activePassage == null || activePassage.trim().isEmpty()) {
                activePassage = incoming;
                persistSessionState();
                Log.i(TAG, "Initial question-paper passage stored; characters=" + activePassage.length());
            } else {
                // An active passage is locked. Explicit replacement is handled locally by handlePassageCommand.
                Log.i(TAG, "Ignored unintended passage replacement because an active passage is already locked.");
                value = "UNCHANGED";
            }
        } else if ("APPEND_CURRENT_INPUT".equals(value)) {
            String addition = submittedQuestion == null ? "" : submittedQuestion.trim();
            String lowerAddition = addition.toLowerCase(Locale.ROOT);
            boolean explicitContinuation = lowerAddition.matches("(?s)^(?:please )?(?:continue|append) (?:the )?passage.*")
                    || lowerAddition.matches("(?s)^next part of (?:the )?passage.*");
            if (explicitContinuation && !addition.isEmpty()) {
                String continuationText = addition.replaceFirst("(?i)^(?:please )?(?:continue|append) (?:the )?passage\\s*[:,-]?\\s*", "")
                        .replaceFirst("(?i)^next part of (?:the )?passage\\s*[:,-]?\\s*", "").trim();
                if (!continuationText.isEmpty()) {
                    activePassage = activePassage == null || activePassage.trim().isEmpty()
                            ? continuationText : activePassage.trim() + " " + continuationText;
                    persistSessionState();
                }
                Log.i(TAG, "Explicit question-paper passage continuation appended; characters=" + (activePassage == null ? 0 : activePassage.length()));
            } else {
                Log.i(TAG, "Ignored unintended passage append because no explicit continuation command was given.");
                value = "UNCHANGED";
            }
        } else if ("CLEAR".equals(value)) {
            activePassage = "";
            persistSessionState();
            Log.i(TAG, "Question-paper passage cleared");
        }
        return value;
    }

    private String stripMachineMetadata(String answer) {
        if (answer == null) return "";
        return answer.replaceAll("(?m)^\\s*\\[\\[(?:VOICE|PASSAGE)=.*?\\]\\]\\s*$", "").trim();
    }

    private boolean isPassageAcknowledgement(String answer) {
        String normalized = answer == null ? "" : answer.trim().replaceAll("\\s+", " ");
        return normalized.matches("(?i)(?:(?:the )?(?:new )?passage (?:has been )?(?:successfully )?(?:saved|stored|updated)(?:[.! ]+.*)?|please read the passage(?: from the question paper)? first)[.! ]*");
    }

    private void setAnswerAndSpeak(String rawAnswer, String answeredQuestion) {
        ArrayList<String> parsed = splitAnswerIntoLines(rawAnswer);
        if (parsed.isEmpty()) { playErrorAndResume("Gemini returned an empty answer. Please ask again."); return; }
        answerLines = parsed;
        currentLineIndex = 0;
        lastAnsweredQuestion = answeredQuestion == null ? "" : answeredQuestion.trim();
        awaitingNextQuestion = false;
        answerGeneration++;
        persistSessionState();
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Speaking line 1 of " + answerLines.size() + ". Say 'next line' to continue.");
        speakCurrentLine(answerGeneration);
    }

    private ArrayList<String> splitAnswerIntoLines(String rawAnswer) {
        ArrayList<String> result = new ArrayList<>();
        if (rawAnswer == null) return result;
        String clean = rawAnswer.replaceAll("(?m)^\\s*\\[\\[(?:VOICE|PASSAGE)=.*?\\]\\]\\s*$", "")
                .replace("```", "").replace("**", "").replace("__", "").replace("*", "").replace("`", "").trim();
        if (clean.isEmpty()) return result;
        String[] lines = clean.split("\\r?\\n");
        for (String original : lines) {
            String line = original == null ? "" : original.trim();
            if (line.isEmpty()) continue;
            // Remove accidental model-added labels because the app supplies the spoken line number.
            line = line.replaceFirst("(?i)^(?:line|step|sentence)\\s*\\d+\\s*[:.)-]\\s*", "");
            line = line.replaceFirst("^\\d{1,2}\\s*[.):]\\s*", "");
            line = line.replaceFirst("^(?:[-•]+)\\s*", "").trim();
            if (!line.isEmpty()) result.add(line);
        }
        return result;
    }

    private void speakCurrentLine(long generation) {
        if (stopping || generation != answerGeneration) return;
        if (answerLines == null || currentLineIndex < 0 || currentLineIndex >= answerLines.size()) {
            isSpeaking = false;
            startListening();
            return;
        }
        if (tts == null || !ttsReady || !configureEnglishVoice()) {
            isSpeaking = false;
            updateStatus("English voice unavailable. Check speech settings.");
            handler.postDelayed(this::startListening, 1000L);
            return;
        }
        isSpeaking = true;
        String text = "Line " + (currentLineIndex + 1) + ". " + answerLines.get(currentLineIndex);
        String utteranceId = "line_" + generation + "_" + currentLineIndex;
        updateStatus("Speaking line " + (currentLineIndex + 1) + " of " + answerLines.size() + "…");
        int spoken = tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), utteranceId);
        if (spoken == TextToSpeech.ERROR) {
            isSpeaking = false;
            updateStatus("Could not speak this line. Try repeating its line number.");
            handler.postDelayed(this::startListening, 500L);
        }
    }

    private void speakControlNotice(String message) {
        if (stopping) return;
        if (tts == null || !ttsReady || !configureEnglishVoice()) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 500L);
            return;
        }
        isSpeaking = true;
        String id = "notice_" + answerGeneration + "_" + System.currentTimeMillis();
        updateStatus("Speaking instruction…");
        int spoken = tts.speak(message, TextToSpeech.QUEUE_FLUSH, new Bundle(), id);
        if (spoken == TextToSpeech.ERROR) { isSpeaking = false; handler.postDelayed(this::startListening, 500L); }
    }

    private void handleUtteranceDone(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("line_")) {
            String[] bits = utteranceId.split("_");
            if (bits.length >= 3) {
                try {
                    long generation = Long.parseLong(bits[1]);
                    int lineIndex = Integer.parseInt(bits[2]);
                    if (generation != answerGeneration || lineIndex != currentLineIndex) return;
                } catch (NumberFormatException ignored) { return; }
            }
            isSpeaking = false;
            isProcessing = false;
            updateStatus("Line " + (currentLineIndex + 1) + " read. Say 'next line', 'repeat', or a line number.");
            startListening();
            return;
        }
        if (utteranceId.startsWith("notice_") || utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            updateStatus("Listening for your next line command or math problem…");
            handler.postDelayed(this::startListening, 200L);
        }
    }

    private void handleUtteranceFinishedWithError(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("line_") || utteranceId.startsWith("notice_") || utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            updateStatus("Speech playback ended. Listening again…");
            handler.postDelayed(this::startListening, 500L);
        }
    }

    private void playErrorAndResume(String message) {
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Math problem could not be answered; speaking a short notice.");
        speakControlNotice(errorMessageInEnglish(message));
    }

    private String errorMessageInEnglish(String message) {
        String value = message == null ? "" : message.toLowerCase(Locale.ROOT);
        if (value.contains("503") || value.contains("temporarily busy") || value.contains("unavailable")) return "The AI service is temporarily unavailable. Please try again shortly.";
        if (value.contains("429") || value.contains("quota") || value.contains("request limit")) return "The free usage limit may have been reached. Please wait before trying again.";
        if (value.contains("401") || value.contains("403") || value.contains("api key") || value.contains("authorize")) return "Please check the Gemini API key and its permissions.";
        if (value.contains("400") || value.contains("model name") || value.contains("model id")) return "Please check the Gemini model name and request settings.";
        return "I could not get an answer. Check your internet connection and API key, then ask again.";
    }

    private HttpApiException makeHttpError(int code, String responseText) {
        String message = "";
        try { JSONObject err = new JSONObject(responseText).optJSONObject("error"); if (err != null) message = err.optString("message", "").trim(); }
        catch (Exception ignored) { }
        return new HttpApiException(code, message);
    }

    private String userFacingError(Exception e) {
        if (e instanceof HttpApiException) {
            HttpApiException apiError = (HttpApiException) e;
            if (apiError.httpCode == 503) return "The AI server is temporarily busy (HTTP 503) after retries. Please try again later.";
            if (apiError.httpCode == 429) return "The free-tier quota or request limit was reached (HTTP 429). Wait before asking again.";
            if (apiError.httpCode == 400) return "The AI rejected the request (HTTP 400). Check the model name.";
            if (apiError.httpCode == 401 || apiError.httpCode == 403) return "The API key could not be authorized (HTTP " + apiError.httpCode + "). Check the key and API access.";
            if (apiError.httpCode >= 500) return "The AI server is unavailable (HTTP " + apiError.httpCode + ") after retries. Please try again later.";
            return "AI request failed with HTTP " + apiError.httpCode + (apiError.apiMessage.isEmpty() ? "." : ". " + abbreviate(apiError.apiMessage, 130));
        }
        String reason = e.getMessage();
        return (reason == null || reason.trim().isEmpty()) ? "I could not get an answer. Check internet access and your Gemini API settings." : abbreviate(reason, 210);
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private String abbreviate(String text, int max) { if (text == null) return ""; return text.length() <= max ? text : text.substring(0, max) + "…"; }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getPackageName() + ":MathNotebookGuide");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(SESSION_LIMIT_MS + 30000L);
            }
        } catch (Exception e) { Log.w(TAG, "Could not acquire wakelock", e); }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Math Notebook Guide session", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows listening and math-solution line status, with a Stop action.");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String status) {
        Intent stopIntent = new Intent(this, VoiceLoopService.class);
        stopIntent.setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 992, stopIntent, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Math Notebook Guide active")
                .setContentText(status)
                .setStyle(new Notification.BigTextStyle().bigText(status))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "STOP", stopPendingIntent).build());
        return builder.build();
    }

    private void updateStatus(String status) {
        if (stopping || notificationManager == null) return;
        try { notificationManager.notify(NOTIFICATION_ID, buildNotification(status)); }
        catch (Exception e) { Log.w(TAG, "Could not update notification", e); }
    }

    private void stopLoop() {
        if (stopping) { stopSelf(); return; }
        stopping = true;
        started = false;
        answerGeneration++;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) { try { tts.stop(); } catch (Exception ignored) { } try { tts.shutdown(); } catch (Exception ignored) { } tts = null; }
        ttsReady = false;
        if (networkExecutor != null) { networkExecutor.shutdownNow(); networkExecutor = null; }
        if (wakeLock != null && wakeLock.isHeld()) { try { wakeLock.release(); } catch (Exception ignored) { } }
        wakeLock = null;
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override public void onDestroy() { if (!stopping) stopLoop(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }

    private static class HttpApiException extends Exception {
        final int httpCode;
        final String apiMessage;
        HttpApiException(int httpCode, String apiMessage) {
            super("Gemini HTTP " + httpCode + (apiMessage == null || apiMessage.isEmpty() ? "" : ": " + apiMessage));
            this.httpCode = httpCode;
            this.apiMessage = apiMessage == null ? "" : apiMessage;
        }
    }
}
