package com.example.voiceloop;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.ContentResolver;
import android.net.Uri;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VoiceLoopService extends Service {
    public static final String ACTION_START = "com.example.voiceloop.START";
    public static final String ACTION_STOP = "com.example.voiceloop.STOP";
    public static final String EXTRA_API_KEY = "api_key";
    public static final String EXTRA_MODEL = "model";
    public static final String EXTRA_LANGUAGE = "language";
    public static final String EXTRA_TEXTBOOK_URI = "geometry_textbook_pdf_uri";

    private static final String TAG = "GeometryAnswerTeller";
    private static final String CHANNEL_ID = "geometry_answer_teller_session";
    private static final String STATE_PREFS = "geometry_answer_teller_saved_session";
    private static final int NOTIFICATION_ID = 2462;
    private static final long SESSION_LIMIT_MS = 6L * 60L * 60L * 1000L;
    private static final int MAX_RETRIES = 3;

    private static final String INSTRUCTIONS =
            "You are Geometry Answer Teller, a careful Maharashtra State Board SSC Class 10 Geometry (Mathematics Part II) tutor and exam-answer writer. Your job is to SOLVE each spoken geometry problem and guide the student in the exact order to write the answer on the exam answer sheet. Never merely identify the subject, restate the problem, describe what it asks, or tell the student that the question was saved. A normal spoken input is a problem to solve.\n" +
            "LANGUAGE AND SPOKEN OUTPUT: Answer in clear, simple Indian English suitable for a Maharashtra SSC Class 10 student. Use school-level mathematical language. No greeting, filler, Markdown, tables, code fences, LaTeX, decorative bullets, or visual-only diagrams. Every complete answer sentence or distinct answer-sheet writing step must be on its own line. Do not add sentence numbers; the app adds them while speaking. Keep each spoken unit clear and short enough to write down.\n" +
            "OPTIONAL TEXTBOOK PDF: A Geometry textbook PDF may be attached to the question. When present, inspect the relevant pages, theorem statements, worked examples, diagrams, constructions, definitions, formulae, and notation. Prefer a correct method used in that uploaded book when it fits the problem. Use the book's own theorem names and sequence of steps where possible. Refer to a chapter, example, or page only when you can clearly verify it in the PDF; never invent page numbers or claim a method came from the book if you did not find it. If the PDF does not contain the relevant method, solve with a valid standard Class 10 method and say so only if useful. If no PDF is attached, solve using standard accepted geometry methods; never ask the user to upload a PDF just to answer.\n" +
            "ANSWER-SHEET FORMAT: Match the question type. For a proof, guide the student to write Given, To Prove, Construction (only if needed), and Proof. Put each proof statement on a separate line and give its mathematical reason, such as Given, common side, vertically opposite angles, corresponding angles, alternate interior angles, congruence criterion, similarity criterion, or the exact theorem used. Do not write a proof as an unsupported chain of equalities. For a numerical problem, write Given, To Find, the relevant theorem or formula, substitution, each essential calculation, and a final Therefore answer with units if required. For a theorem statement, write the correct statement and the requested application or proof. For a construction, guide the student through the construction steps in order, name the instruments and points/arcs/lines to draw, explain labels, and include the required justification if the question asks for it.\n" +
            "GEOMETRY TOPICS: Handle Maharashtra SSC Class 10 geometry topics such as similarity of triangles, Pythagoras theorem and its converse, circle theorems, tangents, chords, cyclic quadrilaterals, geometric constructions, coordinate geometry, trigonometric applications where included, and related mensuration or theorem-based exercises. Identify the exact theorem or criterion needed. For triangle proofs, name the two triangles in matching order and compare corresponding sides/angles consistently. For circle questions, identify the centre, radius, chord, tangent, secant, arc, cyclic quadrilateral, or angle relation accurately. For coordinate geometry, show the formula, ordered pairs, substitutions, arithmetic, and final result. Do not use a theorem whose conditions are not satisfied.\n" +
            "DIAGRAMS AND MISSING INFORMATION: The user may read a problem aloud but cannot automatically provide a picture of its question diagram. Use only the labels, lengths, angles, parallel/perpendicular marks, equal marks, and relationships actually stated or clearly described. If a critical diagram detail is missing or ambiguous and different interpretations would change the answer, ask one short specific clarification instead of guessing. When a figure is needed on the answer sheet, tell the student to draw a neat labelled figure and say exactly which points, lines, lengths, angles, centre, tangent, or marks to label. Do not pretend that you drew the figure.\n" +
            "MATHEMATICAL ACCURACY: Preserve every sign, angle, unit, point label, side order, exponent, and bracket. Check calculations and verify the result when possible. Do not assume a diagram is to scale. Do not invent a missing value or claim that a statement follows from a figure unless it is given or proved. Use exact values before approximations and round only when asked. If there are multiple sub-questions, answer every one in order. If the problem gives marks or asks for a particular method, follow that requirement.\n" +
            "SPOKEN MATHEMATICAL NOTATION: Because the student hears rather than sees the answer, dictate notation unambiguously in ordinary English words. Say 'angle A', 'triangle ABC', 'line AB', 'ray AB', 'segment AB', 'parallel to', 'perpendicular to', 'is congruent to', 'is similar to', 'equals', 'plus', 'minus', 'multiplied by', 'divided by', 'square root of', 'squared', 'degrees', and 'all over' clearly. Read ordered pairs as 'open bracket, x comma y, close bracket'. State which side or angle corresponds to which. Do not use unexplained symbols or compressed notation that a TTS voice may pronounce incorrectly. The student can write standard mathematical symbols from the dictated words.\n" +
            "MARKS AND ANSWER LENGTH: Let the marks and wording control depth. For one mark, give the exact required result or theorem statement. For two marks, show the essential theorem or calculation and conclusion. For proofs or higher-mark problems, include all essential intermediate statements and reasons. Do not pad with unrelated theory. Make the final answer unmistakable and tell the student exactly what to write at the end.\n" +
            "QUESTION HANDLING — CRITICAL: A new Geometry problem is accepted only after the app has finished speaking every sentence of the active answer. While an answer is unfinished, the app accepts only next-sentence, repeat-current, previous-sentence, and numbered-replay commands; other spoken input is not submitted as a new problem and must not replace the active answer. After the final answer sentence has finished, the next complete Geometry problem can be spoken directly; the user does not need to say 'next question' first. Never respond with 'your question is saved', 'tell me a new question', 'this is Geometry', or a topic classification instead of solving. Do not treat a geometry problem as a passage or store it as passage text. Ask a clarification only when a critical value, sign, label, or condition is genuinely missing.\n" +
            "SENTENCE-BY-SENTENCE ANSWER-SHEET GUIDE: The app speaks exactly one sentence or one distinct writing step, then stops and listens. Therefore, place each answer-sheet instruction, proof statement with reason, formula, equation, or calculation step on its own separate line. Every line must be something the student can actually write or do next on the answer sheet. Keep the lines in the correct order. Do not combine several separate notebook lines into one spoken unit. The student can say 'next sentence' or 'next' to continue, 'repeat' to hear the current sentence again, 'previous sentence' or 'repeat previous' to replay the preceding sentence, or 'sentence three' / 'repeat sentence three' to replay a numbered sentence without losing their place. The app locks onto the current problem until the final answer sentence has finished speaking. A different question must not replace or interrupt the active answer.\n" +
            "MANDATORY MACHINE FORMAT: Output exactly these two metadata lines first: [[VOICE=en-IN]] and [[PASSAGE=UNCHANGED]]. After them, output only the solved answer in English, with every sentence or separate answer-sheet writing step on its own line. Never output any other metadata, internal reasoning, subject classification, or commentary about these instructions.\n";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService networkExecutor;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;
    private String apiKey;
    private String model = "gemini-3.5-flash-lite";
    private String recognitionLanguageTag = "en-IN";
    private String activePassage = "";
    private String textbookPdfUri = "";
    private String uploadedPdfUri = "";
    private String uploadedPdfSourceUri = "";
    private long uploadedPdfTimestamp = 0L;
    private ArrayList<String> answerSentences = new ArrayList<>();
    private int currentSentenceIndex = -1;
    private int questionCount = 0;
    private long answerGeneration = 0L;
    private boolean ttsReady = false;
    private boolean isProcessing = false;
    private boolean isSpeaking = false;
    private boolean stopping = false;
    private boolean started = false;
    private boolean awaitingNextParagraph = false;
    private boolean awaitingNextQuestion = false;
    private boolean answerLocked = false;
    private String lastAnsweredQuestion = "";
    private NotificationManager notificationManager;

    @Override public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();
        networkExecutor = Executors.newSingleThreadExecutor();
        restoreSessionState();
    }

    private void persistSessionState() {
        try {
            JSONArray sentences = new JSONArray();
            if (answerSentences != null) {
                for (String sentence : answerSentences) sentences.put(sentence == null ? "" : sentence);
            }
            getSharedPreferences(STATE_PREFS, MODE_PRIVATE).edit()
                    .putString("active_passage", activePassage == null ? "" : activePassage)
                    .putString("answer_sentences", sentences.toString())
                    .putInt("current_sentence_index", currentSentenceIndex)
                    .putBoolean("awaiting_next_question", awaitingNextQuestion)
                    .putBoolean("answer_locked", answerLocked)
                    .putBoolean("awaiting_next_paragraph", awaitingNextParagraph)
                    .putString("last_answered_question", lastAnsweredQuestion == null ? "" : lastAnsweredQuestion)
                    .putString("textbook_pdf_uri", textbookPdfUri == null ? "" : textbookPdfUri)
                    .putString("uploaded_pdf_uri", uploadedPdfUri == null ? "" : uploadedPdfUri)
                    .putString("uploaded_pdf_source_uri", uploadedPdfSourceUri == null ? "" : uploadedPdfSourceUri)
                    .putLong("uploaded_pdf_timestamp", uploadedPdfTimestamp)
                    .apply();
        } catch (Exception e) {
            Log.w(TAG, "Could not persist session state", e);
        }
    }

    private void restoreSessionState() {
        try {
            SharedPreferences prefs = getSharedPreferences(STATE_PREFS, MODE_PRIVATE);
            activePassage = prefs.getString("active_passage", "");
            awaitingNextQuestion = prefs.getBoolean("awaiting_next_question", false);
            awaitingNextParagraph = prefs.getBoolean("awaiting_next_paragraph", false);
            lastAnsweredQuestion = prefs.getString("last_answered_question", "");
            textbookPdfUri = prefs.getString("textbook_pdf_uri", "");
            uploadedPdfUri = prefs.getString("uploaded_pdf_uri", "");
            uploadedPdfSourceUri = prefs.getString("uploaded_pdf_source_uri", "");
            uploadedPdfTimestamp = prefs.getLong("uploaded_pdf_timestamp", 0L);
            answerSentences = new ArrayList<>();
            String saved = prefs.getString("answer_sentences", "[]");
            JSONArray sentences = new JSONArray(saved == null ? "[]" : saved);
            for (int i = 0; i < sentences.length(); i++) {
                String sentence = sentences.optString(i, "").trim();
                if (!sentence.isEmpty()) answerSentences.add(sentence);
            }
            currentSentenceIndex = prefs.getInt("current_sentence_index", -1);
            if (answerSentences.isEmpty() || currentSentenceIndex < 0 || currentSentenceIndex >= answerSentences.size()) {
                if (answerSentences.isEmpty()) currentSentenceIndex = -1;
                else currentSentenceIndex = Math.max(0, Math.min(currentSentenceIndex, answerSentences.size() - 1));
            }
            answerLocked = prefs.getBoolean("answer_locked",
                    !answerSentences.isEmpty() && currentSentenceIndex < answerSentences.size() - 1);
            if (answerSentences.isEmpty()) answerLocked = false;
            Log.i(TAG, "Restored saved session: passageChars=" + (activePassage == null ? 0 : activePassage.length())
                    + ", answerSentences=" + answerSentences.size() + ", currentIndex=" + currentSentenceIndex);
        } catch (Exception e) {
            Log.w(TAG, "Could not restore saved session; starting with fresh state", e);
            activePassage = "";
            answerSentences = new ArrayList<>();
            currentSentenceIndex = -1;
            awaitingNextQuestion = false;
            awaitingNextParagraph = false;
            answerLocked = false;
            lastAnsweredQuestion = "";
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopLoop();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        apiKey = intent.getStringExtra(EXTRA_API_KEY);
        model = intent.getStringExtra(EXTRA_MODEL);
        recognitionLanguageTag = "en-IN";
        String incomingPdf = intent.getStringExtra(EXTRA_TEXTBOOK_URI);
        if (incomingPdf != null) {
            incomingPdf = incomingPdf.trim();
            if (!incomingPdf.equals(textbookPdfUri)) {
                textbookPdfUri = incomingPdf;
                uploadedPdfUri = "";
                uploadedPdfSourceUri = "";
                uploadedPdfTimestamp = 0L;
                persistSessionState();
            }
        }
        if (apiKey == null || apiKey.trim().isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (model == null || model.trim().isEmpty()) model = "gemini-3.5-flash-lite";
        started = true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
                startForeground(NOTIFICATION_ID, buildNotification("Starting Geometry Answer Teller…"), types);
            } else {
                startForeground(NOTIFICATION_ID, buildNotification("Starting Geometry Answer Teller…"));
            }
        } catch (SecurityException | IllegalArgumentException ex) {
            Log.e(TAG, "Could not start foreground service", ex);
            stopLoop();
            return START_NOT_STICKY;
        }
        acquireWakeLock();
        handler.postDelayed(this::stopLoop, SESSION_LIMIT_MS);
        initialiseTts();
        updateStatus("Preparing clear English (India) voice and speech recognition…");
        return START_NOT_STICKY;
    }

    private void initialiseTts() {
        tts = new TextToSpeech(getApplicationContext(), status -> handler.post(() -> {
            if (stopping) return;
            if (status != TextToSpeech.SUCCESS || tts == null) {
                updateStatus("Text-to-speech could not start. Check Android speech settings.");
                handler.postDelayed(this::initialiseTts, 3000L);
                return;
            }
            tts.setSpeechRate(0.88f);
            tts.setPitch(1.0f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { handler.post(() -> handleUtteranceDone(utteranceId)); }
                @Override public void onError(String utteranceId) { handler.post(() -> handleUtteranceFinishedWithError(utteranceId)); }
                @Override public void onError(String utteranceId, int errorCode) { handler.post(() -> handleUtteranceFinishedWithError(utteranceId)); }
            });
            ttsReady = configureEnglishVoice();
            if (ttsReady) {
                if (answerLocked && hasAnswer()) {
                    updateStatus("English voice ready. Resuming the unfinished Geometry answer…");
                    speakCurrentSentence(answerGeneration);
                } else {
                    updateStatus("English voice ready. Listening for your first question…");
                    startListening();
                }
            } else {
                updateStatus("An English voice is unavailable. Install English voice data in Android Text-to-speech settings.");
            }
        }));
    }

    private boolean configureEnglishVoice() {
        if (tts == null) return false;
        Locale preferred = Locale.forLanguageTag("en-IN");
        int result;
        try { result = tts.setLanguage(preferred); }
        catch (Exception e) { Log.w(TAG, "Could not select en-IN voice", e); return false; }
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.ERROR) {
            Log.w(TAG, "English voice data unavailable. result=" + result);
            return false;
        }
        try {
            Set<Voice> voices = tts.getVoices();
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            if (voices != null) {
                for (Voice voice : voices) {
                    Locale vl = voice.getLocale();
                    if (vl == null || !"en".equalsIgnoreCase(vl.getLanguage())) continue;
                    int score = voice.getQuality() * 10;
                    if ("IN".equalsIgnoreCase(vl.getCountry())) score += 100;
                    else if ("GB".equalsIgnoreCase(vl.getCountry())) score += 10;
                    if (voice.isNetworkConnectionRequired()) score += 2;
                    if (score > bestScore) { bestScore = score; best = voice; }
                }
            }
            if (best != null && tts.setVoice(best) == TextToSpeech.ERROR) {
                Log.w(TAG, "Could not set a specific English voice; keeping en-IN language setting");
            }
        } catch (Exception e) { Log.w(TAG, "Could not choose best installed English voice", e); }
        tts.setSpeechRate(0.88f);
        tts.setPitch(1.0f);
        return true;
    }

    private void startListening() {
        if (stopping || !started || isProcessing || isSpeaking) return;
        if (!ttsReady) { handler.postDelayed(this::startListening, 500L); return; }
        destroyRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Speech recognition unavailable. Enable an Android speech service; retrying…");
            handler.postDelayed(this::startListening, 5000L);
            return;
        }
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { updateStatus("Listening for question or sentence command…"); }
                @Override public void onBeginningOfSpeech() { updateStatus("Listening…"); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { updateStatus("Recognizing speech…"); }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String heard = (matches == null || matches.isEmpty()) ? "" : matches.get(0).trim();
                    destroyRecognizer();
                    // Empty/noisy recognition must not clear the saved Geometry answer.
                    if (heard.isEmpty()) {
                        // Silence, no-match, or an empty recognizer result never changes saved output.
                        handler.postDelayed(VoiceLoopService.this::startListening, 450L);
                    } else if (handleSentenceCommand(heard)) {
                        // Only permitted navigation commands can affect an active answer.
                    } else if (answerLocked) {
                        // Do not replace the active problem while any answer sentences remain.
                        speakControlNotice("This answer is still in progress. Say next sentence to continue, repeat to hear the current sentence again, or previous sentence to replay the preceding one. Ask a different question after the final sentence has finished.");
                    } else if (handleClearlyIncompleteInput(heard)) {
                        // Keep the completed answer available and wait for a complete new problem.
                    } else {
                        awaitingNextQuestion = false;
                        awaitingNextParagraph = false;
                        processQuestion(heard);
                    }
                }
                @Override public void onError(int error) {
                    destroyRecognizer();
                    if (stopping || isProcessing || isSpeaking) return;
                    long delay = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1500L : 800L;
                    updateStatus("Speech recognition reset; listening again…");
                    handler.postDelayed(VoiceLoopService.this::startListening, delay);
                }
            });
            Intent speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            // Allow a 2–3 second thinking/pronunciation pause; finalize after about 3.5–4 seconds of silence.
            speechIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3500L);
            speechIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L);
            recognizer.startListening(speechIntent);
        } catch (Exception e) {
            Log.e(TAG, "Could not start speech recognition", e);
            destroyRecognizer();
            updateStatus("Could not start listening; retrying…");
            handler.postDelayed(this::startListening, 1500L);
        }
    }

    private boolean handleSentenceCommand(String raw) {
        String q = raw == null ? "" : raw.toLowerCase(Locale.ROOT).trim();
        q = q.replaceAll("[.!?,;:]+$", "").replaceAll("\\s+", " ").trim();
        if (q.isEmpty()) return false;

        boolean next = q.matches("(?:please )?(?:next|continue|go on)(?: sentence| line| point)?")
                || q.matches("(?:please )?(?:read|say) (?:the )?next sentence")
                || q.equals("sentence after this") || q.equals("next one");
        if (next) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready yet. Ask a question first.");
            else if (currentSentenceIndex + 1 < answerSentences.size()) {
                currentSentenceIndex++;
                persistSessionState();
                speakCurrentSentence(answerGeneration);
            } else {
                answerLocked = false;
                awaitingNextQuestion = false;
                persistSessionState();
                speakControlNotice("This answer is complete. You can ask your next Geometry question.");
            }
            return true;
        }

        boolean repeatPrevious = q.matches("(?:please )?(?:repeat|replay|read|say) (?:the )?(?:previous|prior) sentence")
                || q.matches("(?:please )?(?:previous|prior) sentence")
                || q.matches("(?:please )?go back (?:one|a) sentence")
                || q.matches("(?:please )?repeat previous")
                || q.matches("(?:please )?previous");
        if (repeatPrevious) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready to replay yet.");
            else if (currentSentenceIndex <= 0) speakControlNotice("This is the first sentence. Say next sentence or repeat.");
            else speakSentenceAt(currentSentenceIndex - 1, answerGeneration, true);
            return true;
        }

        boolean repeatCurrent = q.matches("(?:please )?(?:repeat|again|replay)(?: that| it| this)?")
                || q.matches("(?:please )?(?:repeat|read|say) (?:the )?(?:current|last|same) sentence")
                || q.equals("say it again") || q.equals("read that again") || q.equals("repeat that sentence");
        if (repeatCurrent) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready to repeat. Ask a question first.");
            else speakCurrentSentence(answerGeneration);
            return true;
        }

        Integer requested = parseSentenceNumberCommand(q);
        if (requested != null) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready yet. Ask a question first.");
            else if (requested >= 1 && requested <= answerSentences.size()) {
                speakSentenceAt(requested - 1, answerGeneration, true);
            } else speakControlNotice("That sentence number is not in the current answer. Say a number between one and " + answerSentences.size() + ".");
            return true;
        }

        if (answerLocked) return false;

        Matcher inlineNextQuestion = Pattern.compile("^(?:please )?(?:next|new) question(?:\\s+(?:is|says))?\\s*[:,-]?\\s*(.+)$", Pattern.CASE_INSENSITIVE).matcher(raw == null ? "" : raw.trim());
        if (inlineNextQuestion.matches()) {
            String embeddedQuestion = inlineNextQuestion.group(1) == null ? "" : inlineNextQuestion.group(1).trim();
            if (embeddedQuestion.equalsIgnoreCase("is") || embeddedQuestion.equalsIgnoreCase("says")) embeddedQuestion = "";
            awaitingNextQuestion = true;
            awaitingNextParagraph = false;
            persistSessionState();
            if (embeddedQuestion.isEmpty()) {
                speakControlNotice("Ready. Please say the complete next question.");
            } else if (handleClearlyIncompleteInput(embeddedQuestion)) {
                // Prompt for completion while retaining the prior answer.
            } else {
                processQuestion(embeddedQuestion);
            }
            return true;
        }

        if (q.matches("(?:please )?(?:next question|new question|ask next question|ready for next question)")) {
            // Do not clear the saved answer until a complete new answer has been returned.
            awaitingNextQuestion = true;
            awaitingNextParagraph = false;
            persistSessionState();
            speakControlNotice("Ready. Please say the complete next question.");
            return true;
        }
        return false;
    }

    private boolean handleClearlyIncompleteInput(String raw) {
        if (raw == null) return false;
        String q = raw.toLowerCase(Locale.ROOT).trim().replaceAll("[.!?,;:]+$", "").replaceAll("\\s+", " ");
        if (q.isEmpty()) {
            speakControlNotice("Please say the complete question.");
            return true;
        }

        // Truly clipped interrogatives: do not reject grammatically complete short questions.
        if (q.matches("(?:what|who|where|when|why|how|which)(?:\\s+(?:is|are|was|were|do|does|did|can|could|would|will|should|has|have|had))?")) {
            speakControlNotice("Please say the complete question, including all details and options.");
            return true;
        }
        String last = q.substring(q.lastIndexOf(' ') + 1);
        Set<String> dangling = Set.of("because", "and", "or", "but", "if", "that", "who", "whom", "whose", "which", "what", "when", "where", "why", "how", "is", "are", "was", "were", "do", "does", "did", "has", "have", "had", "can", "could", "would", "will", "should", "to", "of", "for", "from", "with", "in", "on", "at", "by", "the", "an", "complete", "fill", "write", "give", "explain", "find", "because of");
        boolean clippedInstruction = q.matches("(?:please )?(?:complete|fill(?: in)?|write|give|find|explain|state|tell me|change|convert|identify|correct)\\s+(?:the\\s+)?(?:answer|reason|meaning|word|sentence|boxes|web|diagram|following|correct|into|from)?\\s*");
        boolean barePrompt = q.matches("(?:passage|grammar|meaning|tense|voice|punctuation|summary|answer|question|explain|write|complete|correct|translate|pronunciation)");
        if (dangling.contains(last) || clippedInstruction || barePrompt) {
            speakControlNotice("Please say the complete question, including all details and options.");
            return true;
        }
        return false;
    }

    private Integer parseSentenceNumberCommand(String q) {
        String numberText = null;
        Matcher m = Pattern.compile("^(?:please )?(?:repeat|read|say|replay) (?:the )?(?:sentence )?(?:number )?([a-z0-9]+)$").matcher(q);
        if (m.matches()) numberText = m.group(1);
        if (numberText == null) {
            m = Pattern.compile("^(?:please )?(?:sentence|number|line|no) (?:number )?([a-z0-9]+)$").matcher(q);
            if (m.matches()) numberText = m.group(1);
        }
        if (numberText == null && q.matches("[0-9]{1,2}")) numberText = q;
        if (numberText == null && WORD_NUMBERS.containsKey(q)) numberText = q;
        if (numberText == null) return null;
        if (numberText.matches("[0-9]{1,2}")) {
            try { return Integer.parseInt(numberText); } catch (NumberFormatException ignored) { return null; }
        }
        return WORD_NUMBERS.get(numberText);
    }

    private static final Map<String, Integer> WORD_NUMBERS = createWordNumbers();
    private static Map<String, Integer> createWordNumbers() {
        Map<String, Integer> map = new HashMap<>();
        String[] words = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"};
        for (int i = 0; i < words.length; i++) map.put(words[i], i);
        map.put("first", 1); map.put("second", 2); map.put("third", 3); map.put("fourth", 4); map.put("fifth", 5);
        map.put("sixth", 6); map.put("seventh", 7); map.put("eighth", 8); map.put("ninth", 9); map.put("tenth", 10);
        return map;
    }

    private boolean hasAnswer() { return answerSentences != null && !answerSentences.isEmpty() && currentSentenceIndex >= 0; }

    private void processQuestion(String question) {
        if (stopping || isProcessing) return;
        isProcessing = true;
        isSpeaking = false;
        questionCount++;
        updateStatus("Geometry problem " + questionCount + ": preparing answer-sheet steps…");
        final String submittedQuestion = question;
        final String selectedModel = model;
        final String selectedKey = apiKey;
        final String passageAtQuestionTime = activePassage;
        if (networkExecutor == null || networkExecutor.isShutdown()) networkExecutor = Executors.newSingleThreadExecutor();
        networkExecutor.execute(() -> {
            try {
                String answer = requestAnswerWithRetry(selectedKey, selectedModel, submittedQuestion, passageAtQuestionTime);
                String visible = stripMachineMetadata(answer);
                if (isNonAnswerAcknowledgement(visible) || isPassageAcknowledgement(visible)) {
                    Log.w(TAG, "Model returned an acknowledgement instead of solving; retrying with a direct-solution instruction.");
                    String forced = "Solve the following Geometry problem now. Do not classify it, save it, ask for a new question, or describe the topic. Give the actual answer-sheet solution with all required proof or calculation steps, one step per line.\nOriginal problem: " + submittedQuestion;
                    answer = requestAnswerWithRetry(selectedKey, selectedModel, forced, passageAtQuestionTime);
                    visible = stripMachineMetadata(answer);
                }
                final String finalAnswer = answer;
                final String finalVisible = visible;
                handler.post(() -> {
                    if (stopping) return;
                    if (finalAnswer == null || finalAnswer.trim().isEmpty() || isNonAnswerAcknowledgement(finalVisible) || isPassageAcknowledgement(finalVisible)) {
                        playErrorAndResume("I did not receive a worked Geometry solution. Please repeat the complete problem, including all diagram labels and given values.");
                    } else {
                        setAnswerAndSpeak(finalAnswer, submittedQuestion);
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Gemini request failed", e);
                handler.post(() -> { if (!stopping) playErrorAndResume(userFacingError(e)); });
            }
        });
    }

    private String requestAnswerWithRetry(String key, String selectedModel, String question, String passageContext) throws Exception {
        int retryNumber = 0;
        while (true) {
            try { return requestAnswerOnce(key, selectedModel, question, passageContext); }
            catch (HttpApiException e) {
                boolean retryable = e.httpCode == 429 || e.httpCode == 500 || e.httpCode == 502 || e.httpCode == 503 || e.httpCode == 504;
                if (!retryable || retryNumber >= MAX_RETRIES) throw e;
                long delay = 2000L << retryNumber;
                retryNumber++;
                updateStatus("Gemini temporarily unavailable (HTTP " + e.httpCode + "). Retry " + retryNumber + " of " + MAX_RETRIES + " in " + (delay / 1000L) + " seconds…");
                try { Thread.sleep(delay); }
                catch (InterruptedException ex) { Thread.currentThread().interrupt(); throw new Exception("Request cancelled during retry.", ex); }
            }
        }
    }

    private String requestAnswerOnce(String key, String selectedModel, String question, String passageContext) throws Exception {
        String safeModel = selectedModel == null ? "" : selectedModel.trim();
        if (!safeModel.matches("[A-Za-z0-9._-]+")) throw new Exception("Invalid Gemini model ID. Use a valid model ID from Google AI Studio.");
        HttpURLConnection connection = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + safeModel + ":generateContent");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(120000);
            connection.setDoOutput(true);
            connection.setRequestProperty("x-goog-api-key", key);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            JSONObject payload = new JSONObject();
            JSONObject systemInstruction = new JSONObject();
            JSONArray systemParts = new JSONArray();
            systemParts.put(new JSONObject().put("text", INSTRUCTIONS));
            systemInstruction.put("parts", systemParts);
            payload.put("systemInstruction", systemInstruction);

            String userText = "Solve this Maharashtra State Board SSC Class 10 Geometry problem. Give the actual solution, not a subject label or a summary. "
                    + "If a Geometry textbook PDF is attached, inspect it and follow the relevant textbook theorem, formula, or worked-example method when appropriate. "
                    + "The spoken transcript may contain minor speech-recognition mistakes; correct them only when the mathematical meaning is clear. "
                    + "Do not invent diagram labels, values, or assumptions. If critical information is missing, ask one precise clarification. "
                    + "Guide the student exactly what to write on the answer sheet, one complete sentence or one separate proof/calculation step per line. "
                    + "Current spoken Geometry problem:\n" + question + "\n"
                    + "No passage needs to be stored. Output exactly [[VOICE=en-IN]] and [[PASSAGE=UNCHANGED]] first, followed by the complete answer only.";

            JSONArray parts = new JSONArray();
            if (textbookPdfUri != null && !textbookPdfUri.trim().isEmpty()) {
                String uploadedUri = ensureTextbookPdfUploaded(key);
                if (uploadedUri != null && !uploadedUri.trim().isEmpty()) {
                    parts.put(new JSONObject().put("fileData", new JSONObject()
                            .put("mimeType", "application/pdf")
                            .put("fileUri", uploadedUri)));
                }
            }
            parts.put(new JSONObject().put("text", userText));
            JSONArray contents = new JSONArray();
            contents.put(new JSONObject().put("role", "user").put("parts", parts));
            payload.put("contents", contents);
            JSONObject config = new JSONObject();
            config.put("maxOutputTokens", 3072);
            config.put("temperature", 0.12);
            payload.put("generationConfig", config);

            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(body); }
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            String responseText = readStream(stream);
            if (code < 200 || code >= 300) throw makeHttpError(code, responseText);
            JSONObject response = new JSONObject(responseText);
            JSONArray candidates = response.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) throw new Exception("Gemini returned no answer. Ask the geometry problem again.");
            JSONObject candidate = candidates.optJSONObject(0);
            JSONObject content = candidate == null ? null : candidate.optJSONObject("content");
            JSONArray responseParts = content == null ? null : content.optJSONArray("parts");
            StringBuilder output = new StringBuilder();
            if (responseParts != null) {
                for (int i = 0; i < responseParts.length(); i++) {
                    JSONObject part = responseParts.optJSONObject(i);
                    String text = part == null ? "" : part.optString("text", "").trim();
                    if (!text.isEmpty()) { if (output.length() > 0) output.append('\n'); output.append(text); }
                }
            }
            return output.toString().trim();
        } finally { if (connection != null) connection.disconnect(); }
    }

    private String ensureTextbookPdfUploaded(String key) throws Exception {
        if (textbookPdfUri == null || textbookPdfUri.trim().isEmpty()) return "";
        if (textbookPdfUri.equals(uploadedPdfSourceUri) && uploadedPdfUri != null && !uploadedPdfUri.isEmpty()
                && System.currentTimeMillis() - uploadedPdfTimestamp < 42L * 60L * 60L * 1000L) {
            return uploadedPdfUri;
        }
        updateStatus("Uploading Geometry textbook PDF to Gemini…");
        byte[] pdfBytes = readSelectedPdfBytes(textbookPdfUri);
        if (pdfBytes.length == 0) throw new Exception("The selected textbook PDF is empty.");
        if (pdfBytes.length > 45 * 1024 * 1024) throw new Exception("The PDF is larger than 45 MB. Choose a smaller file.");
        String uploadUrl = beginPdfUpload(key, pdfBytes.length);
        String remoteUri = finishPdfUpload(uploadUrl, pdfBytes, key);
        if (remoteUri == null || remoteUri.trim().isEmpty()) throw new Exception("The PDF uploaded, but Gemini did not return a file reference.");
        uploadedPdfUri = remoteUri;
        uploadedPdfSourceUri = textbookPdfUri;
        uploadedPdfTimestamp = System.currentTimeMillis();
        persistSessionState();
        updateStatus("Geometry textbook PDF is ready. Solving the problem…");
        return remoteUri;
    }

    private byte[] readSelectedPdfBytes(String uriString) throws Exception {
        ContentResolver resolver = getContentResolver();
        try (InputStream in = resolver.openInputStream(Uri.parse(uriString));
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception("Could not open the selected PDF. Please select it again.");
            byte[] buffer = new byte[8192];
            int total = 0;
            int count;
            while ((count = in.read(buffer)) != -1) {
                total += count;
                if (total > 45 * 1024 * 1024) throw new Exception("The PDF is larger than 45 MB. Choose a smaller file.");
                out.write(buffer, 0, count);
            }
            return out.toByteArray();
        }
    }

    private String beginPdfUpload(String key, int byteCount) throws Exception {
        HttpURLConnection connection = null;
        try {
            String encodedKey = URLEncoder.encode(key, "UTF-8");
            URL url = new URL("https://generativelanguage.googleapis.com/upload/v1beta/files?key=" + encodedKey);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(30000);
            connection.setDoOutput(true);
            connection.setRequestProperty("X-Goog-Upload-Protocol", "resumable");
            connection.setRequestProperty("X-Goog-Upload-Command", "start");
            connection.setRequestProperty("X-Goog-Upload-Header-Content-Length", String.valueOf(byteCount));
            connection.setRequestProperty("X-Goog-Upload-Header-Content-Type", "application/pdf");
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] metadata = new JSONObject().put("file", new JSONObject().put("display_name", "Maharashtra_SSC_Class_10_Geometry_Textbook.pdf"))
                    .toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(metadata.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(metadata); }
            int code = connection.getResponseCode();
            String response = readStream(code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream());
            if (code < 200 || code >= 300) throw makeHttpError(code, response);
            String uploadUrl = connection.getHeaderField("X-Goog-Upload-URL");
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) uploadUrl = connection.getHeaderField("x-goog-upload-url");
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) {
                Map<String, java.util.List<String>> headers = connection.getHeaderFields();
                if (headers != null) for (Map.Entry<String, java.util.List<String>> h : headers.entrySet()) {
                    if (h.getKey() != null && "x-goog-upload-url".equalsIgnoreCase(h.getKey()) && h.getValue() != null && !h.getValue().isEmpty()) {
                        uploadUrl = h.getValue().get(0); break;
                    }
                }
            }
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) throw new Exception("Gemini did not return a PDF upload URL.");
            return uploadUrl.trim();
        } finally { if (connection != null) connection.disconnect(); }
    }

    private String finishPdfUpload(String uploadUrl, byte[] pdfBytes, String key) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(uploadUrl).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(90000);
            connection.setDoOutput(true);
            connection.setRequestProperty("X-Goog-Upload-Offset", "0");
            connection.setRequestProperty("X-Goog-Upload-Command", "upload, finalize");
            connection.setRequestProperty("Content-Type", "application/pdf");
            connection.setFixedLengthStreamingMode(pdfBytes.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(pdfBytes); }
            int code = connection.getResponseCode();
            String response = readStream(code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream());
            if (code < 200 || code >= 300) throw makeHttpError(code, response);
            JSONObject root = new JSONObject(response);
            JSONObject file = root.optJSONObject("file");
            if (file == null) file = root;
            String uri = file.optString("uri", "").trim();
            String name = file.optString("name", "").trim();
            if (uri.isEmpty()) throw new Exception("Gemini did not return the uploaded PDF URI.");
            if (!name.isEmpty()) waitForPdfProcessing(name, key);
            return uri;
        } finally { if (connection != null) connection.disconnect(); }
    }

    // Gemini can return a file reference before PDF processing is complete.
    // Poll its metadata before using the URI in a generateContent request.
    private void waitForPdfProcessing(String fileName, String key) throws Exception {
        if (!fileName.matches("files/[A-Za-z0-9_-]+")) throw new Exception("Gemini returned an invalid PDF file reference.");
        long deadline = System.currentTimeMillis() + 90000L;
        String state = "PROCESSING";
        while ("PROCESSING".equalsIgnoreCase(state) && System.currentTimeMillis() < deadline) {
            try { Thread.sleep(2000L); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new Exception("PDF processing was interrupted.", e); }
            HttpURLConnection metadataConnection = null;
            try {
                URL metadataUrl = new URL("https://generativelanguage.googleapis.com/v1beta/" + fileName);
                metadataConnection = (HttpURLConnection) metadataUrl.openConnection();
                metadataConnection.setRequestMethod("GET");
                metadataConnection.setConnectTimeout(20000);
                metadataConnection.setReadTimeout(30000);
                metadataConnection.setRequestProperty("x-goog-api-key", key);
                int metadataCode = metadataConnection.getResponseCode();
                String metadataText = readStream(metadataCode >= 200 && metadataCode < 300 ? metadataConnection.getInputStream() : metadataConnection.getErrorStream());
                if (metadataCode < 200 || metadataCode >= 300) throw makeHttpError(metadataCode, metadataText);
                JSONObject metadata = new JSONObject(metadataText);
                state = metadata.optString("state", "").trim().toUpperCase(Locale.ROOT);
                if ("FAILED".equals(state)) throw new Exception("Gemini could not process the selected textbook PDF. Try a clearer or smaller PDF.");
                if (state.isEmpty() || "ACTIVE".equals(state)) return;
            } finally { if (metadataConnection != null) metadataConnection.disconnect(); }
        }
        if ("PROCESSING".equalsIgnoreCase(state)) throw new Exception("The textbook PDF is still processing. Please try the Geometry problem again in a moment.");
        if (!state.isEmpty() && !"ACTIVE".equalsIgnoreCase(state)) throw new Exception("The textbook PDF is not ready (" + state + "). Please select it again or continue without the PDF.");
    }

    private String applyPassageMarker(String response, String submittedQuestion) {
        if (response == null) return "UNCHANGED";
        Matcher matcher = Pattern.compile("(?m)^\\s*\\[\\[PASSAGE=(STORE_CURRENT_INPUT|APPEND_CURRENT_INPUT|CLEAR|UNCHANGED)\\]\\]\\s*$", Pattern.CASE_INSENSITIVE).matcher(response);
        if (!matcher.find()) return "UNCHANGED";
        String value = matcher.group(1) == null ? "UNCHANGED" : matcher.group(1).trim().toUpperCase(Locale.ROOT);
        if ("STORE_CURRENT_INPUT".equals(value)) {
            String incoming = submittedQuestion == null ? "" : submittedQuestion.trim();
            if (activePassage == null || activePassage.trim().isEmpty()) {
                activePassage = incoming;
                persistSessionState();
                Log.i(TAG, "Initial question-paper passage stored; characters=" + activePassage.length());
            } else {
                // Geometry input is never stored as passage text.
                Log.i(TAG, "Ignored unintended passage replacement because an active passage is already locked.");
                value = "UNCHANGED";
            }
        } else if ("APPEND_CURRENT_INPUT".equals(value)) {
            String addition = submittedQuestion == null ? "" : submittedQuestion.trim();
            String lowerAddition = addition.toLowerCase(Locale.ROOT);
            boolean explicitContinuation = lowerAddition.matches("(?s)^(?:please )?(?:continue|append) (?:the )?passage.*")
                    || lowerAddition.matches("(?s)^next part of (?:the )?passage.*");
            if (explicitContinuation && !addition.isEmpty()) {
                String continuationText = addition.replaceFirst("(?i)^(?:please )?(?:continue|append) (?:the )?passage\\s*[:,-]?\\s*", "")
                        .replaceFirst("(?i)^next part of (?:the )?passage\\s*[:,-]?\\s*", "").trim();
                if (!continuationText.isEmpty()) {
                    activePassage = activePassage == null || activePassage.trim().isEmpty()
                            ? continuationText : activePassage.trim() + " " + continuationText;
                    persistSessionState();
                }
                Log.i(TAG, "Explicit question-paper passage continuation appended; characters=" + (activePassage == null ? 0 : activePassage.length()));
            } else {
                Log.i(TAG, "Ignored unintended passage append because no explicit continuation command was given.");
                value = "UNCHANGED";
            }
        } else if ("CLEAR".equals(value)) {
            activePassage = "";
            persistSessionState();
            Log.i(TAG, "Question-paper passage cleared");
        }
        return value;
    }

    private String stripMachineMetadata(String answer) {
        if (answer == null) return "";
        return answer.replaceAll("(?m)^\\s*\\[\\[(?:VOICE|PASSAGE)=.*?\\]\\]\\s*$", "").trim();
    }

    private boolean isPassageAcknowledgement(String answer) {
        String normalized = answer == null ? "" : answer.trim().replaceAll("\\s+", " ");
        return normalized.matches("(?i)(?:(?:the )?(?:new )?passage (?:has been )?(?:successfully )?(?:saved|stored|updated)(?:[.! ]+.*)?|please read the passage(?: from the question paper)? first)[.! ]*");
    }


    private boolean isNonAnswerAcknowledgement(String answer) {
        String value = answer == null ? "" : answer.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
        if (value.isEmpty()) return true;
        if (value.matches("(?is)^(?:your )?question (?:has been )?(?:saved|stored)(?:[.! ]+.*)?$")) return true;
        if (value.matches("(?is)^(?:please )?(?:say|tell me|ask) (?:a |the |your )?(?:new |next )?question[.! ]*$")) return true;
        if (value.matches("(?is)^(?:this is|that is) (?:a |an )?(?:geometry|mathematics|maths) question[.! ]*$")) return true;
        if (value.matches("(?is)^(?:the )?(?:topic|subject) (?:is|appears to be) (?:geometry|mathematics|maths)[.! ]*$")) return true;
        if (value.matches("(?is)^(?:i have|i've) saved (?:your )?question[.! ]*$")) return true;
        return false;
    }

    private void setAnswerAndSpeak(String rawAnswer, String answeredQuestion) {
        ArrayList<String> parsed = splitAnswerIntoSentences(rawAnswer);
        if (parsed.isEmpty()) { playErrorAndResume("Gemini returned an empty answer. Please ask again."); return; }
        answerSentences = parsed;
        currentSentenceIndex = 0;
        lastAnsweredQuestion = answeredQuestion == null ? "" : answeredQuestion.trim();
        awaitingNextQuestion = false;
        answerLocked = true;
        answerGeneration++;
        persistSessionState();
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Speaking sentence 1 of " + answerSentences.size() + ". Say 'next sentence' to continue.");
        speakCurrentSentence(answerGeneration);
    }

    private ArrayList<String> splitAnswerIntoSentences(String rawAnswer) {
        ArrayList<String> result = new ArrayList<>();
        if (rawAnswer == null) return result;
        String clean = rawAnswer.replaceAll("(?m)^\\s*\\[\\[(?:VOICE|PASSAGE)=.*?\\]\\]\\s*$", "")
                .replace("```", "").replace("**", "").replace("__", "").replace("*", "").replace("`", "").trim();
        if (clean.isEmpty()) return result;
        String[] lines = clean.split("\\r?\\n");
        Pattern numberedLine = Pattern.compile("^\\s*(?:sentence\\s*)?(\\d{1,2})\\s*[.):-]\\s*(.+?)\\s*$", Pattern.CASE_INSENSITIVE);
        int numberedCount = 0;
        for (String line : lines) if (numberedLine.matcher(line.trim()).matches()) numberedCount++;
        if (numberedCount > 0) {
            for (String original : lines) {
                String line = original.trim();
                if (line.isEmpty()) continue;
                Matcher m = numberedLine.matcher(line);
                if (m.matches()) line = m.group(2).trim();
                else line = line.replaceFirst("^(?:[-•]+|[A-Z][.)])\\s*", "").trim();
                addSentenceFragments(result, line);
            }
        } else {
            for (String original : lines) {
                String line = original.trim().replaceFirst("^(?:[-•]+)\\s*", "").trim();
                if (!line.isEmpty()) addSentenceFragments(result, line);
            }
        }
        return result;
    }

    private void addSentenceFragments(ArrayList<String> target, String line) {
        if (line == null || line.trim().isEmpty()) return;
        BreakIterator iterator = BreakIterator.getSentenceInstance(Locale.US);
        iterator.setText(line.trim());
        int start = iterator.first();
        for (int end = iterator.next(); end != BreakIterator.DONE; start = end, end = iterator.next()) {
            String part = line.trim().substring(start, end).trim();
            if (!part.isEmpty()) target.add(part);
        }
    }

    private void speakCurrentSentence(long generation) {
        speakSentenceAt(currentSentenceIndex, generation, false);
    }

    // A replay uses its own utterance ID and does not move the progress pointer.
    // This means "next sentence" still continues from the point where the student paused.
    private void speakSentenceAt(int sentenceIndex, long generation, boolean preserveProgress) {
        if (stopping || generation != answerGeneration) return;
        if (answerSentences == null || sentenceIndex < 0 || sentenceIndex >= answerSentences.size()) {
            isSpeaking = false;
            startListening();
            return;
        }
        if (tts == null || !ttsReady || !configureEnglishVoice()) {
            isSpeaking = false;
            updateStatus("English voice unavailable. Check speech settings.");
            handler.postDelayed(this::startListening, 1000L);
            return;
        }
        isSpeaking = true;
        String text = "Sentence " + (sentenceIndex + 1) + ". " + answerSentences.get(sentenceIndex);
        String prefix = preserveProgress ? "replay_" : "sentence_";
        String utteranceId = prefix + generation + "_" + sentenceIndex;
        updateStatus((preserveProgress ? "Replaying sentence " : "Speaking sentence ")
                + (sentenceIndex + 1) + " of " + answerSentences.size() + "…");
        int spoken = tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), utteranceId);
        if (spoken == TextToSpeech.ERROR) {
            isSpeaking = false;
            updateStatus("Could not speak this sentence. Try repeating its sentence number.");
            handler.postDelayed(this::startListening, 500L);
        }
    }

    private void speakControlNotice(String message) {
        if (stopping) return;
        if (tts == null || !ttsReady || !configureEnglishVoice()) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 500L);
            return;
        }
        isSpeaking = true;
        String id = "notice_" + answerGeneration + "_" + System.currentTimeMillis();
        updateStatus("Speaking instruction…");
        int spoken = tts.speak(message, TextToSpeech.QUEUE_FLUSH, new Bundle(), id);
        if (spoken == TextToSpeech.ERROR) { isSpeaking = false; handler.postDelayed(this::startListening, 500L); }
    }

    private void handleUtteranceDone(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("replay_")) {
            String[] bits = utteranceId.split("_");
            if (bits.length >= 3) {
                try {
                    long generation = Long.parseLong(bits[1]);
                    int replayedIndex = Integer.parseInt(bits[2]);
                    if (generation != answerGeneration || replayedIndex < 0 || replayedIndex >= answerSentences.size()) return;
                } catch (NumberFormatException ignored) { return; }
            }
            isSpeaking = false;
            isProcessing = false;
            updateStatus(answerLocked
                    ? "Replayed. Current answer remains locked. Say next sentence, repeat, or previous sentence."
                    : "Replayed. The answer is complete; you may ask another Geometry question.");
            startListening();
            return;
        }
        if (utteranceId.startsWith("sentence_")) {
            String[] bits = utteranceId.split("_");
            if (bits.length >= 3) {
                try {
                    long generation = Long.parseLong(bits[1]);
                    int sentenceIndex = Integer.parseInt(bits[2]);
                    if (generation != answerGeneration || sentenceIndex != currentSentenceIndex) return;
                } catch (NumberFormatException ignored) { return; }
            }
            isSpeaking = false;
            isProcessing = false;
            if (currentSentenceIndex >= answerSentences.size() - 1) {
                answerLocked = false;
                awaitingNextQuestion = false;
                persistSessionState();
                updateStatus("Answer complete. You may ask the next Geometry question.");
            } else {
                answerLocked = true;
                persistSessionState();
                updateStatus("Sentence " + (currentSentenceIndex + 1) + " read. Answer locked. Say 'next sentence', 'repeat', or 'previous sentence'.");
            }
            startListening();
            return;
        }
        if (utteranceId.startsWith("notice_") || utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            updateStatus("Listening for your next instruction…");
            handler.postDelayed(this::startListening, 200L);
        }
    }

    private void handleUtteranceFinishedWithError(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("sentence_") || utteranceId.startsWith("replay_") || utteranceId.startsWith("notice_") || utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            updateStatus("Speech playback ended. Listening again…");
            handler.postDelayed(this::startListening, 500L);
        }
    }

    private void playErrorAndResume(String message) {
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Question could not be answered; speaking a short notice.");
        speakControlNotice(errorMessageInEnglish(message));
    }

    private String errorMessageInEnglish(String message) {
        String value = message == null ? "" : message.toLowerCase(Locale.ROOT);
        if (value.contains("503") || value.contains("temporarily busy") || value.contains("unavailable")) return "The AI service is temporarily unavailable. Please try again shortly.";
        if (value.contains("429") || value.contains("quota") || value.contains("request limit")) return "The free usage limit may have been reached. Please wait before trying again.";
        if (value.contains("401") || value.contains("403") || value.contains("api key") || value.contains("authorize")) return "Please check the Gemini API key and its permissions.";
        if (value.contains("400") || value.contains("model name") || value.contains("model id")) return "Please check the Gemini model name and request settings.";
        return "I could not get an answer. Check your internet connection and API key, then ask again.";
    }

    private HttpApiException makeHttpError(int code, String responseText) {
        String message = "";
        try { JSONObject err = new JSONObject(responseText).optJSONObject("error"); if (err != null) message = err.optString("message", "").trim(); }
        catch (Exception ignored) { }
        return new HttpApiException(code, message);
    }

    private String userFacingError(Exception e) {
        if (e instanceof HttpApiException) {
            HttpApiException apiError = (HttpApiException) e;
            if (apiError.httpCode == 503) return "The AI server is temporarily busy (HTTP 503) after retries. Please try again later.";
            if (apiError.httpCode == 429) return "The free-tier quota or request limit was reached (HTTP 429). Wait before asking again.";
            if (apiError.httpCode == 400) return "The AI rejected the request (HTTP 400). Check the model name.";
            if (apiError.httpCode == 401 || apiError.httpCode == 403) return "The API key could not be authorized (HTTP " + apiError.httpCode + "). Check the key and API access.";
            if (apiError.httpCode >= 500) return "The AI server is unavailable (HTTP " + apiError.httpCode + ") after retries. Please try again later.";
            return "AI request failed with HTTP " + apiError.httpCode + (apiError.apiMessage.isEmpty() ? "." : ". " + abbreviate(apiError.apiMessage, 130));
        }
        String reason = e.getMessage();
        return (reason == null || reason.trim().isEmpty()) ? "I could not get an answer. Check internet access and your Gemini API settings." : abbreviate(reason, 210);
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private String abbreviate(String text, int max) { if (text == null) return ""; return text.length() <= max ? text : text.substring(0, max) + "…"; }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getPackageName() + ":GeometryAnswerTeller");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(SESSION_LIMIT_MS + 30000L);
            }
        } catch (Exception e) { Log.w(TAG, "Could not acquire wakelock", e); }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Geometry Answer Teller session", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows Geometry listening and sentence-by-sentence answer status, with a Stop action.");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String status) {
        Intent stopIntent = new Intent(this, VoiceLoopService.class);
        stopIntent.setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 992, stopIntent, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Geometry Answer Teller active")
                .setContentText(status)
                .setStyle(new Notification.BigTextStyle().bigText(status))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "STOP", stopPendingIntent).build());
        return builder.build();
    }

    private void updateStatus(String status) {
        if (stopping || notificationManager == null) return;
        try { notificationManager.notify(NOTIFICATION_ID, buildNotification(status)); }
        catch (Exception e) { Log.w(TAG, "Could not update notification", e); }
    }

    private void stopLoop() {
        if (stopping) { stopSelf(); return; }
        stopping = true;
        started = false;
        answerGeneration++;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) { try { tts.stop(); } catch (Exception ignored) { } try { tts.shutdown(); } catch (Exception ignored) { } tts = null; }
        ttsReady = false;
        if (networkExecutor != null) { networkExecutor.shutdownNow(); networkExecutor = null; }
        if (wakeLock != null && wakeLock.isHeld()) { try { wakeLock.release(); } catch (Exception ignored) { } }
        wakeLock = null;
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override public void onDestroy() { if (!stopping) stopLoop(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }

    private static class HttpApiException extends Exception {
        final int httpCode;
        final String apiMessage;
        HttpApiException(int httpCode, String apiMessage) {
            super("Gemini HTTP " + httpCode + (apiMessage == null || apiMessage.isEmpty() ? "" : ": " + apiMessage));
            this.httpCode = httpCode;
            this.apiMessage = apiMessage == null ? "" : apiMessage;
        }
    }
}
