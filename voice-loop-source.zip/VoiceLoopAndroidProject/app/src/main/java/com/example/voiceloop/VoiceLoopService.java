package com.example.voiceloop;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VoiceLoopService extends Service {
    public static final String ACTION_START = "com.example.voiceloop.START";
    public static final String ACTION_STOP = "com.example.voiceloop.STOP";
    public static final String EXTRA_API_KEY = "api_key";
    public static final String EXTRA_MODEL = "model";
    public static final String EXTRA_LANGUAGE = "language";
    public static final String EXTRA_TEXTBOOK_URI = "textbook_uri";

    private static final String TAG = "SanskritAnswerTeller";
    private static final String CHANNEL_ID = "sanskrit_answer_teller_session";
    private static final int NOTIFICATION_ID = 2461;
    private static final long SESSION_LIMIT_MS = 6L * 60L * 60L * 1000L;
    private static final long WORD_PAUSE_MS = 4000L;
    private static final int MAX_RETRIES = 3;
    private static final long MAX_PDF_BYTES = 50L * 1024L * 1024L;

    private static final String INSTRUCTIONS =
            "You are an expert Maharashtra State Board SSC Class 10 Sanskrit teacher, Sanskrit grammar specialist, textbook researcher, and board-examination answer writer. Solve spoken questions as a top-performing student would write them. PRIMARY TASK: Maharashtra SSC Sanskrit PYQs. If an attached PDF is present, treat it as the primary textbook reference for lesson names, characters, events, poem/verse text, vocabulary, grammar tables and prescribed exercises. Check the PDF before making textbook-specific claims; do not invent quotations, verse lines, story events, or forms. If the answer cannot be verified from the PDF, use only a well-supported grammatical inference and do not pretend you found it in the book. If no PDF is attached, answer with reliable Sanskrit grammar and make no claim that you checked a textbook.\n" +
            "STRICT ANSWER-LANGUAGE RULES (follow this priority order; do not choose Marathi just because the question is about a story or chapter): " +
            "(1) An explicit instruction about the LANGUAGE OF THE ANSWER always wins, even when that instruction itself is spoken in Sanskrit. If the user says मातृभाषया / मातृभाषायाम् / मातृभाषायां लिखत, or asks to write the answer in the mother tongue, answer in Marathi (the expected Maharashtra SSC mother tongue) using clear Devanagari. Also use Marathi for explicit instructions such as मराठीत उत्तर द्या, मराठी भाषेत अर्थ लिहा, or अर्थं मराठीभाषया लिखत. " +
            "(2) Otherwise, if the question or instruction is in Sanskrit, answer in Sanskrit by default. This includes lesson/story comprehension, questions about characters or events, prose and poetry questions, संस्कृतेन उत्तरत/लिखत, grammar (सन्धि, समास, विभक्ति, शब्दरूप, धातुरूप, लकार, प्रयोग, वाक्यरचना), vocabulary, fill-in-the-blanks, sentence formation, and Sanskrit translation. Use grammatical Sanskrit in Devanagari, not Marathi, Hindi, or English. " +
            "(3) If the question is spoken in Marathi, Hindi, or English but asks for a Sanskrit textbook/grammar answer and does not explicitly request a mother-tongue explanation, answer in Sanskrit by default. The language used to speak the question and the speech-recognition language do NOT determine the output language. " +
            "(4) Use Marathi only when Marathi/mother-tongue output is explicitly requested, or when the task clearly asks for meaning/explanation in Marathi. Use Hindi or English only when explicitly requested. For ambiguous questions from a Sanskrit lesson, prefer Sanskrit rather than Marathi. " +
            "For Marathi-to-Sanskrit translation, preserve meaning and use correct cases, gender, number, person, tense and agreement. For grammar, verify the requested form instead of guessing. For poetry, preserve the exact textbook verse when available.\n" +
            "EXAM FORMAT: answer the spoken question directly, not with advice. Keep answer length medium and appropriate to marks. One-mark factual answers should be exact and short. Two-mark answers should give the needed complete fact/reason, usually one or two sentences. Questions asking for explanation, स्वमत, a story incident, or a poetry meaning usually need about 3–5 concise, relevant sentences unless a different length is specified. Essays must follow the asked sentence count. For fill-in blanks, return the exact form and the complete sentence when requested. For diagrams or tables, explicitly say each box/row/column placement. Preserve any question number spoken by the user. Do not answer unused alternatives unless asked. No irrelevant introduction, encouragement, markdown, or unsupported details.\n" +
            "IMPORTANT OUTPUT PROTOCOL: the first line must be exactly one voice marker: [[VOICE=sa-IN]] for an answer written in Sanskrit, [[VOICE=mr-IN]] for Marathi, [[VOICE=hi-IN]] for Hindi, or [[VOICE=en-IN]] for English. Then place the answer on the next line. The marker is for the app and must not be part of the answer. Pick the marker according to the language of the actual answer. The spoken answer should be clearly worded and easy to follow. Provide only the final answer, not your reasoning or sources.";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService networkExecutor;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;
    private String apiKey;
    private String model = "gemini-3.5-flash-lite";
    private String recognitionLanguageTag = "hi-IN";
    private String textbookUriString;
    private String cachedGeminiTextbookUri;
    private String[] answerWords = new String[0];
    private int wordIndex = 0;
    private int questionCount = 0;
    private long answerGeneration = 0L;
    private boolean ttsReady = false;
    private boolean isProcessing = false;
    private boolean isSpeaking = false;
    private boolean stopping = false;
    private boolean started = false;
    private NotificationManager notificationManager;

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();
        networkExecutor = Executors.newSingleThreadExecutor();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopLoop();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        apiKey = intent.getStringExtra(EXTRA_API_KEY);
        model = intent.getStringExtra(EXTRA_MODEL);
        recognitionLanguageTag = intent.getStringExtra(EXTRA_LANGUAGE);
        textbookUriString = intent.getStringExtra(EXTRA_TEXTBOOK_URI);
        if (apiKey == null || apiKey.trim().isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (model == null || model.trim().isEmpty()) model = "gemini-3.5-flash-lite";
        if (recognitionLanguageTag == null || recognitionLanguageTag.trim().isEmpty()) recognitionLanguageTag = "hi-IN";

        started = true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                        | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
                startForeground(NOTIFICATION_ID, buildNotification("Starting Sanskrit Answer Teller…"), types);
            } else {
                startForeground(NOTIFICATION_ID, buildNotification("Starting Sanskrit Answer Teller…"));
            }
        } catch (SecurityException | IllegalArgumentException ex) {
            Log.e(TAG, "Could not start foreground service", ex);
            stopLoop();
            return START_NOT_STICKY;
        }

        acquireWakeLock();
        handler.postDelayed(this::stopLoop, SESSION_LIMIT_MS);
        initialiseTts();
        updateStatus("Preparing Hindi voice and speech recognition…");
        return START_NOT_STICKY;
    }

    private void initialiseTts() {
        tts = new TextToSpeech(getApplicationContext(), status -> handler.post(() -> {
            if (stopping) return;
            if (status != TextToSpeech.SUCCESS || tts == null) {
                updateStatus("Text-to-speech could not start. Check Android text-to-speech settings.");
                handler.postDelayed(this::initialiseTts, 3000L);
                return;
            }
            tts.setSpeechRate(0.72f);
            tts.setPitch(0.98f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) {
                    handler.post(() -> handleUtteranceDone(utteranceId));
                }
                @Override public void onError(String utteranceId) {
                    handler.post(() -> handleUtteranceFinishedWithError(utteranceId));
                }
                @Override public void onError(String utteranceId, int errorCode) {
                    handler.post(() -> handleUtteranceFinishedWithError(utteranceId));
                }
            });
            // Hindi is a useful initial fallback for Devanagari Sanskrit if a Sanskrit voice is absent.
            configureVoice("hi-IN", true);
            ttsReady = true;
            updateStatus("Ready. Listening for question 1…");
            startListening();
        }));
    }

    private void configureVoice(String requestedTag, boolean initial) {
        if (tts == null) return;
        String tag = requestedTag == null ? "hi-IN" : requestedTag;
        Locale locale = Locale.forLanguageTag(tag);
        int result = tts.setLanguage(locale);
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            if ("sa-IN".equals(tag) || "mr-IN".equals(tag)) {
                tag = "hi-IN";
                result = tts.setLanguage(Locale.forLanguageTag(tag));
            }
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tag = "en-IN";
                result = tts.setLanguage(Locale.forLanguageTag(tag));
            }
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tag = "en-US";
                tts.setLanguage(Locale.US);
            }
        }
        // Prefer a high-quality installed voice for the chosen language when one is available.
        try {
            Set<Voice> voices = tts.getVoices();
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            if (voices != null) {
                for (Voice voice : voices) {
                    if (!voice.getLocale().getLanguage().equals(Locale.forLanguageTag(tag).getLanguage())) continue;
                    int score = voice.getQuality();
                    if (voice.isNetworkConnectionRequired()) score -= 5;
                    if (score > bestScore) { bestScore = score; best = voice; }
                }
            }
            if (best != null) tts.setVoice(best);
        } catch (Exception e) {
            Log.w(TAG, "Could not select a specific TTS voice", e);
        }
        tts.setSpeechRate(0.72f);
        tts.setPitch(0.98f);
        if (initial && ("en-IN".equals(tag) || "en-US".equals(tag))) {
            updateStatus("Hindi voice data is unavailable; using an installed fallback voice.");
        }
    }

    private void startListening() {
        if (stopping || !started || isProcessing || isSpeaking) return;
        if (!ttsReady) {
            handler.postDelayed(this::startListening, 500L);
            return;
        }
        destroyRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Speech recognition unavailable. Enable an Android speech service; retrying…");
            handler.postDelayed(this::startListening, 5000L);
            return;
        }
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { updateStatus("Listening for question " + (questionCount + 1) + "…"); }
                @Override public void onBeginningOfSpeech() { updateStatus("Hearing your question…"); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { updateStatus("Transcribing question…"); }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null
                            : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String question = (matches == null || matches.isEmpty()) ? "" : matches.get(0).trim();
                    destroyRecognizer();
                    if (question.isEmpty()) {
                        handler.postDelayed(VoiceLoopService.this::startListening, 700L);
                    } else {
                        processQuestion(question);
                    }
                }

                @Override
                public void onError(int error) {
                    destroyRecognizer();
                    if (stopping || isProcessing || isSpeaking) return;
                    long retryDelay = (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) ? 1800L : 1000L;
                    updateStatus("Speech recognition reset; listening again…");
                    handler.postDelayed(VoiceLoopService.this::startListening, retryDelay);
                }
            });

            Intent speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, recognitionLanguageTag);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, recognitionLanguageTag);
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            recognizer.startListening(speechIntent);
        } catch (Exception e) {
            Log.e(TAG, "Could not start speech recognition", e);
            destroyRecognizer();
            updateStatus("Could not start listening; retrying…");
            handler.postDelayed(this::startListening, 1800L);
        }
    }

    private void processQuestion(String question) {
        if (stopping || isProcessing) return;
        isProcessing = true;
        isSpeaking = false;
        questionCount++;
        updateStatus("Question " + questionCount + ": checking textbook and asking Gemini…");
        final String submittedQuestion = question;
        final String selectedModel = model;
        final String selectedKey = apiKey;
        if (networkExecutor == null || networkExecutor.isShutdown()) networkExecutor = Executors.newSingleThreadExecutor();
        networkExecutor.execute(() -> {
            try {
                String answer = requestAnswerWithRetry(selectedKey, selectedModel, submittedQuestion);
                handler.post(() -> {
                    if (stopping) return;
                    if (answer == null || answer.trim().isEmpty()) {
                        playErrorAndResume("Gemini returned an empty answer. Please ask that question again.");
                    } else {
                        speakAnswerWordByWord(answer);
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Gemini request failed", e);
                handler.post(() -> {
                    if (stopping) return;
                    String reason = userFacingError(e);
                    updateStatus("Request failed: " + abbreviate(reason, 150));
                    playErrorAndResume(reason);
                });
            }
        });
    }

    private String requestAnswerWithRetry(String key, String selectedModel, String question) throws Exception {
        int retryNumber = 0;
        while (true) {
            try {
                return requestAnswerOnce(key, selectedModel, question);
            } catch (HttpApiException e) {
                boolean retryable = e.httpCode == 429 || e.httpCode == 500 || e.httpCode == 502
                        || e.httpCode == 503 || e.httpCode == 504;
                if (!retryable || retryNumber >= MAX_RETRIES) throw e;
                long delay = 2000L << retryNumber; // 2, 4, then 8 seconds
                retryNumber++;
                updateStatus("Gemini temporarily unavailable (HTTP " + e.httpCode + "). Retry "
                        + retryNumber + " of " + MAX_RETRIES + " in " + (delay / 1000L) + " seconds…");
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw new Exception("Request cancelled while waiting to retry.", interrupted);
                }
            }
        }
    }

    private String requestAnswerOnce(String key, String selectedModel, String question) throws Exception {
        String safeModel = selectedModel == null ? "" : selectedModel.trim();
        if (!safeModel.matches("[A-Za-z0-9._-]+")) {
            throw new Exception("Invalid Gemini model ID. Use gemini-3.5-flash-lite.");
        }
        if (textbookUriString != null && !textbookUriString.trim().isEmpty()
                && (cachedGeminiTextbookUri == null || cachedGeminiTextbookUri.isEmpty())) {
            updateStatus("Uploading Sanskrit textbook to Gemini for this session…");
            cachedGeminiTextbookUri = uploadTextbookToGemini(key, textbookUriString);
            updateStatus("Textbook ready. Preparing your answer…");
        }

        HttpURLConnection connection = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + safeModel + ":generateContent");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(90000);
            connection.setDoOutput(true);
            connection.setRequestProperty("x-goog-api-key", key);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            JSONObject payload = new JSONObject();
            JSONObject systemInstruction = new JSONObject();
            JSONArray systemParts = new JSONArray();
            systemParts.put(new JSONObject().put("text", INSTRUCTIONS));
            systemInstruction.put("parts", systemParts);
            payload.put("systemInstruction", systemInstruction);

            JSONArray contents = new JSONArray();
            JSONObject userContent = new JSONObject();
            userContent.put("role", "user");
            JSONArray userParts = new JSONArray();
            if (cachedGeminiTextbookUri != null && !cachedGeminiTextbookUri.isEmpty()) {
                JSONObject fileData = new JSONObject();
                fileData.put("mimeType", "application/pdf");
                fileData.put("fileUri", cachedGeminiTextbookUri);
                userParts.put(new JSONObject().put("fileData", fileData));
            }
            userParts.put(new JSONObject().put("text",
                    "Solve this Maharashtra SSC Class 10 Sanskrit textbook/PYQ question. Apply the system's STRICT ANSWER-LANGUAGE RULES exactly: unless the speaker explicitly asks for Marathi/mother tongue (for example, मातृभाषया लिखत), answer a Sanskrit question or Sanskrit lesson/grammar exercise in Sanskrit. An explicit request for mother tongue means Marathi, even if the request is spoken in Sanskrit. Do not answer in Marathi merely because the question concerns a chapter, story, or character. The question's spoken language and recognition locale are not output-language instructions.\nQUESTION: " + question));
            userContent.put("parts", userParts);
            contents.put(userContent);
            payload.put("contents", contents);

            JSONObject generationConfig = new JSONObject();
            generationConfig.put("maxOutputTokens", 320);
            generationConfig.put("temperature", 0.15);
            payload.put("generationConfig", generationConfig);

            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(body); }

            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            String responseText = readStream(stream);
            if (code < 200 || code >= 300) throw makeHttpError(code, responseText);

            JSONObject response = new JSONObject(responseText);
            JSONArray candidates = response.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) {
                throw new Exception("Gemini returned no answer. Check the question and try again.");
            }
            JSONObject candidate = candidates.optJSONObject(0);
            JSONObject content = candidate == null ? null : candidate.optJSONObject("content");
            JSONArray parts = content == null ? null : content.optJSONArray("parts");
            StringBuilder output = new StringBuilder();
            if (parts != null) {
                for (int i = 0; i < parts.length(); i++) {
                    JSONObject part = parts.optJSONObject(i);
                    if (part == null) continue;
                    String text = part.optString("text", "").trim();
                    if (!text.isEmpty()) {
                        if (output.length() > 0) output.append('\n');
                        output.append(text);
                    }
                }
            }
            return output.toString().trim();
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String uploadTextbookToGemini(String key, String uriString) throws Exception {
        byte[] pdfBytes = readTextbookPdf(uriString);
        if (pdfBytes.length == 0) throw new Exception("The selected textbook PDF is empty or could not be read.");

        HttpURLConnection startConnection = null;
        String uploadUrl;
        try {
            startConnection = (HttpURLConnection) new URL("https://generativelanguage.googleapis.com/upload/v1beta/files").openConnection();
            startConnection.setRequestMethod("POST");
            startConnection.setConnectTimeout(25000);
            startConnection.setReadTimeout(60000);
            startConnection.setDoOutput(true);
            startConnection.setRequestProperty("x-goog-api-key", key);
            startConnection.setRequestProperty("X-Goog-Upload-Protocol", "resumable");
            startConnection.setRequestProperty("X-Goog-Upload-Command", "start");
            startConnection.setRequestProperty("X-Goog-Upload-Header-Content-Length", String.valueOf(pdfBytes.length));
            startConnection.setRequestProperty("X-Goog-Upload-Header-Content-Type", "application/pdf");
            startConnection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] metadata = new JSONObject().put("file", new JSONObject().put("display_name", "Maharashtra_SSC_Class10_Sanskrit_Textbook.pdf"))
                    .toString().getBytes(StandardCharsets.UTF_8);
            startConnection.setFixedLengthStreamingMode(metadata.length);
            try (OutputStream out = startConnection.getOutputStream()) { out.write(metadata); }
            int code = startConnection.getResponseCode();
            String response = readStream(code >= 200 && code < 300 ? startConnection.getInputStream() : startConnection.getErrorStream());
            if (code < 200 || code >= 300) throw makeHttpError(code, response);
            uploadUrl = startConnection.getHeaderField("X-Goog-Upload-URL");
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) uploadUrl = startConnection.getHeaderField("x-goog-upload-url");
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) {
                throw new Exception("Gemini did not provide a textbook upload URL. Try without the PDF or choose it again.");
            }
        } finally {
            if (startConnection != null) startConnection.disconnect();
        }

        HttpURLConnection uploadConnection = null;
        try {
            uploadConnection = (HttpURLConnection) new URL(uploadUrl).openConnection();
            uploadConnection.setRequestMethod("POST");
            uploadConnection.setConnectTimeout(30000);
            uploadConnection.setReadTimeout(180000);
            uploadConnection.setDoOutput(true);
            uploadConnection.setRequestProperty("x-goog-api-key", key);
            uploadConnection.setRequestProperty("X-Goog-Upload-Offset", "0");
            uploadConnection.setRequestProperty("X-Goog-Upload-Command", "upload, finalize");
            uploadConnection.setRequestProperty("Content-Type", "application/pdf");
            uploadConnection.setFixedLengthStreamingMode(pdfBytes.length);
            try (OutputStream out = uploadConnection.getOutputStream()) { out.write(pdfBytes); }
            int code = uploadConnection.getResponseCode();
            String responseText = readStream(code >= 200 && code < 300 ? uploadConnection.getInputStream() : uploadConnection.getErrorStream());
            if (code < 200 || code >= 300) throw makeHttpError(code, responseText);
            JSONObject response = new JSONObject(responseText);
            JSONObject file = response.optJSONObject("file");
            String fileUri = file == null ? "" : file.optString("uri", "").trim();
            if (fileUri.isEmpty()) throw new Exception("Gemini uploaded the PDF but did not return its file URI.");
            return fileUri;
        } finally {
            if (uploadConnection != null) uploadConnection.disconnect();
        }
    }

    private byte[] readTextbookPdf(String uriString) throws Exception {
        Uri uri = Uri.parse(uriString);
        try (InputStream input = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            if (input == null) throw new Exception("Cannot open the selected textbook PDF. Please choose it again.");
            byte[] buffer = new byte[16384];
            int read;
            long total = 0;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_PDF_BYTES) throw new Exception("The textbook PDF is larger than 50 MB. Choose a smaller/compressed PDF.");
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        }
    }

    private HttpApiException makeHttpError(int code, String responseText) {
        String message = "";
        try {
            JSONObject err = new JSONObject(responseText).optJSONObject("error");
            if (err != null) message = err.optString("message", "").trim();
        } catch (Exception ignored) { }
        return new HttpApiException(code, message);
    }

    private String userFacingError(Exception e) {
        if (e instanceof HttpApiException) {
            HttpApiException apiError = (HttpApiException) e;
            if (apiError.httpCode == 503) return "Gemini is temporarily busy or unavailable (HTTP 503) after three retries. Please try again later.";
            if (apiError.httpCode == 429) return "Gemini's free-tier quota or request limit was reached (HTTP 429). Wait before asking again.";
            if (apiError.httpCode == 400) return "Gemini rejected the request (HTTP 400). Check the model name and selected textbook PDF.";
            if (apiError.httpCode == 401 || apiError.httpCode == 403) return "Gemini could not authorize this API key (HTTP " + apiError.httpCode + "). Check the key and its API access.";
            if (apiError.httpCode >= 500) return "Gemini's server is unavailable (HTTP " + apiError.httpCode + ") after retries. Please try again later.";
            return "Gemini request failed with HTTP " + apiError.httpCode + (apiError.apiMessage.isEmpty() ? "." : ". " + abbreviate(apiError.apiMessage, 130));
        }
        String reason = e.getMessage();
        return (reason == null || reason.trim().isEmpty())
                ? "I could not get an answer. Check internet access and your Gemini API settings."
                : abbreviate(reason, 210);
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private String abbreviate(String text, int max) {
        if (text == null) return "";
        return text.length() <= max ? text : text.substring(0, max) + "…";
    }

    private void speakAnswerWordByWord(String answer) {
        String clean = answer == null ? "" : answer.trim();
        String languageTag = "hi-IN";
        java.util.regex.Matcher matcher = java.util.regex.Pattern
                .compile("(?m)^\\s*\\[\\[VOICE=(sa-IN|mr-IN|hi-IN|en-IN)\\]\\]\\s*$")
                .matcher(clean);
        if (matcher.find()) {
            languageTag = matcher.group(1);
            clean = (clean.substring(0, matcher.start()) + "\n" + clean.substring(matcher.end())).trim();
        }
        configureVoice(languageTag, false);
        clean = clean.replaceAll("(?m)^\\s*#{1,6}\\s*", "")
                .replace("```", "")
                .replace("**", "")
                .replace("__", "")
                .replace("*", "")
                .replace("_", "")
                .replace("`", "")
                .replaceAll("\\s+", " ").trim();
        if (clean.isEmpty()) {
            playErrorAndResume("Gemini returned an empty answer. Please ask again.");
            return;
        }
        answerWords = clean.split(" ");
        wordIndex = 0;
        answerGeneration++;
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Speaking answer to question " + questionCount + " (" + answerWords.length + " words)…");
        speakCurrentWord(answerGeneration);
    }

    private void speakCurrentWord(long generation) {
        if (stopping || generation != answerGeneration) return;
        if (wordIndex >= answerWords.length) {
            isSpeaking = false;
            updateStatus("Answer finished. Listening for question " + (questionCount + 1) + "…");
            startListening();
            return;
        }
        String word = answerWords[wordIndex];
        if (word.trim().isEmpty()) {
            wordIndex++;
            handler.postDelayed(() -> speakCurrentWord(generation), WORD_PAUSE_MS);
            return;
        }
        String utteranceId = "word_" + generation + "_" + wordIndex;
        if (tts == null || !ttsReady) {
            handler.postDelayed(() -> speakCurrentWord(generation), 700L);
            return;
        }
        int result = tts.speak(word, TextToSpeech.QUEUE_FLUSH, new Bundle(), utteranceId);
        if (result == TextToSpeech.ERROR) {
            handler.postDelayed(() -> {
                if (generation != answerGeneration || stopping) return;
                wordIndex++;
                handler.postDelayed(() -> speakCurrentWord(generation), WORD_PAUSE_MS);
            }, 300L);
        }
    }

    private void handleUtteranceDone(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            handler.postDelayed(this::startListening, 1000L);
            return;
        }
        if (!utteranceId.startsWith("word_")) return;
        final long generation = answerGeneration;
        handler.postDelayed(() -> {
            if (stopping || generation != answerGeneration) return;
            wordIndex++;
            speakCurrentWord(generation);
        }, WORD_PAUSE_MS);
    }

    private void handleUtteranceFinishedWithError(String utteranceId) {
        // Treat an individual TTS failure like a completed word so the loop does not get stuck.
        handleUtteranceDone(utteranceId);
    }

    private void playErrorAndResume(String message) {
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Problem with this question; listening again after the notice.");
        if (tts == null || !ttsReady) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 1500L);
            return;
        }
        // Use Hindi for understandable system/error messages; answer-specific voice is selected per answer.
        configureVoice("hi-IN", false);
        Bundle params = new Bundle();
        String id = "error_" + System.currentTimeMillis();
        int result = tts.speak(message, TextToSpeech.QUEUE_FLUSH, params, id);
        if (result == TextToSpeech.ERROR) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 1500L);
        }
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null) {
                wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getPackageName() + ":SanskritAnswerTeller");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(SESSION_LIMIT_MS + 30000L);
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not acquire wakelock", e);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Sanskrit Answer Teller session", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows listening, textbook upload and speech status, with a Stop action.");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String status) {
        Intent stopIntent = new Intent(this, VoiceLoopService.class);
        stopIntent.setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 991, stopIntent, flags);
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) builder = new Notification.Builder(this, CHANNEL_ID);
        else builder = new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Sanskrit Answer Teller active")
                .setContentText(status)
                .setStyle(new Notification.BigTextStyle().bigText(status))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "STOP", stopPendingIntent).build());
        return builder.build();
    }

    private void updateStatus(String status) {
        if (stopping || notificationManager == null) return;
        try { notificationManager.notify(NOTIFICATION_ID, buildNotification(status)); }
        catch (Exception e) { Log.w(TAG, "Could not update notification", e); }
    }

    private void stopLoop() {
        if (stopping) { stopSelf(); return; }
        stopping = true;
        started = false;
        answerGeneration++;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) { }
            try { tts.shutdown(); } catch (Exception ignored) { }
            tts = null;
        }
        ttsReady = false;
        if (networkExecutor != null) {
            networkExecutor.shutdownNow();
            networkExecutor = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) { }
        }
        wakeLock = null;
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (!stopping) stopLoop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private static class HttpApiException extends Exception {
        final int httpCode;
        final String apiMessage;
        HttpApiException(int httpCode, String apiMessage) {
            super("Gemini HTTP " + httpCode + (apiMessage == null || apiMessage.isEmpty() ? "" : ": " + apiMessage));
            this.httpCode = httpCode;
            this.apiMessage = apiMessage == null ? "" : apiMessage;
        }
    }
}
