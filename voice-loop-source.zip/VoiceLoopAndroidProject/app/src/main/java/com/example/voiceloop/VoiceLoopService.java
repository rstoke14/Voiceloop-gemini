package com.example.voiceloop;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VoiceLoopService extends Service {
    public static final String ACTION_START = "com.example.voiceloop.START";
    public static final String ACTION_STOP = "com.example.voiceloop.STOP";
    public static final String EXTRA_API_KEY = "api_key";
    public static final String EXTRA_MODEL = "model";
    public static final String EXTRA_LANGUAGE = "language";

    private static final String TAG = "EnglishAnswerTeller";
    private static final String CHANNEL_ID = "english_answer_teller_session";
    private static final int NOTIFICATION_ID = 2462;
    private static final long SESSION_LIMIT_MS = 6L * 60L * 60L * 1000L;
    private static final int MAX_RETRIES = 3;

    private static final String INSTRUCTIONS =
            "You are an expert Maharashtra State Board SSC Class 10 English exam solver and a careful student reading the actual paper. Solve the exact question asked using the passage the user has read aloud, or standard English grammar and board-exam skills where applicable. Aim for accurate, exam-ready answers, but never invent facts or claim certainty when the passage does not support an answer.\n" +
            "LANGUAGE AND SPOKEN OUTPUT: Answer in clear, natural, grammatically correct Indian English by default. Use simple, school-level English that a Maharashtra SSC Class 10 student can understand and write in an exam. Use another language only if the question explicitly asks for translation or an answer in that language. Do not use Markdown headings, asterisks, hashtags, tables, decorative bullets, pipes, code fences, or visual diagrams. No greeting, no filler, and no explanation of what you are about to do. Give only the answer. Every answer sentence or distinct answer item MUST be placed on its own line. Do not combine multiple sentences into one line. Do not include numbered labels before the lines; the app numbers each spoken sentence automatically. Keep punctuation natural and spoken clearly.\n" +
            "NO TEXTBOOK PDF: The app has no textbook PDF. The user will read the unseen/seen passage, question-paper extract, prompt details, or writing instructions aloud. Treat the recognized spoken transcript as the source. The user may pronounce a word imperfectly; correct minor speech-to-text errors from context without asking them to repeat unless the meaning is genuinely impossible to determine.\n" +
            "PASSAGE STATE: ACTIVE_PASSAGE contains the last passage read aloud in this session, if one has been stored. It is the controlling source for questions based on that passage. Pay close attention to pronouns and references such as he, she, they, them, these, those, it, his, her, their, and 'the above'; resolve each to the correct person, group, action, place, or idea in the actual passage. Separate explicit facts from inference. Never substitute outside knowledge for a passage detail.\n" +
            "PASSAGE CAPTURE PROTOCOL: (1) If the user clearly announces and reads a passage, or speaks a coherent standalone passage/paragraph without an actual question, store the current transcript as the passage and answer briefly: 'Passage saved. Ask your question.' Use [[PASSAGE=STORE_CURRENT_INPUT]]. (2) If the user reads a long passage in multiple parts and clearly says 'continue the passage', 'next part of the passage', or reads a continuation after the passage has already been saved, append the current transcript to ACTIVE_PASSAGE and reply briefly that the passage has been updated. Use [[PASSAGE=APPEND_CURRENT_INPUT]]. Do not append a normal question. (3) If the user reads the passage and its question in the same utterance, answer the question immediately and store the passage when reasonably identifiable. Do not only acknowledge it. (4) If the user asks a passage-based question but no relevant passage has been supplied, say: 'Please read the passage from the question paper first.' Do not guess. (5) If the user says 'new passage' or 'clear passage' without reading the new text, clear the old passage and ask for the complete new passage. Use [[PASSAGE=CLEAR]]. A newly read passage replaces the old one. Otherwise use [[PASSAGE=UNCHANGED]].\n" +
            "SEEN / UNSEEN PASSAGE QUESTIONS: Read the whole passage and the exact question carefully. For web diagrams, web charts, boxes, tables, matching, fill-in-the-blanks, true/false, complete the sentences, identify who/what/why/when/where, explain a reference, give evidence, find words, word meanings, synonyms, antonyms, title, central idea, summary, personal response, or 'write in your own words', answer only what the question asks and only in the required number/format. For a web diagram or box task, determine the central prompt, count the empty boxes, use any points already filled, and provide exactly the missing answers in their correct positions. Do not repeat filled boxes. Follow references and pronouns through the passage. 'Write in your own words' means paraphrase the passage in simple correct English while preserving its meaning; do not copy blindly, and do not add unsupported ideas. A personal response should answer the prompt directly, connect to the passage when relevant, and give a sensible example. A suitable title should be brief and represent the main idea. Summary questions require only the important points, not extra commentary.\n" +
            "ENGLISH GRAMMAR / LANGUAGE STUDY: Solve standard Maharashtra SSC Class 10 English language-study tasks accurately. These may include tense forms, articles, prepositions, conjunctions, modal auxiliaries, question tags, active and passive voice, direct and indirect speech, degrees of comparison, wh-questions, sentence transformation, error correction, punctuation, word formation, prefixes and suffixes, parts of speech, synonyms and antonyms, homophones, phrasal verbs, collocations, idioms, make a meaningful sentence, word chains, alphabetical order, and vocabulary in context. Preserve the original meaning when transforming a sentence. For direct/indirect speech, adjust pronouns, tense, time/place words, and punctuation correctly. For voice change, preserve tense and intended meaning. For degrees, write the correct equivalent sentence. For punctuation, provide the fully corrected sentence. For word chains, use a valid sequence and follow the exact starting/ending-letter rules. Do not explain grammar unless the question asks for explanation. Give only the requested form/answer.\n" +
            "TEXTUAL CONTENT, POETRY AND LITERATURE: Answer questions about prose, poems, characters, theme, message, figures of speech, rhyming words, appreciation, personal response, and vocabulary from the supplied question or any passage the user has read. If the relevant extract is not supplied and the answer depends on specific text not present in the conversation, request that extract rather than inventing quotations. For appreciation, include only the requested elements, such as title and poet (when known from the question), theme, language/poetic devices, favourite line, and reason. For figures of speech, name the device and evidence only when justified by the given lines.\n" +
            "WRITING SKILLS: Follow the exact prompt, marks, word limit, format, audience, purpose, and points supplied. Handle letter/email writing, report writing, dialogue, speech, story, expansion of an idea, summary, information transfer, interview questions, paragraph writing, essay, notice/advertisement, and other common board-style tasks. Organize longer writing logically and use correct grammar and appropriate vocabulary. Include only details actually supplied or harmless generic placeholders; never fabricate personal contact details, dates, statistics, names, quotations, or events. If asked to write in a specified format, follow it. For a composition, put each complete sentence on a separate line so the app can speak one sentence at a time.\n" +
            "MARKS AND PRECISION: Let the stated marks determine length. A one-mark factual answer should usually be short. A two-mark answer should give the required detail in one or two complete sentences. Longer answers should cover all parts of the prompt without padding. Count requested points, answer every sub-question, respect alternatives, and do not silently skip a part. Re-check grammar, spelling, factual support, and the requested number of answers before responding. If a detail truly cannot be determined, say so briefly rather than guess.\n" +
            "SENTENCE-BY-SENTENCE VOICE PROTOCOL: The app will speak exactly one answer sentence or one distinct answer item, then stop and listen. The user will say 'next sentence' to hear the next item, or say 'sentence two', 'repeat sentence two', or another sentence number to hear that specific item again. Therefore, produce each complete sentence or distinct web-diagram/box answer on its own line, in the correct logical order. Avoid empty lines, very long run-on sentences, and decorative headings. For a web diagram with two answers, use two separate lines. For numbered requested points, put each point on its own line while stating the logical box/point label in the sentence when needed. The app automatically adds a spoken sentence number; do not add your own line numbers.\n" +
            "MANDATORY MACHINE FORMAT: Output these two metadata lines first and exactly once each: [[VOICE=en-IN]] and one of [[PASSAGE=STORE_CURRENT_INPUT]], [[PASSAGE=APPEND_CURRENT_INPUT]], [[PASSAGE=CLEAR]], or [[PASSAGE=UNCHANGED]]. After those lines, output only the answer in English, with each sentence or distinct answer item on a separate line. Use STORE only when the user has actually read a passage. Use APPEND only for a clear continuation of a passage. Use CLEAR only for an explicit passage reset. Otherwise use UNCHANGED. Never output other metadata, internal reasoning, references, sources, or explanations of these rules.";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService networkExecutor;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;
    private String apiKey;
    private String model = "gemini-3.5-flash-lite";
    private String recognitionLanguageTag = "en-IN";
    private String activePassage = "";
    private ArrayList<String> answerSentences = new ArrayList<>();
    private int currentSentenceIndex = -1;
    private int questionCount = 0;
    private long answerGeneration = 0L;
    private boolean ttsReady = false;
    private boolean isProcessing = false;
    private boolean isSpeaking = false;
    private boolean stopping = false;
    private boolean started = false;
    private NotificationManager notificationManager;

    @Override public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();
        networkExecutor = Executors.newSingleThreadExecutor();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopLoop();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        apiKey = intent.getStringExtra(EXTRA_API_KEY);
        model = intent.getStringExtra(EXTRA_MODEL);
        recognitionLanguageTag = "en-IN";
        if (apiKey == null || apiKey.trim().isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (model == null || model.trim().isEmpty()) model = "gemini-3.5-flash-lite";
        started = true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
                startForeground(NOTIFICATION_ID, buildNotification("Starting English Answer Teller…"), types);
            } else {
                startForeground(NOTIFICATION_ID, buildNotification("Starting English Answer Teller…"));
            }
        } catch (SecurityException | IllegalArgumentException ex) {
            Log.e(TAG, "Could not start foreground service", ex);
            stopLoop();
            return START_NOT_STICKY;
        }
        acquireWakeLock();
        handler.postDelayed(this::stopLoop, SESSION_LIMIT_MS);
        initialiseTts();
        updateStatus("Preparing clear English (India) voice and speech recognition…");
        return START_NOT_STICKY;
    }

    private void initialiseTts() {
        tts = new TextToSpeech(getApplicationContext(), status -> handler.post(() -> {
            if (stopping) return;
            if (status != TextToSpeech.SUCCESS || tts == null) {
                updateStatus("Text-to-speech could not start. Check Android speech settings.");
                handler.postDelayed(this::initialiseTts, 3000L);
                return;
            }
            tts.setSpeechRate(0.88f);
            tts.setPitch(1.0f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { handler.post(() -> handleUtteranceDone(utteranceId)); }
                @Override public void onError(String utteranceId) { handler.post(() -> handleUtteranceFinishedWithError(utteranceId)); }
                @Override public void onError(String utteranceId, int errorCode) { handler.post(() -> handleUtteranceFinishedWithError(utteranceId)); }
            });
            ttsReady = configureEnglishVoice();
            if (ttsReady) {
                updateStatus("English voice ready. Listening for your first question…");
                startListening();
            } else {
                updateStatus("An English voice is unavailable. Install English voice data in Android Text-to-speech settings.");
            }
        }));
    }

    private boolean configureEnglishVoice() {
        if (tts == null) return false;
        Locale preferred = Locale.forLanguageTag("en-IN");
        int result;
        try { result = tts.setLanguage(preferred); }
        catch (Exception e) { Log.w(TAG, "Could not select en-IN voice", e); return false; }
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.ERROR) {
            Log.w(TAG, "English voice data unavailable. result=" + result);
            return false;
        }
        try {
            Set<Voice> voices = tts.getVoices();
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            if (voices != null) {
                for (Voice voice : voices) {
                    Locale vl = voice.getLocale();
                    if (vl == null || !"en".equalsIgnoreCase(vl.getLanguage())) continue;
                    int score = voice.getQuality() * 10;
                    if ("IN".equalsIgnoreCase(vl.getCountry())) score += 100;
                    else if ("GB".equalsIgnoreCase(vl.getCountry())) score += 10;
                    if (voice.isNetworkConnectionRequired()) score += 2;
                    if (score > bestScore) { bestScore = score; best = voice; }
                }
            }
            if (best != null && tts.setVoice(best) == TextToSpeech.ERROR) {
                Log.w(TAG, "Could not set a specific English voice; keeping en-IN language setting");
            }
        } catch (Exception e) { Log.w(TAG, "Could not choose best installed English voice", e); }
        tts.setSpeechRate(0.88f);
        tts.setPitch(1.0f);
        return true;
    }

    private void startListening() {
        if (stopping || !started || isProcessing || isSpeaking) return;
        if (!ttsReady) { handler.postDelayed(this::startListening, 500L); return; }
        destroyRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Speech recognition unavailable. Enable an Android speech service; retrying…");
            handler.postDelayed(this::startListening, 5000L);
            return;
        }
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { updateStatus("Listening for question or sentence command…"); }
                @Override public void onBeginningOfSpeech() { updateStatus("Listening…"); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { updateStatus("Recognizing speech…"); }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String heard = (matches == null || matches.isEmpty()) ? "" : matches.get(0).trim();
                    destroyRecognizer();
                    if (heard.isEmpty()) handler.postDelayed(VoiceLoopService.this::startListening, 500L);
                    else if (!handleSentenceCommand(heard)) processQuestion(heard);
                }
                @Override public void onError(int error) {
                    destroyRecognizer();
                    if (stopping || isProcessing || isSpeaking) return;
                    long delay = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1500L : 800L;
                    updateStatus("Speech recognition reset; listening again…");
                    handler.postDelayed(VoiceLoopService.this::startListening, delay);
                }
            });
            Intent speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "en-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            recognizer.startListening(speechIntent);
        } catch (Exception e) {
            Log.e(TAG, "Could not start speech recognition", e);
            destroyRecognizer();
            updateStatus("Could not start listening; retrying…");
            handler.postDelayed(this::startListening, 1500L);
        }
    }

    private boolean handleSentenceCommand(String raw) {
        String q = raw == null ? "" : raw.toLowerCase(Locale.ROOT).trim();
        q = q.replaceAll("[.!?,;:]+$", "").replaceAll("\\s+", " ").trim();
        if (q.isEmpty()) return false;

        boolean next = q.matches("(?:please )?(?:next|continue|go on)(?: sentence| line| point)?")
                || q.matches("(?:please )?(?:read|say) (?:the )?next sentence")
                || q.equals("sentence after this") || q.equals("next one");
        if (next) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready yet. Ask a question first.");
            else if (currentSentenceIndex + 1 < answerSentences.size()) {
                currentSentenceIndex++;
                speakCurrentSentence(answerGeneration);
            } else speakControlNotice("There are no more sentences in this answer. Ask your next question.");
            return true;
        }

        boolean repeatCurrent = q.matches("(?:please )?(?:repeat|again|replay)(?: that| it| this)?")
                || q.matches("(?:please )?(?:repeat|read|say) (?:the )?(?:current|last|same) sentence")
                || q.equals("say it again") || q.equals("read that again") || q.equals("repeat that sentence");
        if (repeatCurrent) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready to repeat. Ask a question first.");
            else speakCurrentSentence(answerGeneration);
            return true;
        }

        Integer requested = parseSentenceNumberCommand(q);
        if (requested != null) {
            if (!hasAnswer()) speakControlNotice("There is no answer ready yet. Ask a question first.");
            else if (requested >= 1 && requested <= answerSentences.size()) {
                currentSentenceIndex = requested - 1;
                speakCurrentSentence(answerGeneration);
            } else speakControlNotice("That sentence number is not in the current answer. Say a number between one and " + answerSentences.size() + ".");
            return true;
        }
        return false;
    }

    private Integer parseSentenceNumberCommand(String q) {
        String numberText = null;
        Matcher m = Pattern.compile("^(?:please )?(?:repeat|read|say|replay) (?:the )?(?:sentence )?(?:number )?([a-z0-9]+)$").matcher(q);
        if (m.matches()) numberText = m.group(1);
        if (numberText == null) {
            m = Pattern.compile("^(?:please )?(?:sentence|number|line|no) (?:number )?([a-z0-9]+)$").matcher(q);
            if (m.matches()) numberText = m.group(1);
        }
        if (numberText == null && q.matches("[0-9]{1,2}")) numberText = q;
        if (numberText == null && WORD_NUMBERS.containsKey(q)) numberText = q;
        if (numberText == null) return null;
        if (numberText.matches("[0-9]{1,2}")) {
            try { return Integer.parseInt(numberText); } catch (NumberFormatException ignored) { return null; }
        }
        return WORD_NUMBERS.get(numberText);
    }

    private static final Map<String, Integer> WORD_NUMBERS = createWordNumbers();
    private static Map<String, Integer> createWordNumbers() {
        Map<String, Integer> map = new HashMap<>();
        String[] words = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"};
        for (int i = 0; i < words.length; i++) map.put(words[i], i);
        map.put("first", 1); map.put("second", 2); map.put("third", 3); map.put("fourth", 4); map.put("fifth", 5);
        map.put("sixth", 6); map.put("seventh", 7); map.put("eighth", 8); map.put("ninth", 9); map.put("tenth", 10);
        return map;
    }

    private boolean hasAnswer() { return answerSentences != null && !answerSentences.isEmpty() && currentSentenceIndex >= 0; }

    private void processQuestion(String question) {
        if (stopping || isProcessing) return;
        isProcessing = true;
        isSpeaking = false;
        questionCount++;
        updateStatus("Question " + questionCount + ": solving board-style answer…");
        final String submittedQuestion = question;
        final String selectedModel = model;
        final String selectedKey = apiKey;
        final String passageAtQuestionTime = activePassage;
        if (networkExecutor == null || networkExecutor.isShutdown()) networkExecutor = Executors.newSingleThreadExecutor();
        networkExecutor.execute(() -> {
            try {
                String answer = requestAnswerWithRetry(selectedKey, selectedModel, submittedQuestion, passageAtQuestionTime);
                handler.post(() -> {
                    if (stopping) return;
                    if (answer == null || answer.trim().isEmpty()) playErrorAndResume("Gemini returned an empty answer. Please ask that question again.");
                    else {
                        applyPassageMarker(answer, submittedQuestion);
                        setAnswerAndSpeak(answer);
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Gemini request failed", e);
                handler.post(() -> { if (!stopping) playErrorAndResume(userFacingError(e)); });
            }
        });
    }

    private String requestAnswerWithRetry(String key, String selectedModel, String question, String passageContext) throws Exception {
        int retryNumber = 0;
        while (true) {
            try { return requestAnswerOnce(key, selectedModel, question, passageContext); }
            catch (HttpApiException e) {
                boolean retryable = e.httpCode == 429 || e.httpCode == 500 || e.httpCode == 502 || e.httpCode == 503 || e.httpCode == 504;
                if (!retryable || retryNumber >= MAX_RETRIES) throw e;
                long delay = 2000L << retryNumber;
                retryNumber++;
                updateStatus("Gemini temporarily unavailable (HTTP " + e.httpCode + "). Retry " + retryNumber + " of " + MAX_RETRIES + " in " + (delay / 1000L) + " seconds…");
                try { Thread.sleep(delay); }
                catch (InterruptedException ex) { Thread.currentThread().interrupt(); throw new Exception("Request cancelled during retry.", ex); }
            }
        }
    }

    private String requestAnswerOnce(String key, String selectedModel, String question, String passageContext) throws Exception {
        String safeModel = selectedModel == null ? "" : selectedModel.trim();
        if (!safeModel.matches("[A-Za-z0-9._-]+")) throw new Exception("Invalid Gemini model ID. Use gemini-3.5-flash-lite.");
        HttpURLConnection connection = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + safeModel + ":generateContent");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(90000);
            connection.setDoOutput(true);
            connection.setRequestProperty("x-goog-api-key", key);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            JSONObject payload = new JSONObject();
            JSONObject systemInstruction = new JSONObject();
            JSONArray systemParts = new JSONArray();
            systemParts.put(new JSONObject().put("text", INSTRUCTIONS));
            systemInstruction.put("parts", systemParts);
            payload.put("systemInstruction", systemInstruction);

            String passage = (passageContext == null || passageContext.trim().isEmpty())
                    ? "(no passage supplied yet; if this question depends on a passage, ask the user to read it aloud first)"
                    : passageContext.substring(0, Math.min(passageContext.length(), 16000));
            String userText = "Solve this Maharashtra State Board SSC Class 10 English exam question using the system instructions. No textbook PDF is available or needed.\n"
                    + "ACTIVE_PASSAGE supplied by the user, if any:\n--- BEGIN ACTIVE PASSAGE ---\n" + passage + "\n--- END ACTIVE PASSAGE ---\n"
                    + "Current spoken transcript (may contain small speech-to-text mistakes; it may be a passage, instruction, command, or question):\n" + question + "\n"
                    + "Classify the transcript carefully. If it is a passage alone, store it. If it asks a question about the active passage, answer from that passage. Produce one complete sentence or one distinct box/point answer per line. Output exactly the required VOICE and PASSAGE metadata lines, then the answer only.";
            JSONArray parts = new JSONArray();
            parts.put(new JSONObject().put("text", userText));
            JSONArray contents = new JSONArray();
            contents.put(new JSONObject().put("role", "user").put("parts", parts));
            payload.put("contents", contents);
            JSONObject config = new JSONObject();
            config.put("maxOutputTokens", 2048);
            config.put("temperature", 0.12);
            payload.put("generationConfig", config);

            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(body); }
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            String responseText = readStream(stream);
            if (code < 200 || code >= 300) throw makeHttpError(code, responseText);
            JSONObject response = new JSONObject(responseText);
            JSONArray candidates = response.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) throw new Exception("Gemini returned no answer. Ask the question again.");
            JSONObject candidate = candidates.optJSONObject(0);
            JSONObject content = candidate == null ? null : candidate.optJSONObject("content");
            JSONArray responseParts = content == null ? null : content.optJSONArray("parts");
            StringBuilder output = new StringBuilder();
            if (responseParts != null) {
                for (int i = 0; i < responseParts.length(); i++) {
                    JSONObject part = responseParts.optJSONObject(i);
                    String text = part == null ? "" : part.optString("text", "").trim();
                    if (!text.isEmpty()) { if (output.length() > 0) output.append('\n'); output.append(text); }
                }
            }
            return output.toString().trim();
        } finally { if (connection != null) connection.disconnect(); }
    }

    private void applyPassageMarker(String response, String submittedQuestion) {
        if (response == null) return;
        Matcher matcher = Pattern.compile("(?m)^\\s*\\[\\[PASSAGE=(STORE_CURRENT_INPUT|APPEND_CURRENT_INPUT|CLEAR|UNCHANGED)\\]\\]\\s*$", Pattern.CASE_INSENSITIVE).matcher(response);
        if (!matcher.find()) return;
        String value = matcher.group(1) == null ? "UNCHANGED" : matcher.group(1).trim().toUpperCase(Locale.ROOT);
        if ("STORE_CURRENT_INPUT".equals(value)) {
            activePassage = submittedQuestion == null ? "" : submittedQuestion.trim();
            Log.i(TAG, "Question-paper passage stored; characters=" + activePassage.length());
        } else if ("APPEND_CURRENT_INPUT".equals(value)) {
            String addition = submittedQuestion == null ? "" : submittedQuestion.trim();
            if (!addition.isEmpty()) activePassage = activePassage == null || activePassage.trim().isEmpty() ? addition : activePassage.trim() + " " + addition;
            Log.i(TAG, "Question-paper passage appended; characters=" + activePassage.length());
        } else if ("CLEAR".equals(value)) {
            activePassage = "";
            Log.i(TAG, "Question-paper passage cleared");
        }
    }

    private void setAnswerAndSpeak(String rawAnswer) {
        ArrayList<String> parsed = splitAnswerIntoSentences(rawAnswer);
        if (parsed.isEmpty()) { playErrorAndResume("Gemini returned an empty answer. Please ask again."); return; }
        answerSentences = parsed;
        currentSentenceIndex = 0;
        answerGeneration++;
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Speaking sentence 1 of " + answerSentences.size() + ". Say 'next sentence' to continue.");
        speakCurrentSentence(answerGeneration);
    }

    private ArrayList<String> splitAnswerIntoSentences(String rawAnswer) {
        ArrayList<String> result = new ArrayList<>();
        if (rawAnswer == null) return result;
        String clean = rawAnswer.replaceAll("(?m)^\\s*\\[\\[(?:VOICE|PASSAGE)=.*?\\]\\]\\s*$", "")
                .replace("```", "").replace("**", "").replace("__", "").replace("*", "").replace("`", "").trim();
        if (clean.isEmpty()) return result;
        String[] lines = clean.split("\\r?\\n");
        Pattern numberedLine = Pattern.compile("^\\s*(?:sentence\\s*)?(\\d{1,2})\\s*[.):-]\\s*(.+?)\\s*$", Pattern.CASE_INSENSITIVE);
        int numberedCount = 0;
        for (String line : lines) if (numberedLine.matcher(line.trim()).matches()) numberedCount++;
        if (numberedCount > 0) {
            for (String original : lines) {
                String line = original.trim();
                if (line.isEmpty()) continue;
                Matcher m = numberedLine.matcher(line);
                if (m.matches()) line = m.group(2).trim();
                else line = line.replaceFirst("^(?:[-•]+|[A-Z][.)])\\s*", "").trim();
                addSentenceFragments(result, line);
            }
        } else {
            for (String original : lines) {
                String line = original.trim().replaceFirst("^(?:[-•]+)\\s*", "").trim();
                if (!line.isEmpty()) addSentenceFragments(result, line);
            }
        }
        return result;
    }

    private void addSentenceFragments(ArrayList<String> target, String line) {
        if (line == null || line.trim().isEmpty()) return;
        BreakIterator iterator = BreakIterator.getSentenceInstance(Locale.US);
        iterator.setText(line.trim());
        int start = iterator.first();
        for (int end = iterator.next(); end != BreakIterator.DONE; start = end, end = iterator.next()) {
            String part = line.trim().substring(start, end).trim();
            if (!part.isEmpty()) target.add(part);
        }
    }

    private void speakCurrentSentence(long generation) {
        if (stopping || generation != answerGeneration) return;
        if (answerSentences == null || currentSentenceIndex < 0 || currentSentenceIndex >= answerSentences.size()) {
            isSpeaking = false;
            startListening();
            return;
        }
        if (tts == null || !ttsReady || !configureEnglishVoice()) {
            isSpeaking = false;
            updateStatus("English voice unavailable. Check speech settings.");
            handler.postDelayed(this::startListening, 1000L);
            return;
        }
        isSpeaking = true;
        String text = "Sentence " + (currentSentenceIndex + 1) + ". " + answerSentences.get(currentSentenceIndex);
        String utteranceId = "sentence_" + generation + "_" + currentSentenceIndex;
        updateStatus("Speaking sentence " + (currentSentenceIndex + 1) + " of " + answerSentences.size() + "…");
        int spoken = tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), utteranceId);
        if (spoken == TextToSpeech.ERROR) {
            isSpeaking = false;
            updateStatus("Could not speak this sentence. Try repeating its sentence number.");
            handler.postDelayed(this::startListening, 500L);
        }
    }

    private void speakControlNotice(String message) {
        if (stopping) return;
        if (tts == null || !ttsReady || !configureEnglishVoice()) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 500L);
            return;
        }
        isSpeaking = true;
        String id = "notice_" + answerGeneration + "_" + System.currentTimeMillis();
        updateStatus("Speaking instruction…");
        int spoken = tts.speak(message, TextToSpeech.QUEUE_FLUSH, new Bundle(), id);
        if (spoken == TextToSpeech.ERROR) { isSpeaking = false; handler.postDelayed(this::startListening, 500L); }
    }

    private void handleUtteranceDone(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("sentence_")) {
            String[] bits = utteranceId.split("_");
            if (bits.length >= 3) {
                try {
                    long generation = Long.parseLong(bits[1]);
                    int sentenceIndex = Integer.parseInt(bits[2]);
                    if (generation != answerGeneration || sentenceIndex != currentSentenceIndex) return;
                } catch (NumberFormatException ignored) { return; }
            }
            isSpeaking = false;
            isProcessing = false;
            updateStatus("Sentence " + (currentSentenceIndex + 1) + " read. Say 'next sentence', 'repeat', or a sentence number.");
            startListening();
            return;
        }
        if (utteranceId.startsWith("notice_") || utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            updateStatus("Listening for your next instruction…");
            handler.postDelayed(this::startListening, 200L);
        }
    }

    private void handleUtteranceFinishedWithError(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("sentence_") || utteranceId.startsWith("notice_") || utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            updateStatus("Speech playback ended. Listening again…");
            handler.postDelayed(this::startListening, 500L);
        }
    }

    private void playErrorAndResume(String message) {
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Question could not be answered; speaking a short notice.");
        speakControlNotice(errorMessageInEnglish(message));
    }

    private String errorMessageInEnglish(String message) {
        String value = message == null ? "" : message.toLowerCase(Locale.ROOT);
        if (value.contains("503") || value.contains("temporarily busy") || value.contains("unavailable")) return "The AI service is temporarily unavailable. Please try again shortly.";
        if (value.contains("429") || value.contains("quota") || value.contains("request limit")) return "The free usage limit may have been reached. Please wait before trying again.";
        if (value.contains("401") || value.contains("403") || value.contains("api key") || value.contains("authorize")) return "Please check the Gemini API key and its permissions.";
        if (value.contains("400") || value.contains("model name") || value.contains("model id")) return "Please check the Gemini model name and request settings.";
        return "I could not get an answer. Check your internet connection and API key, then ask again.";
    }

    private HttpApiException makeHttpError(int code, String responseText) {
        String message = "";
        try { JSONObject err = new JSONObject(responseText).optJSONObject("error"); if (err != null) message = err.optString("message", "").trim(); }
        catch (Exception ignored) { }
        return new HttpApiException(code, message);
    }

    private String userFacingError(Exception e) {
        if (e instanceof HttpApiException) {
            HttpApiException apiError = (HttpApiException) e;
            if (apiError.httpCode == 503) return "The AI server is temporarily busy (HTTP 503) after retries. Please try again later.";
            if (apiError.httpCode == 429) return "The free-tier quota or request limit was reached (HTTP 429). Wait before asking again.";
            if (apiError.httpCode == 400) return "The AI rejected the request (HTTP 400). Check the model name.";
            if (apiError.httpCode == 401 || apiError.httpCode == 403) return "The API key could not be authorized (HTTP " + apiError.httpCode + "). Check the key and API access.";
            if (apiError.httpCode >= 500) return "The AI server is unavailable (HTTP " + apiError.httpCode + ") after retries. Please try again later.";
            return "AI request failed with HTTP " + apiError.httpCode + (apiError.apiMessage.isEmpty() ? "." : ". " + abbreviate(apiError.apiMessage, 130));
        }
        String reason = e.getMessage();
        return (reason == null || reason.trim().isEmpty()) ? "I could not get an answer. Check internet access and your Gemini API settings." : abbreviate(reason, 210);
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private String abbreviate(String text, int max) { if (text == null) return ""; return text.length() <= max ? text : text.substring(0, max) + "…"; }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getPackageName() + ":EnglishAnswerTeller");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(SESSION_LIMIT_MS + 30000L);
            }
        } catch (Exception e) { Log.w(TAG, "Could not acquire wakelock", e); }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "English Answer Teller session", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows listening and sentence-by-sentence speech status, with a Stop action.");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String status) {
        Intent stopIntent = new Intent(this, VoiceLoopService.class);
        stopIntent.setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 992, stopIntent, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("English Answer Teller active")
                .setContentText(status)
                .setStyle(new Notification.BigTextStyle().bigText(status))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "STOP", stopPendingIntent).build());
        return builder.build();
    }

    private void updateStatus(String status) {
        if (stopping || notificationManager == null) return;
        try { notificationManager.notify(NOTIFICATION_ID, buildNotification(status)); }
        catch (Exception e) { Log.w(TAG, "Could not update notification", e); }
    }

    private void stopLoop() {
        if (stopping) { stopSelf(); return; }
        stopping = true;
        started = false;
        answerGeneration++;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) { try { tts.stop(); } catch (Exception ignored) { } try { tts.shutdown(); } catch (Exception ignored) { } tts = null; }
        ttsReady = false;
        if (networkExecutor != null) { networkExecutor.shutdownNow(); networkExecutor = null; }
        if (wakeLock != null && wakeLock.isHeld()) { try { wakeLock.release(); } catch (Exception ignored) { } }
        wakeLock = null;
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override public void onDestroy() { if (!stopping) stopLoop(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }

    private static class HttpApiException extends Exception {
        final int httpCode;
        final String apiMessage;
        HttpApiException(int httpCode, String apiMessage) {
            super("Gemini HTTP " + httpCode + (apiMessage == null || apiMessage.isEmpty() ? "" : ": " + apiMessage));
            this.httpCode = httpCode;
            this.apiMessage = apiMessage == null ? "" : apiMessage;
        }
    }
}
