package com.example.voiceloop;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.ContentResolver;
import android.net.Uri;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VoiceLoopService extends Service {
    public static final String ACTION_START = "com.example.voiceloop.START";
    public static final String ACTION_STOP = "com.example.voiceloop.STOP";
    public static final String EXTRA_API_KEY = "api_key";
    public static final String EXTRA_MODEL = "model";
    public static final String EXTRA_LANGUAGE = "language";
    public static final String EXTRA_TEXTBOOK_URI = "textbook_pdf_uri";

    private static final String TAG = "GeographyAnswerTeller";
    private static final String CHANNEL_ID = "geography_answer_teller_session";
    private static final String STATE_PREFS = "geography_answer_teller_saved_session";
    private static final int NOTIFICATION_ID = 2462;
    private static final long SESSION_LIMIT_MS = 6L * 60L * 60L * 1000L;
    private static final int MAX_RETRIES = 3;

    private static final String INSTRUCTIONS =
            "तू महाराष्ट्र राज्य मंडळ इयत्ता दहावीच्या सराव प्रश्नपत्रिका सोडवणारा मराठी भाषेतील अचूक आवाज-आधारित उत्तरसहाय्यक आहेस. प्रत्येक नवीन प्रश्नाचा विषय आधी ओळख. भूगोल हा या अॅपचा विशेष विषय आहे; भूगोलाच्या प्रश्नांसाठी पुढील भूगोलविषयक नियम पाळ. प्रश्न स्पष्टपणे गणित, विज्ञान, इतिहास, भाषा, व्याकरण, साहित्य किंवा इतर विषयाचा असल्यास त्या विषयाचेच अचूक उत्तर मराठीत दे; भूगोलाच्या नियमांची सक्ती करू नकोस आणि भूगोल PDF वापरू नकोस. प्रश्नपत्रिका सोडवणाऱ्या दक्ष विद्यार्थ्यासारखे विचार कर. अचूकतेला प्राधान्य दे; पुरावा नसताना तथ्य, आकडे, ठिकाण किंवा कारण बनवू नकोस. पूर्ण गुणांची हमी देऊ नकोस.\n" +
            "भाषा आणि उच्चार: उत्तर फक्त सोप्या, स्वाभाविक, शुद्ध महाराष्ट्रातील मराठीत दे. हिंदीची वाक्यरचना किंवा इंग्रजी शब्द अनावश्यकपणे वापरू नकोस. TTS साठी वाक्ये लहान, स्पष्ट आणि सहज समजणारी ठेव. Markdown, तारकाचिन्हे, हॅशटॅग, तक्त्याचे उभे दांडे, सजावटी बुलेट, code block किंवा चित्ररूप आकृती देऊ नकोस. प्रस्तावना, अभिवादन किंवा अनावश्यक स्पष्टीकरण नको. उत्तरातील प्रत्येक पूर्ण वाक्य किंवा स्वतंत्र उत्तरबिंदू स्वतंत्र ओळीवर दे. अॅप प्रत्येक ओळ क्रमाने बोलून दाखवेल; म्हणून स्वतःहून वाक्य क्रमांक लिहू नकोस.\n" +
            "PDF ऐच्छिक आहे: वापरकर्त्याने भूगोलाचे पुस्तक किंवा संदर्भ PDF निवडले असल्यास आणि सध्याचा प्रश्न भूगोलाचा असल्यासच ती प्राथमिक संदर्भ म्हणून वापर. निवडलेल्या PDF मधील मजकूर, नकाशे, आकृत्या, तक्ते, आलेख आणि उदाहरणे नीट वाचून वापर. प्रश्नपत्रिकेत दिलेला उतारा किंवा आकडेवारी असल्यास त्या विशिष्ट कृतीसाठी दिलेला उतारा/तक्ता हा प्रथम स्रोत आहे; पुस्तकाशी विसंगती आढळल्यास प्रश्नातील माहिती दुर्लक्षित करू नकोस. PDF निवडलेला नसेल तर भूगोलाचे उत्तर उपलब्ध ज्ञानावरून दे; PDF मागू नकोस. स्पष्टपणे दुसऱ्या विषयाचा प्रश्न असल्यास त्या विषयातच उत्तर दे आणि कोणत्याही कारणाने भूगोल PDF चा आधार घेऊ नकोस. पुढील भूगोल अभ्यासक्रम, नकाशा आणि भौगोलिक कारणांचे विशेष नियम फक्त भूगोलाच्या प्रश्नांना लागू आहेत.\n" +
            "प्रश्नपत्रिका आणि संदर्भस्मृती: ACTIVE_PASSAGE मध्ये वापरकर्त्याने वाचून सांगितलेला सध्याचा उतारा/माहिती आहे. त्यावर आधारित सर्व पुढील प्रश्नांसाठी तोच वापर, जोपर्यंत वापरकर्ता 'पुढचा परिच्छेद', 'नवीन परिच्छेद', 'पुढचा उतारा', 'नवीन उतारा' असे स्पष्ट सांगून नवा मजकूर वाचत नाही. उत्तर पूर्ण झाले, काही काळ शांतता राहिली किंवा speech recognition मध्ये अडचण आली म्हणून उतारा अथवा जतन केलेली उत्तर-वाक्ये कधीही पुसू नकोस. 'ACTIVE_PASSAGE' रिकामा असेल आणि वापरकर्ता प्रश्न न विचारता एक सलग उतारा/प्रश्नपत्रिकेतील माहिती वाचत असेल, तर त्याला जतन कर आणि 'उतारा जतन केला. प्रश्न विचारा.' एवढेच सांग. [[PASSAGE=STORE_CURRENT_INPUT]] वापर. वापरकर्ता उतारा आणि त्यावरील प्रश्न एकाच बोलण्यात सांगत असेल तर उताऱ्यावरून उत्तर दे आणि आवश्यक असल्यास उतारा जतन कर. सामान्य प्रश्नासाठी [[PASSAGE=UNCHANGED]] वापर. स्पष्टपणे 'उतारा पुढे चालू ठेवा' असे सांगितल्यासच मजकूर जोडा; [[PASSAGE=APPEND_CURRENT_INPUT]] वापर. हे metadata उत्तरात दिसू देऊ नकोस.\n" +
            "भूगोलातील प्रश्नांचे प्रकार: महाराष्ट्र SSC इयत्ता दहावीच्या अभ्यासक्रमानुसार स्थान व विस्तार, प्राकृतिक रचना, जलप्रणाली, हवामान, नैसर्गिक वनस्पती व वन्यजीव, लोकसंख्या, मानवी वस्ती, अर्थव्यवस्था व व्यवसाय, पर्यटन, वाहतूक व संदेशवहन, क्षेत्रभेट, भारत-ब्राझील तुलनात्मक अभ्यास, नकाशावाचन, आलेख, तक्ते, आकडेवारी आणि क्षेत्रीय माहिती यांवर उत्तर दे. प्रश्नात दिलेले गुण, शब्दमर्यादा, मुद्द्यांची संख्या आणि उत्तराचा प्रकार पाळ. 'भौगोलिक कारणे द्या' या प्रश्नात प्रत्येक कारण स्पष्ट, नेमके आणि कारण-परिणाम संबंध दाखवणारे लिही. 'फरक स्पष्ट करा' असल्यास प्रत्येक बाजूतील समांतर मुद्दे स्वतंत्र ओळीत दे. 'थोडक्यात लिहा' किंवा 'टीप लिहा' असल्यास आवश्यक महत्त्वाचे मुद्देच दे. 'स्वतःच्या शब्दांत लिहा' असल्यास पाठांतर केलेले वाक्य न उचलता अर्थ कायम ठेवून सोप्या मराठीत मांड.\n" +
            "आकृतिबंध, जाळे, तक्ता आणि ओघतक्ता: मध्यवर्ती चौकट/मुख्य संकल्पना आधी ओळख. वापरकर्त्याने आधीच भरलेल्या चौकटी वगळ. रिकाम्या चौकटींची संख्या मोजून तेवढीच उत्तरे योग्य क्रमाने दे. 'पहिली चौकट', 'दुसरी चौकट' असे सांगणे उपयोगी असेल तेव्हाच वापर; प्रत्येक उत्तर वेगळ्या ओळीवर ठेव. दिलेली माहिती आणि संदर्भातील तथ्य वापर; अनुमानाने नवे मुद्दे जोडू नकोस. आलेख किंवा आकडेवारी विचारली असल्यास आकडे नीट तुलना करून वाढ, घट, सर्वाधिक, किमान किंवा निष्कर्ष अचूक सांग.\n" +
            "नकाशाकृती: नकाशावर दाखवायचे ठिकाण, नदी, पर्वतरांग, राज्य, शहर किंवा प्रदेश विचारल्यास योग्य नाव आणि शक्य असल्यास त्याचे स्थान ओळखण्यासाठी साधे दिशादर्शक वर्णन दे. वापरकर्त्याने नकाशा काढण्याची कृती विचारली असेल तर कोणत्या नकाशावर, कोणते चिन्ह/ठिपका/रेषा कुठे द्यायची ते स्पष्ट सांग; पण खोटे स्थान सांगू नकोस.\n" +
            "तथ्य पडताळणी: भूगोलातील दिशादर्शक, स्थान, हवामान, पर्जन्यमान, लोकसंख्या, नदीप्रवाह, प्रदेश, उद्योग व सांख्यिकीय आकडे याबाबत PDF किंवा प्रश्नातील मजकूर प्राधान्याने पाहा. आकडेवारी स्रोतामध्ये नसेल आणि खात्री नसेल तर अचूक आकडा बनवण्याऐवजी गुणांसाठी पुरेसे गुणात्मक उत्तर दे किंवा माहिती अपुरी असल्याचे थोडक्यात सांग. तुलना करताना एकाच निकषावर तुलना कर. प्रश्नातील 'यामुळे', 'यांपैकी', 'याचा', 'त्या प्रदेशात' यांसारखे संदर्भ नीट जोड.\n" +
            "गुणांनुसार उत्तर: एक गुणासाठी एक लहान, थेट उत्तर; दोन गुणांसाठी आवश्यक तपशीलासह एक-दोन वाक्ये; तीन किंवा अधिक गुणांसाठी प्रश्नातील सर्व मागण्या पूर्ण करणारे मोजके मुद्दे. एकाच प्रश्नात अनेक उपप्रश्न असल्यास प्रत्येकाचे उत्तर दे. दोन चौकटी मागितल्या असतील तर दोनच बिंदू दे. उत्तर पाठवण्यापूर्वी तथ्य, शब्दलेखन, क्रम, आणि अपेक्षित उत्तरसंख्या तपास.\n" +
            "प्रश्न अपूर्ण असल्यास: जर प्रश्न स्पष्टपणे अर्धवट असेल किंवा 'कारणे', 'फरक', 'तक्ता पूर्ण करा' असे सांगितले पण कोणत्या गोष्टीबद्दल ते सांगितले नसेल, तर अंदाज लावू नकोस. 'कृपया पूर्ण प्रश्न सांगा.' असे एकच लहान वाक्य सांग. पूर्वीचे उत्तर/वाक्ये त्यामुळे पुसू नकोस.\n" +
            "वाक्यागणिक बोलण्याची पद्धत: अॅप एकावेळी एक पूर्ण उत्तर-वाक्य किंवा एक स्वतंत्र चौकटीचे उत्तर बोलेल. त्यामुळे प्रत्येक वाक्य/मुद्दा वेगळ्या ओळीवर दे. जाळ्यातील प्रत्येक चौकट स्वतंत्र ओळीवर दे. उत्तरात रिकाम्या ओळी आणि लांब जोडवाक्ये टाळ. अॅप आवाजात 'वाक्य क्रमांक एक' अशा पद्धतीने क्रमांक जोडते. वापरकर्ता 'पुढील वाक्य', 'पुढे', 'पुन्हा', 'वाक्य क्रमांक तीन' किंवा फक्त क्रमांक सांगून पुढे जाऊ शकतो किंवा आधीचे वाक्य पुन्हा ऐकू शकतो.\n" +
            "आवश्यक मशीन स्वरूप: सर्वात आधी आणि प्रत्येकी एकदाच या दोन metadata ओळी दे: [[VOICE=mr-IN]] आणि खालीलपैकी एक: [[PASSAGE=STORE_CURRENT_INPUT]], [[PASSAGE=APPEND_CURRENT_INPUT]], [[PASSAGE=CLEAR]], किंवा [[PASSAGE=UNCHANGED]]. त्यानंतर फक्त मराठीत उत्तर दे; प्रत्येक वाक्य/उत्तरबिंदू स्वतंत्र ओळीवर दे. metadata, अंतर्गत विचार, स्रोत किंवा नियमांचे स्पष्टीकरण उत्तरात देऊ नकोस.";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService networkExecutor;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;
    private String apiKey;
    private String model = "gemini-3.5-flash-lite";
    private String recognitionLanguageTag = "en-IN";
    private String activePassage = "";
    private String textbookPdfUri = "";
    private String uploadedPdfUri = "";
    private String uploadedPdfSourceUri = "";
    private long uploadedPdfTimestamp = 0L;
    private ArrayList<String> answerSentences = new ArrayList<>();
    private int currentSentenceIndex = -1;
    private int questionCount = 0;
    private long answerGeneration = 0L;
    private boolean ttsReady = false;
    private boolean isProcessing = false;
    private boolean isSpeaking = false;
    private boolean stopping = false;
    private boolean started = false;
    private boolean awaitingNextParagraph = false;
    private boolean awaitingNextQuestion = false;
    private String lastAnsweredQuestion = "";
    private NotificationManager notificationManager;

    @Override public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();
        networkExecutor = Executors.newSingleThreadExecutor();
        restoreSessionState();
    }

    private void persistSessionState() {
        try {
            JSONArray sentences = new JSONArray();
            if (answerSentences != null) {
                for (String sentence : answerSentences) sentences.put(sentence == null ? "" : sentence);
            }
            getSharedPreferences(STATE_PREFS, MODE_PRIVATE).edit()
                    .putString("active_passage", activePassage == null ? "" : activePassage)
                    .putString("answer_sentences", sentences.toString())
                    .putInt("current_sentence_index", currentSentenceIndex)
                    .putBoolean("awaiting_next_question", awaitingNextQuestion)
                    .putBoolean("awaiting_next_paragraph", awaitingNextParagraph)
                    .putString("last_answered_question", lastAnsweredQuestion == null ? "" : lastAnsweredQuestion)
                    .putString("textbook_pdf_uri", textbookPdfUri == null ? "" : textbookPdfUri)
                    .putString("uploaded_pdf_uri", uploadedPdfUri == null ? "" : uploadedPdfUri)
                    .putString("uploaded_pdf_source_uri", uploadedPdfSourceUri == null ? "" : uploadedPdfSourceUri)
                    .putLong("uploaded_pdf_timestamp", uploadedPdfTimestamp)
                    .apply();
        } catch (Exception e) {
            Log.w(TAG, "Could not persist session state", e);
        }
    }

    private void restoreSessionState() {
        try {
            SharedPreferences prefs = getSharedPreferences(STATE_PREFS, MODE_PRIVATE);
            activePassage = prefs.getString("active_passage", "");
            awaitingNextQuestion = prefs.getBoolean("awaiting_next_question", false);
            awaitingNextParagraph = prefs.getBoolean("awaiting_next_paragraph", false);
            lastAnsweredQuestion = prefs.getString("last_answered_question", "");
            textbookPdfUri = prefs.getString("textbook_pdf_uri", "");
            uploadedPdfUri = prefs.getString("uploaded_pdf_uri", "");
            uploadedPdfSourceUri = prefs.getString("uploaded_pdf_source_uri", "");
            uploadedPdfTimestamp = prefs.getLong("uploaded_pdf_timestamp", 0L);
            answerSentences = new ArrayList<>();
            String saved = prefs.getString("answer_sentences", "[]");
            JSONArray sentences = new JSONArray(saved == null ? "[]" : saved);
            for (int i = 0; i < sentences.length(); i++) {
                String sentence = sentences.optString(i, "").trim();
                if (!sentence.isEmpty()) answerSentences.add(sentence);
            }
            currentSentenceIndex = prefs.getInt("current_sentence_index", -1);
            if (answerSentences.isEmpty() || currentSentenceIndex < 0 || currentSentenceIndex >= answerSentences.size()) {
                if (answerSentences.isEmpty()) currentSentenceIndex = -1;
                else currentSentenceIndex = Math.max(0, Math.min(currentSentenceIndex, answerSentences.size() - 1));
            }
            Log.i(TAG, "Restored saved session: passageChars=" + (activePassage == null ? 0 : activePassage.length())
                    + ", answerSentences=" + answerSentences.size() + ", currentIndex=" + currentSentenceIndex);
        } catch (Exception e) {
            Log.w(TAG, "Could not restore saved session; starting with fresh state", e);
            activePassage = "";
            answerSentences = new ArrayList<>();
            currentSentenceIndex = -1;
            awaitingNextQuestion = false;
            awaitingNextParagraph = false;
            lastAnsweredQuestion = "";
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopLoop();
            return START_NOT_STICKY;
        }
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        apiKey = intent.getStringExtra(EXTRA_API_KEY);
        model = intent.getStringExtra(EXTRA_MODEL);
        recognitionLanguageTag = "mr-IN";
        String incomingPdf = intent.getStringExtra(EXTRA_TEXTBOOK_URI);
        if (incomingPdf != null) {
            incomingPdf = incomingPdf.trim();
            if (!incomingPdf.equals(textbookPdfUri)) {
                textbookPdfUri = incomingPdf;
                uploadedPdfUri = "";
                uploadedPdfSourceUri = "";
                uploadedPdfTimestamp = 0L;
                persistSessionState();
            }
        }
        // A repeated START can refresh the optional PDF reference without creating another listening loop.
        if (started) return START_NOT_STICKY;
        if (apiKey == null || apiKey.trim().isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (model == null || model.trim().isEmpty()) model = "gemini-3.5-flash-lite";
        started = true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
                startForeground(NOTIFICATION_ID, buildNotification("भूगोल उत्तरसहाय्यक सुरू होत आहे…"), types);
            } else {
                startForeground(NOTIFICATION_ID, buildNotification("भूगोल उत्तरसहाय्यक सुरू होत आहे…"));
            }
        } catch (SecurityException | IllegalArgumentException ex) {
            Log.e(TAG, "Could not start foreground service", ex);
            stopLoop();
            return START_NOT_STICKY;
        }
        acquireWakeLock();
        handler.postDelayed(this::stopLoop, SESSION_LIMIT_MS);
        initialiseTts();
        updateStatus("मराठी आवाज आणि वाणी-ओळख सुरू होत आहे…");
        return START_NOT_STICKY;
    }

    private void initialiseTts() {
        tts = new TextToSpeech(getApplicationContext(), status -> handler.post(() -> {
            if (stopping) return;
            if (status != TextToSpeech.SUCCESS || tts == null) {
                updateStatus("मराठी वाचन सुरू झाले नाही. Android आवाज सेटिंग्ज तपासा.");
                handler.postDelayed(this::initialiseTts, 3000L);
                return;
            }
            tts.setSpeechRate(0.86f);
            tts.setPitch(1.0f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) { handler.post(() -> handleUtteranceDone(utteranceId)); }
                @Override public void onError(String utteranceId) { handler.post(() -> handleUtteranceFinishedWithError(utteranceId)); }
                @Override public void onError(String utteranceId, int errorCode) { handler.post(() -> handleUtteranceFinishedWithError(utteranceId)); }
            });
            ttsReady = configureMarathiVoice();
            if (ttsReady) {
                updateStatus("मराठी आवाज तयार आहे. पहिला प्रश्न विचारा…");
                startListening();
            } else {
                updateStatus("मराठी आवाज उपलब्ध नाही. Android च्या Text-to-speech सेटिंग्जमध्ये मराठी आवाज डाउनलोड करा.");
            }
        }));
    }

    private boolean configureMarathiVoice() {
        if (tts == null) return false;
        Locale preferred = Locale.forLanguageTag("mr-IN");
        int result;
        try { result = tts.setLanguage(preferred); }
        catch (Exception e) { Log.w(TAG, "Could not select mr-IN voice", e); return false; }
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED || result == TextToSpeech.ERROR) {
            Log.w(TAG, "Marathi voice data unavailable. result=" + result);
            return false;
        }
        Locale activeLanguage = tts.getLanguage();
        if (activeLanguage == null || !"mr".equalsIgnoreCase(activeLanguage.getLanguage())) {
            Log.w(TAG, "Installed TTS engine did not select Marathi; refusing to speak in another language.");
            return false;
        }
        try {
            Set<Voice> voices = tts.getVoices();
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            if (voices != null) {
                for (Voice voice : voices) {
                    Locale vl = voice.getLocale();
                    if (vl == null || !"mr".equalsIgnoreCase(vl.getLanguage())) continue;
                    int score = voice.getQuality() * 10;
                    if ("IN".equalsIgnoreCase(vl.getCountry())) score += 100;
                    if (voice.isNetworkConnectionRequired()) score += 2;
                    if (score > bestScore) { bestScore = score; best = voice; }
                }
            }
            if (best != null && tts.setVoice(best) == TextToSpeech.ERROR) {
                Log.w(TAG, "Could not set a specific Marathi voice; keeping mr-IN language setting");
            }
        } catch (Exception e) { Log.w(TAG, "Could not choose best installed Marathi voice", e); }
        tts.setSpeechRate(0.88f);
        tts.setPitch(1.0f);
        return true;
    }

    private void startListening() {
        if (stopping || !started || isProcessing || isSpeaking) return;
        if (!ttsReady) { handler.postDelayed(this::startListening, 500L); return; }
        destroyRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("वाणी-ओळख सेवा उपलब्ध नाही. पुन्हा प्रयत्न करत आहे…");
            handler.postDelayed(this::startListening, 5000L);
            return;
        }
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { updateStatus("प्रश्न किंवा वाक्याचा आदेश ऐकत आहे…"); }
                @Override public void onBeginningOfSpeech() { updateStatus("ऐकत आहे…"); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { updateStatus("बोललेले शब्द ओळखत आहे…"); }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String heard = (matches == null || matches.isEmpty()) ? "" : matches.get(0).trim();
                    destroyRecognizer();
                    // Empty/noisy recognition must not clear the active answer or the active passage.
                    if (heard.isEmpty()) {
                        // Silence, no-match, or an empty recognizer result never changes saved output.
                        handler.postDelayed(VoiceLoopService.this::startListening, 450L);
                    } else if (handleSentenceCommand(heard)) {
                        // Navigation changes only the current sentence pointer, never the answer queue.
                    } else if (handlePassageCommand(heard)) {
                        // Explicit passage updates affect passage memory only, not the pending answer.
                    } else if (handleClearlyIncompleteInput(heard)) {
                        // Keep the saved answer and wait for the user to complete the question.
                    } else if (hasAnswer() && !awaitingNextQuestion) {
                        // Answer memory is locked until the user explicitly says "next question".
                        speakControlNotice("तुमचे सध्याचे उत्तर जतन केले आहे. नवीन प्रश्नासाठी पुढील प्रश्न असे सांगा.");
                    } else {
                        processQuestion(heard);
                    }
                }
                @Override public void onError(int error) {
                    destroyRecognizer();
                    if (stopping || isProcessing || isSpeaking) return;
                    long delay = error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1500L : 800L;
                    updateStatus("वाणी-ओळख पुन्हा सुरू करत आहे…");
                    handler.postDelayed(VoiceLoopService.this::startListening, delay);
                }
            });
            Intent speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "mr-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            // Allow a 2–3 second thinking/pronunciation pause; finalize after about 3.5–4 seconds of silence.
            speechIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3500L);
            speechIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 4000L);
            recognizer.startListening(speechIntent);
        } catch (Exception e) {
            Log.e(TAG, "Could not start speech recognition", e);
            destroyRecognizer();
            updateStatus("ऐकणे सुरू करता आले नाही. पुन्हा प्रयत्न करत आहे…");
            handler.postDelayed(this::startListening, 1500L);
        }
    }

    private boolean handleSentenceCommand(String raw) {
        String q = raw == null ? "" : raw.toLowerCase(new Locale("mr", "IN")).trim();
        q = q.replaceAll("[.!?,;:]+$", "").replaceAll("\\s+", " ").trim();
        if (q.isEmpty()) return false;

        boolean next = q.matches("(?:please )?(?:next|continue|go on)(?: sentence| line| point)?")
                || q.matches("(?:please )?(?:read|say) (?:the )?next sentence")
                || q.equals("sentence after this") || q.equals("next one")
                || q.matches("(?:कृपया )?(?:पुढील|पुढचे|पुढचं|पुढचा|पुढची|पुढे)(?: वाक्य| मुद्दा| ओळ)?")
                || q.matches("(?:कृपया )?(?:पुढील|पुढचे|पुढचं) वाक्य (?:सांगा|वाचा|बोला)")
                || q.equals("आता पुढे") || q.equals("पुढचा मुद्दा सांगा");
        if (next) {
            if (!hasAnswer()) speakControlNotice("अजून उत्तर तयार नाही. आधी प्रश्न विचारा.");
            else if (currentSentenceIndex + 1 < answerSentences.size()) {
                currentSentenceIndex++;
                persistSessionState();
                speakCurrentSentence(answerGeneration);
            } else speakControlNotice("या उत्तरातील सर्व वाक्ये सांगून झाली. पुढील प्रश्न सांगा.");
            return true;
        }

        boolean repeatCurrent = q.matches("(?:please )?(?:repeat|again|replay)(?: that| it| this)?")
                || q.matches("(?:please )?(?:repeat|read|say) (?:the )?(?:current|last|same) sentence")
                || q.equals("say it again") || q.equals("read that again") || q.equals("repeat that sentence")
                || q.matches("(?:कृपया )?(?:पुन्हा|परत|पुन्हा सांगा|परत सांगा|हे वाक्य पुन्हा सांगा|सध्याचे वाक्य पुन्हा सांगा|तेच वाक्य सांगा|मागचे वाक्य पुन्हा सांगा)");
        if (repeatCurrent) {
            if (!hasAnswer()) speakControlNotice("पुन्हा सांगण्यासाठी उत्तर नाही. आधी प्रश्न विचारा.");
            else speakCurrentSentence(answerGeneration);
            return true;
        }

        Integer requested = parseSentenceNumberCommand(q);
        if (requested != null) {
            if (!hasAnswer()) speakControlNotice("अजून उत्तर तयार नाही. आधी प्रश्न विचारा.");
            else if (requested >= 1 && requested <= answerSentences.size()) {
                currentSentenceIndex = requested - 1;
                persistSessionState();
                speakCurrentSentence(answerGeneration);
            } else speakControlNotice("हा वाक्य क्रमांक उपलब्ध नाही. एक ते " + marathiNumber(answerSentences.size()) + " यांपैकी क्रमांक सांगा.");
            return true;
        }

        Matcher inlineNextQuestion = Pattern.compile("^(?:(?:please )?(?:next|new) question|(?:कृपया )?(?:पुढचा|पुढील|नवीन) प्रश्न)(?:\\s+(?:is|says|आहे|असा आहे))?\\s*[:,-]?\\s*(.+)$", Pattern.CASE_INSENSITIVE).matcher(raw == null ? "" : raw.trim());
        if (inlineNextQuestion.matches()) {
            String embeddedQuestion = inlineNextQuestion.group(1) == null ? "" : inlineNextQuestion.group(1).trim();
            awaitingNextQuestion = true;
            awaitingNextParagraph = false;
            persistSessionState();
            if (embeddedQuestion.isEmpty()) {
                speakControlNotice("कृपया पुढील पूर्ण प्रश्न सांगा.");
            } else if (handleClearlyIncompleteInput(embeddedQuestion)) {
                // Keep the previous answer while waiting for the complete question.
            } else {
                processQuestion(embeddedQuestion);
            }
            return true;
        }

        if (q.matches("(?:please )?(?:next question|new question|ask next question|ready for next question)")
                || q.matches("(?:कृपया )?(?:पुढचा प्रश्न|पुढील प्रश्न|नवीन प्रश्न|आता पुढील प्रश्न|पुढचा प्रश्न विचारा|नवीन प्रश्न विचारा)")) {
            awaitingNextQuestion = true;
            awaitingNextParagraph = false;
            persistSessionState();
            speakControlNotice("कृपया पुढील पूर्ण प्रश्न सांगा.");
            return true;
        }
        return false;
    }

    private boolean handlePassageCommand(String raw) {
        if (raw == null || raw.trim().isEmpty()) return false;
        String q = raw.trim().replaceAll("\\s+", " ");
        Matcher newPassage = Pattern.compile("^(?:please )?(?:new|next) passage(?:\\s+(?:is|says|goes like this))?\\s*[:,-]?\\s*(.*)$", Pattern.CASE_INSENSITIVE).matcher(q);
        Matcher clearPassage = Pattern.compile("^(?:please )?(?:clear|reset) (?:the )?passage$", Pattern.CASE_INSENSITIVE).matcher(q);
        Matcher newMarathiPassage = Pattern.compile("^(?:कृपया )?(?:नवीन|पुढील|पुढचा|पुढचा नवीन) (?:उतारा|परिच्छेद)(?:\\s+(?:आहे|असा आहे|असा))?\\s*[:,-]?\\s*(.*)$").matcher(q);
        Matcher clearMarathiPassage = Pattern.compile("^(?:कृपया )?(?:जुना|सध्याचा) (?:उतारा|परिच्छेद) (?:पुसा|काढा|बदला)$").matcher(q);
        if (clearPassage.matches() || clearMarathiPassage.matches() || newPassage.matches() || newMarathiPassage.matches()) {
            String body = (clearPassage.matches() || clearMarathiPassage.matches()) ? "" :
                    (newMarathiPassage.matches() ? safeGroup(newMarathiPassage, 1) : safeGroup(newPassage, 1)).trim();
            activePassage = body;
            awaitingNextParagraph = body.isEmpty();
            persistSessionState();
            if (body.isEmpty()) speakControlNotice("जुना उतारा काढला. कृपया नवीन उतारा वाचा.");
            else speakControlNotice("नवीन उतारा जतन केला. प्रश्न विचारा.");
            return true;
        }

        Matcher nextParagraph = Pattern.compile("^(?:please )?(?:(?:read|use|replace with) )?(?:the )?(?:next|new) paragraph(?:\\s+(?:is|says|goes like this))?\\s*[:,-]?\\s*(.*)$", Pattern.CASE_INSENSITIVE).matcher(q);
        Matcher marathiParagraph = Pattern.compile("^(?:कृपया )?(?:(?:वाचा|वापरा|बदला) )?(?:पुढील|पुढचा|नवीन) (?:परिच्छेद|उतारा)(?:\\s+(?:आहे|असा आहे|असा))?\\s*[:,-]?\\s*(.*)$").matcher(q);
        if (nextParagraph.matches() || marathiParagraph.matches()) {
            String body = (marathiParagraph.matches() ? safeGroup(marathiParagraph, 1) : safeGroup(nextParagraph, 1)).trim();
            if (body.isEmpty()) {
                awaitingNextParagraph = true;
                persistSessionState();
                speakControlNotice("कृपया नवीन परिच्छेद आता वाचा.");
            } else {
                activePassage = body;
                awaitingNextParagraph = false;
                persistSessionState();
                Log.i(TAG, "Active paragraph replaced; characters=" + activePassage.length());
                speakControlNotice("नवीन परिच्छेद जतन केला. प्रश्न विचारा.");
            }
            return true;
        }

        Matcher continuation = Pattern.compile("^(?:please )?(?:continue|append) (?:the )?(?:paragraph|passage)(?:\\s+(?:is|with|says))?\\s*[:,-]?\\s*(.*)$", Pattern.CASE_INSENSITIVE).matcher(q);
        Matcher marathiContinuation = Pattern.compile("^(?:कृपया )?(?:उतारा|परिच्छेद) (?:पुढे चालू ठेवा|पुढे वाचा|जोडा)(?:\\s+(?:आहे|असा))?\\s*[:,-]?\\s*(.*)$").matcher(q);
        if (continuation.matches() || marathiContinuation.matches()) {
            String body = (marathiContinuation.matches() ? safeGroup(marathiContinuation, 1) : safeGroup(continuation, 1)).trim();
            if (body.isEmpty()) {
                awaitingNextParagraph = true;
                persistSessionState();
                speakControlNotice("कृपया उताऱ्याचा पुढील भाग वाचा.");
            } else {
                activePassage = (activePassage == null || activePassage.trim().isEmpty()) ? body : activePassage.trim() + " " + body;
                awaitingNextParagraph = false;
                persistSessionState();
                speakControlNotice("उताऱ्याचा पुढील भाग जतन केला. प्रश्न विचारा.");
            }
            return true;
        }

        if (awaitingNextParagraph) {
            activePassage = q;
            awaitingNextParagraph = false;
            persistSessionState();
            Log.i(TAG, "Active passage replaced from explicit next-paragraph input; characters=" + activePassage.length());
            speakControlNotice("नवीन परिच्छेद जतन केला. प्रश्न विचारा.");
            return true;
        }
        return false;
    }

    private String safeGroup(Matcher matcher, int index) {
        try { String value = matcher.group(index); return value == null ? "" : value; }
        catch (Exception ignored) { return ""; }
    }

    private boolean handleClearlyIncompleteInput(String raw) {
        if (raw == null) return false;
        String q = raw.toLowerCase(new Locale("mr", "IN")).trim().replaceAll("[.!?,;:]+$", "").replaceAll("\\s+", " ");
        if (q.isEmpty()) {
            speakControlNotice("कृपया पूर्ण प्रश्न सांगा.");
            return true;
        }
        boolean devanagari = Pattern.compile(".*[\\p{InDevanagari}].*").matcher(q).matches();
        if (!devanagari) {
            if (q.matches("(?:what|who|where|when|why|how|which)(?:\\s+(?:is|are|was|were|do|does|did|can|could|would|will|should|has|have|had))?")) {
                speakControlNotice("कृपया सर्व तपशीलांसह पूर्ण प्रश्न सांगा.");
                return true;
            }
            String[] words = q.split(" ");
            Set<String> complete = new HashSet<>(java.util.Arrays.asList("what happened", "what changed", "who won", "who came", "who helped him", "who helped her", "what did he do"));
            if (words.length <= 2 && !complete.contains(q)) {
                speakControlNotice("कृपया पूर्ण प्रश्न सांगा.");
                return true;
            }
            String last = words[words.length - 1];
            Set<String> dangling = new HashSet<>(java.util.Arrays.asList("because", "and", "or", "but", "if", "that", "who", "whom", "whose", "which", "what", "when", "where", "why", "how", "to", "of", "for", "from", "with", "in", "on", "at", "by", "the", "a", "an", "complete", "fill", "write", "give", "explain", "find"));
            if (dangling.contains(last)) {
                speakControlNotice("कृपया पूर्ण प्रश्न सांगा.");
                return true;
            }
        } else {
            String normalized = q.replaceAll("[\\p{Punct}।॥]+$", "").trim();
            if (normalized.matches("(?:भूगोल|प्रश्न|उत्तर|कारणे|कारण|फरक|स्पष्ट करा|भौगोलिक कारणे|तक्ता पूर्ण करा|आकृतिबंध पूर्ण करा|नकाशात दाखवा|लिहा|सांगा|समजवा|स्पष्ट|पूर्ण करा|दाखवा)")) {
                speakControlNotice("कृपया पूर्ण प्रश्न सांगा.");
                return true;
            }
        }
        return false;
    }

    private Integer parseSentenceNumberCommand(String q) {
        String numberText = null;
        Matcher m = Pattern.compile("^(?:please )?(?:repeat|read|say|replay) (?:the )?(?:sentence )?(?:number )?([a-z0-9]+)$").matcher(q);
        if (m.matches()) numberText = m.group(1);
        if (numberText == null) {
            m = Pattern.compile("^(?:please )?(?:sentence|number|line|no) (?:number )?([a-z0-9]+)$").matcher(q);
            if (m.matches()) numberText = m.group(1);
        }
        if (numberText == null && q.matches("[0-9]{1,2}")) numberText = q;
        if (numberText == null && WORD_NUMBERS.containsKey(q)) numberText = q;

        Matcher marathi = Pattern.compile("^(?:कृपया )?(?:(?:वाक्य|वाक्य क्रमांक|क्रमांक|ओळ|ओळ क्रमांक)\\s+)?(एक|दोन|तीन|चार|पाच|सहा|सात|आठ|नऊ|नव|दहा|अकरा|बारा|तेरा|चौदा|पंधरा|सोळा|सतरा|अठरा|एकोणीस|वीस|पहिला|पहिली|पहिले|पहिलं|दुसरा|दुसरी|दुसरे|दुसरं|तिसरा|तिसरी|तिसरे|तिसरं|चौथा|चौथी|चौथे|पाचवा|पाचवी|पाचवे|सहावा|सहावी|सहावे|सातवा|सातवी|सातवे|आठवा|आठवी|आठवे|नववा|नववी|नववे|दहावा|दहावी|दहावे|[०-९]{1,2}|[0-9]{1,2})(?:\\s+(?:वाक्य(?: पुन्हा| पुन्हा वाचा)?|वाचा|पुन्हा|पुन्हा वाचा|सांगा))?$").matcher(q);
        if (numberText == null && marathi.matches()) {
            String token = marathi.group(1);
            Integer mapped = MARATHI_NUMBERS.get(token);
            if (mapped != null) return mapped;
            try {
                String ascii = token.replace('०','0').replace('१','1').replace('२','2').replace('३','3').replace('४','4').replace('५','5').replace('६','6').replace('७','7').replace('८','8').replace('९','9');
                return Integer.parseInt(ascii);
            } catch (Exception ignored) { return null; }
        }
        if (numberText == null) return null;
        if (numberText.matches("[0-9]{1,2}")) {
            try { return Integer.parseInt(numberText); } catch (NumberFormatException ignored) { return null; }
        }
        return WORD_NUMBERS.get(numberText);
    }

    private static final Map<String, Integer> MARATHI_NUMBERS = createMarathiNumbers();
    private static Map<String, Integer> createMarathiNumbers() {
        Map<String, Integer> map = new HashMap<>();
        String[] basics = {"एक","दोन","तीन","चार","पाच","सहा","सात","आठ","नऊ","दहा","अकरा","बारा","तेरा","चौदा","पंधरा","सोळा","सतरा","अठरा","एकोणीस","वीस"};
        for (int i = 0; i < basics.length; i++) map.put(basics[i], i + 1);
        String[][] ordinals = {
                {"पहिला","पहिली","पहिले","पहिलं"}, {"दुसरा","दुसरी","दुसरे","दुसरं"}, {"तिसरा","तिसरी","तिसरे","तिसरं"},
                {"चौथा","चौथी","चौथे"}, {"पाचवा","पाचवी","पाचवे"}, {"सहावा","सहावी","सहावे"},
                {"सातवा","सातवी","सातवे"}, {"आठवा","आठवी","आठवे"}, {"नववा","नववी","नववे"}, {"दहावा","दहावी","दहावे"}
        };
        for (int i = 0; i < ordinals.length; i++) for (String item : ordinals[i]) map.put(item, i + 1);
        return map;
    }

    private String marathiNumber(int n) {
        String[] names = {"शून्य","एक","दोन","तीन","चार","पाच","सहा","सात","आठ","नऊ","दहा","अकरा","बारा","तेरा","चौदा","पंधरा","सोळा","सतरा","अठरा","एकोणीस","वीस"};
        if (n >= 0 && n < names.length) return names[n];
        return String.valueOf(n);
    }

    private static final Map<String, Integer> WORD_NUMBERS = createWordNumbers();
    private static Map<String, Integer> createWordNumbers() {
        Map<String, Integer> map = new HashMap<>();
        String[] words = {"zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen", "twenty"};
        for (int i = 0; i < words.length; i++) map.put(words[i], i);
        map.put("first", 1); map.put("second", 2); map.put("third", 3); map.put("fourth", 4); map.put("fifth", 5);
        map.put("sixth", 6); map.put("seventh", 7); map.put("eighth", 8); map.put("ninth", 9); map.put("tenth", 10);
        return map;
    }

    private boolean hasAnswer() { return answerSentences != null && !answerSentences.isEmpty() && currentSentenceIndex >= 0; }

    private void processQuestion(String question) {
        if (stopping || isProcessing) return;
        isProcessing = true;
        isSpeaking = false;
        questionCount++;
        updateStatus("प्रश्न क्रमांक " + questionCount + ": उत्तर तयार करत आहे…");
        final String submittedQuestion = question;
        final String selectedModel = model;
        final String selectedKey = apiKey;
        final String passageAtQuestionTime = activePassage;
        if (networkExecutor == null || networkExecutor.isShutdown()) networkExecutor = Executors.newSingleThreadExecutor();
        networkExecutor.execute(() -> {
            try {
                String answer = requestAnswerWithRetry(selectedKey, selectedModel, submittedQuestion, passageAtQuestionTime);
                handler.post(() -> {
                    if (stopping) return;
                    if (answer == null || answer.trim().isEmpty()) playErrorAndResume("उत्तर रिकामे आले. प्रश्न पुन्हा विचारा.");
                    else {
                        applyPassageMarker(answer, submittedQuestion);
                        String visibleAnswer = stripMachineMetadata(answer);
                        if (isPassageAcknowledgement(visibleAnswer)) {
                            // Passage capture/request-for-passage text is not an answer; preserve the old answer queue.
                            speakControlNotice(visibleAnswer.replace('\n', ' ').trim());
                        } else {
                            setAnswerAndSpeak(answer, submittedQuestion);
                        }
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Gemini request failed", e);
                handler.post(() -> { if (!stopping) playErrorAndResume(userFacingError(e)); });
            }
        });
    }

    private String requestAnswerWithRetry(String key, String selectedModel, String question, String passageContext) throws Exception {
        int retryNumber = 0;
        while (true) {
            try { return requestAnswerOnce(key, selectedModel, question, passageContext); }
            catch (HttpApiException e) {
                boolean retryable = e.httpCode == 429 || e.httpCode == 500 || e.httpCode == 502 || e.httpCode == 503 || e.httpCode == 504;
                if (!retryable || retryNumber >= MAX_RETRIES) throw e;
                long delay = 2000L << retryNumber;
                retryNumber++;
                updateStatus("सेवा तात्पुरती उपलब्ध नाही. पुन्हा प्रयत्न " + retryNumber + " / " + MAX_RETRIES + "…");
                try { Thread.sleep(delay); }
                catch (InterruptedException ex) { Thread.currentThread().interrupt(); throw new Exception("Request cancelled during retry.", ex); }
            }
        }
    }

    private String requestAnswerOnce(String key, String selectedModel, String question, String passageContext) throws Exception {
        String safeModel = selectedModel == null ? "" : selectedModel.trim();
        if (!safeModel.matches("[A-Za-z0-9._-]+")) throw new Exception("Invalid Gemini model ID. Use gemini-3.5-flash-lite.");
        HttpURLConnection connection = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + safeModel + ":generateContent");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(90000);
            connection.setDoOutput(true);
            connection.setRequestProperty("x-goog-api-key", key);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            JSONObject payload = new JSONObject();
            JSONObject systemInstruction = new JSONObject();
            JSONArray systemParts = new JSONArray();
            systemParts.put(new JSONObject().put("text", INSTRUCTIONS));
            systemInstruction.put("parts", systemParts);
            payload.put("systemInstruction", systemInstruction);

            String passage = (passageContext == null || passageContext.trim().isEmpty())
                    ? "(अद्याप प्रश्नपत्रिकेतील उतारा दिलेला नाही; प्रश्न उताऱ्यावर अवलंबून असल्यास वापरकर्त्याला उतारा वाचण्यास सांगा.)"
                    : passageContext.substring(0, Math.min(passageContext.length(), 16000));
            boolean geographyContext = shouldAttachGeographyPdf(question);
            String subjectInstruction = geographyContext
                    ? "प्रश्नाचा विषय अचूक ओळख. प्रश्न भूगोलाचा असल्यास निवडलेली भूगोल PDF संदर्भ म्हणून वापर; स्पष्टपणे दुसऱ्या विषयाचा प्रश्न असल्यास त्या विषयाचेच मराठीत उत्तर दे."
                    : "हा प्रश्न भूगोलापेक्षा वेगळ्या विषयाचा दिसतो. प्रश्नाचा खरा विषय ओळखून त्याच विषयाचे मराठीत परीक्षाभिमुख उत्तर दे; भूगोलाच्या PDF किंवा भूगोलाच्या नियमांचा वापर करू नकोस.";
            String userText = "महाराष्ट्र राज्य मंडळ इयत्ता दहावीच्या सराव प्रश्नपत्रिकेतील प्रश्न सोडव. उत्तर फक्त परीक्षेस योग्य, स्पष्ट मराठीत दे.\n"
                    + subjectInstruction + "\n"
                    + "जतन केलेला प्रश्नपत्रिकेतील उतारा (असल्यास):\n--- उतारा सुरू ---\n" + passage + "\n--- उतारा समाप्त ---\n"
                    + "आत्ताच बोललेला मजकूर:\n" + question + "\n"
                    + "हा प्रश्न आहे की उतारा/सूचना, ते ओळख. भूगोलाचा प्रश्न असल्यासच भूगोल PDF चा संदर्भ घे. प्रत्येक वाक्य किंवा प्रत्येक चौकट/मुद्दा स्वतंत्र ओळीवर दे. प्रथम [[VOICE=mr-IN]] आणि [[PASSAGE=...]] metadata दे, त्यानंतर फक्त उत्तर दे.";
            JSONArray parts = new JSONArray();
            if (geographyContext && textbookPdfUri != null && !textbookPdfUri.trim().isEmpty()) {
                String uploadedUri = ensureTextbookPdfUploaded(key);
                if (uploadedUri != null && !uploadedUri.trim().isEmpty()) {
                    parts.put(new JSONObject().put("fileData", new JSONObject()
                            .put("mimeType", "application/pdf")
                            .put("fileUri", uploadedUri)));
                }
            }
            parts.put(new JSONObject().put("text", userText));
            JSONArray contents = new JSONArray();
            contents.put(new JSONObject().put("role", "user").put("parts", parts));
            payload.put("contents", contents);
            JSONObject config = new JSONObject();
            config.put("maxOutputTokens", 2048);
            config.put("temperature", 0.12);
            payload.put("generationConfig", config);

            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(body); }
            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            String responseText = readStream(stream);
            if (code < 200 || code >= 300) throw makeHttpError(code, responseText);
            JSONObject response = new JSONObject(responseText);
            JSONArray candidates = response.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) throw new Exception("Gemini returned no answer. Ask the question again.");
            JSONObject candidate = candidates.optJSONObject(0);
            JSONObject content = candidate == null ? null : candidate.optJSONObject("content");
            JSONArray responseParts = content == null ? null : content.optJSONArray("parts");
            StringBuilder output = new StringBuilder();
            if (responseParts != null) {
                for (int i = 0; i < responseParts.length(); i++) {
                    JSONObject part = responseParts.optJSONObject(i);
                    String text = part == null ? "" : part.optString("text", "").trim();
                    if (!text.isEmpty()) { if (output.length() > 0) output.append('\n'); output.append(text); }
                }
            }
            return output.toString().trim();
        } finally { if (connection != null) connection.disconnect(); }
    }

    private boolean shouldAttachGeographyPdf(String question) {
        String q = question == null ? "" : question.toLowerCase(new Locale("mr", "IN"));
        // Attach the Geography PDF only when the utterance does not clearly name another subject.
        String nonGeography = "गणित|बीजगणित|भूमिती|त्रिकोणमिती|सांख्यिकी|संभाव्यता|विज्ञान|भौतिकशास्त्र|रसायनशास्त्र|जीवशास्त्र|इतिहास|नागरिकशास्त्र|राज्यशास्त्र|अर्थशास्त्र|संगणक|मराठी विषय|हिंदी विषय|संस्कृत विषय|इंग्रजी विषय|मराठी व्याकरण|हिंदी व्याकरण|संस्कृत व्याकरण|इंग्रजी व्याकरण|मराठीचा पाठ|हिंदीचा पाठ|संस्कृतचा पाठ|इंग्रजीचा पाठ|व्याकरण|शब्दार्थ|समानार्थी|विरुद्धार्थी|वाक्प्रचार|संधी|समास|कविता|कवी|काव्य|कथालेखन|निबंध|पत्रलेखन|जाहिरात|बातमी|संवादलेखन|अहवाल|नाट्य|गद्य|पद्य|नाटक|उतारा इंग्रजी|निबंध लिहा|अर्ज लिहा|पत्र लिहा|essay|letter|grammar|poem|poetry|story|dialogue|speech|report|application|synonym|antonym|tenses|adjective|adverb|preposition|pronoun|verb|noun|active voice|passive voice|direct speech|indirect speech|quadratic equation|solve for|solve the equation|algebra|chemistry|physics|biology|history|civics|political science|economics|computer science|english grammar|marathi grammar|hindi grammar|sanskrit grammar";
        return !Pattern.compile(nonGeography).matcher(q).find();
    }

    private String ensureTextbookPdfUploaded(String key) throws Exception {
        if (textbookPdfUri == null || textbookPdfUri.trim().isEmpty()) return "";
        if (textbookPdfUri.equals(uploadedPdfSourceUri) && uploadedPdfUri != null && !uploadedPdfUri.isEmpty()
                && System.currentTimeMillis() - uploadedPdfTimestamp < 42L * 60L * 60L * 1000L) {
            return uploadedPdfUri;
        }
        updateStatus("भूगोलाची PDF Google Gemini कडे सुरक्षित विनंतीसाठी पाठवत आहे…");
        byte[] pdfBytes = readSelectedPdfBytes(textbookPdfUri);
        if (pdfBytes.length == 0) throw new Exception("PDF रिकामी आहे.");
        if (pdfBytes.length > 45 * 1024 * 1024) throw new Exception("PDF खूप मोठी आहे. कृपया 45 MB पेक्षा लहान PDF निवडा.");
        String uploadUrl = beginPdfUpload(key, pdfBytes.length);
        String remoteUri = finishPdfUpload(uploadUrl, pdfBytes);
        if (remoteUri == null || remoteUri.trim().isEmpty()) throw new Exception("PDF अपलोड झाला, पण त्याचा संदर्भ मिळाला नाही.");
        uploadedPdfUri = remoteUri;
        uploadedPdfSourceUri = textbookPdfUri;
        uploadedPdfTimestamp = System.currentTimeMillis();
        persistSessionState();
        updateStatus("भूगोलाची PDF तयार आहे. उत्तर शोधत आहे…");
        return remoteUri;
    }

    private byte[] readSelectedPdfBytes(String uriString) throws Exception {
        ContentResolver resolver = getContentResolver();
        try (InputStream in = resolver.openInputStream(Uri.parse(uriString));
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new Exception("निवडलेली PDF उघडता आली नाही. PDF पुन्हा निवडा.");
            byte[] buffer = new byte[8192];
            int total = 0;
            int count;
            while ((count = in.read(buffer)) != -1) {
                total += count;
                if (total > 45 * 1024 * 1024) throw new Exception("PDF 45 MB पेक्षा मोठी आहे. लहान PDF निवडा.");
                out.write(buffer, 0, count);
            }
            return out.toByteArray();
        }
    }

    private String beginPdfUpload(String key, int byteCount) throws Exception {
        HttpURLConnection connection = null;
        try {
            String encodedKey = URLEncoder.encode(key, "UTF-8");
            URL url = new URL("https://generativelanguage.googleapis.com/upload/v1beta/files?key=" + encodedKey);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(30000);
            connection.setDoOutput(true);
            connection.setRequestProperty("X-Goog-Upload-Protocol", "resumable");
            connection.setRequestProperty("X-Goog-Upload-Command", "start");
            connection.setRequestProperty("X-Goog-Upload-Header-Content-Length", String.valueOf(byteCount));
            connection.setRequestProperty("X-Goog-Upload-Header-Content-Type", "application/pdf");
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] metadata = new JSONObject().put("file", new JSONObject().put("display_name", "SSC_Class_10_Geography_Textbook.pdf"))
                    .toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(metadata.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(metadata); }
            int code = connection.getResponseCode();
            String response = readStream(code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream());
            if (code < 200 || code >= 300) throw makeHttpError(code, response);
            String uploadUrl = connection.getHeaderField("X-Goog-Upload-URL");
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) {
                uploadUrl = connection.getHeaderField("x-goog-upload-url");
            }
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) {
                Map<String, java.util.List<String>> headers = connection.getHeaderFields();
                if (headers != null) for (Map.Entry<String, java.util.List<String>> h : headers.entrySet()) {
                    if (h.getKey() != null && "x-goog-upload-url".equalsIgnoreCase(h.getKey()) && h.getValue() != null && !h.getValue().isEmpty()) {
                        uploadUrl = h.getValue().get(0); break;
                    }
                }
            }
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) throw new Exception("Google Gemini कडून PDF अपलोड लिंक मिळाली नाही.");
            return uploadUrl.trim();
        } finally { if (connection != null) connection.disconnect(); }
    }

    private String finishPdfUpload(String uploadUrl, byte[] pdfBytes) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(uploadUrl).openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(90000);
            connection.setDoOutput(true);
            connection.setRequestProperty("X-Goog-Upload-Offset", "0");
            connection.setRequestProperty("X-Goog-Upload-Command", "upload, finalize");
            connection.setRequestProperty("Content-Type", "application/pdf");
            connection.setFixedLengthStreamingMode(pdfBytes.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(pdfBytes); }
            int code = connection.getResponseCode();
            String response = readStream(code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream());
            if (code < 200 || code >= 300) throw makeHttpError(code, response);
            JSONObject root = new JSONObject(response);
            JSONObject file = root.optJSONObject("file");
            if (file == null) file = root;
            String uri = file.optString("uri", "").trim();
            if (uri.isEmpty()) throw new Exception("Google Gemini ने PDF चा URI दिला नाही.");
            return uri;
        } finally { if (connection != null) connection.disconnect(); }
    }

    private String applyPassageMarker(String response, String submittedQuestion) {
        if (response == null) return "UNCHANGED";
        Matcher matcher = Pattern.compile("(?m)^\\s*\\[\\[PASSAGE=(STORE_CURRENT_INPUT|APPEND_CURRENT_INPUT|CLEAR|UNCHANGED)\\]\\]\\s*$", Pattern.CASE_INSENSITIVE).matcher(response);
        if (!matcher.find()) return "UNCHANGED";
        String value = matcher.group(1) == null ? "UNCHANGED" : matcher.group(1).trim().toUpperCase(Locale.ROOT);
        if ("STORE_CURRENT_INPUT".equals(value)) {
            String incoming = submittedQuestion == null ? "" : submittedQuestion.trim();
            if (activePassage == null || activePassage.trim().isEmpty()) {
                activePassage = incoming;
                persistSessionState();
                Log.i(TAG, "Initial question-paper passage stored; characters=" + activePassage.length());
            } else {
                // An active passage is locked. Explicit replacement is handled locally by handlePassageCommand.
                Log.i(TAG, "Ignored unintended passage replacement because an active passage is already locked.");
                value = "UNCHANGED";
            }
        } else if ("APPEND_CURRENT_INPUT".equals(value)) {
            String addition = submittedQuestion == null ? "" : submittedQuestion.trim();
            String lowerAddition = addition.toLowerCase(Locale.ROOT);
            boolean explicitContinuation = lowerAddition.matches("(?s)^(?:please )?(?:continue|append) (?:the )?passage.*")
                    || lowerAddition.matches("(?s)^next part of (?:the )?passage.*");
            if (explicitContinuation && !addition.isEmpty()) {
                String continuationText = addition.replaceFirst("(?i)^(?:please )?(?:continue|append) (?:the )?passage\\s*[:,-]?\\s*", "")
                        .replaceFirst("(?i)^next part of (?:the )?passage\\s*[:,-]?\\s*", "").trim();
                if (!continuationText.isEmpty()) {
                    activePassage = activePassage == null || activePassage.trim().isEmpty()
                            ? continuationText : activePassage.trim() + " " + continuationText;
                    persistSessionState();
                }
                Log.i(TAG, "Explicit question-paper passage continuation appended; characters=" + (activePassage == null ? 0 : activePassage.length()));
            } else {
                Log.i(TAG, "Ignored unintended passage append because no explicit continuation command was given.");
                value = "UNCHANGED";
            }
        } else if ("CLEAR".equals(value)) {
            activePassage = "";
            persistSessionState();
            Log.i(TAG, "Question-paper passage cleared");
        }
        return value;
    }

    private String stripMachineMetadata(String answer) {
        if (answer == null) return "";
        return answer.replaceAll("(?m)^\\s*\\[\\[(?:VOICE|PASSAGE)=.*?\\]\\]\\s*$", "").trim();
    }

    private boolean isPassageAcknowledgement(String answer) {
        String normalized = answer == null ? "" : answer.trim().replaceAll("\\s+", " ");
        return normalized.matches("(?i)(?:(?:the )?(?:new )?passage (?:has been )?(?:successfully )?(?:saved|stored|updated)(?:[.! ]+.*)?|please read the passage(?: from the question paper)? first)[.! ]*")
                || normalized.contains("उतारा जतन केला")
                || normalized.contains("नवीन उतारा जतन केला")
                || normalized.contains("कृपया प्रश्नपत्रिकेतील उतारा आधी वाचा")
                || (normalized.contains("उतारा") && normalized.contains("वाचा") && normalized.contains("कृपया"));
    }

    private void setAnswerAndSpeak(String rawAnswer, String answeredQuestion) {
        ArrayList<String> parsed = splitAnswerIntoSentences(rawAnswer);
        if (parsed.isEmpty()) { playErrorAndResume("उत्तर रिकामे आले. प्रश्न पुन्हा विचारा."); return; }
        answerSentences = parsed;
        currentSentenceIndex = 0;
        lastAnsweredQuestion = answeredQuestion == null ? "" : answeredQuestion.trim();
        awaitingNextQuestion = false;
        answerGeneration++;
        persistSessionState();
        isProcessing = false;
        isSpeaking = true;
        updateStatus("पहिले वाक्य सांगत आहे. पुढील वाक्यासाठी 'पुढील वाक्य' म्हणा.");
        speakCurrentSentence(answerGeneration);
    }

    private ArrayList<String> splitAnswerIntoSentences(String rawAnswer) {
        ArrayList<String> result = new ArrayList<>();
        if (rawAnswer == null) return result;
        String clean = rawAnswer.replaceAll("(?m)^\\s*\\[\\[(?:VOICE|PASSAGE)=.*?\\]\\]\\s*$", "")
                .replace("```", "").replace("**", "").replace("__", "").replace("*", "").replace("`", "").trim();
        if (clean.isEmpty()) return result;
        String[] lines = clean.split("\\r?\\n");
        Pattern numberedLine = Pattern.compile("^\\s*(?:sentence\\s*)?(\\d{1,2})\\s*[.):-]\\s*(.+?)\\s*$", Pattern.CASE_INSENSITIVE);
        int numberedCount = 0;
        for (String line : lines) if (numberedLine.matcher(line.trim()).matches()) numberedCount++;
        if (numberedCount > 0) {
            for (String original : lines) {
                String line = original.trim();
                if (line.isEmpty()) continue;
                Matcher m = numberedLine.matcher(line);
                if (m.matches()) line = m.group(2).trim();
                else line = line.replaceFirst("^(?:[-•]+|[A-Z][.)])\\s*", "").trim();
                addSentenceFragments(result, line);
            }
        } else {
            for (String original : lines) {
                String line = original.trim().replaceFirst("^(?:[-•]+)\\s*", "").trim();
                if (!line.isEmpty()) addSentenceFragments(result, line);
            }
        }
        return result;
    }

    private void addSentenceFragments(ArrayList<String> target, String line) {
        if (line == null || line.trim().isEmpty()) return;
        String trimmed = line.trim();
        String[] parts = trimmed.split("(?<=[.!?।॥])\\s+");
        if (parts.length == 0) { target.add(trimmed); return; }
        for (String part : parts) {
            String value = part == null ? "" : part.trim();
            if (!value.isEmpty()) target.add(value);
        }
    }

    private void speakCurrentSentence(long generation) {
        if (stopping || generation != answerGeneration) return;
        if (answerSentences == null || currentSentenceIndex < 0 || currentSentenceIndex >= answerSentences.size()) {
            isSpeaking = false;
            startListening();
            return;
        }
        if (tts == null || !ttsReady || !configureMarathiVoice()) {
            isSpeaking = false;
            updateStatus("मराठी आवाज उपलब्ध नाही. आवाज सेटिंग्ज तपासा.");
            handler.postDelayed(this::startListening, 1000L);
            return;
        }
        isSpeaking = true;
        String text = "वाक्य क्रमांक " + marathiNumber(currentSentenceIndex + 1) + ". " + answerSentences.get(currentSentenceIndex);
        String utteranceId = "sentence_" + generation + "_" + currentSentenceIndex;
        updateStatus("वाक्य क्रमांक " + marathiNumber(currentSentenceIndex + 1) + " सांगत आहे…");
        int spoken = tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), utteranceId);
        if (spoken == TextToSpeech.ERROR) {
            isSpeaking = false;
            updateStatus("हे वाक्य बोलता आले नाही. वाक्याचा क्रमांक पुन्हा सांगा.");
            handler.postDelayed(this::startListening, 500L);
        }
    }

    private void speakControlNotice(String message) {
        if (stopping) return;
        if (tts == null || !ttsReady || !configureMarathiVoice()) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 500L);
            return;
        }
        isSpeaking = true;
        String id = "notice_" + answerGeneration + "_" + System.currentTimeMillis();
        updateStatus("सूचना सांगत आहे…");
        int spoken = tts.speak(message, TextToSpeech.QUEUE_FLUSH, new Bundle(), id);
        if (spoken == TextToSpeech.ERROR) { isSpeaking = false; handler.postDelayed(this::startListening, 500L); }
    }

    private void handleUtteranceDone(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("sentence_")) {
            String[] bits = utteranceId.split("_");
            if (bits.length >= 3) {
                try {
                    long generation = Long.parseLong(bits[1]);
                    int sentenceIndex = Integer.parseInt(bits[2]);
                    if (generation != answerGeneration || sentenceIndex != currentSentenceIndex) return;
                } catch (NumberFormatException ignored) { return; }
            }
            isSpeaking = false;
            isProcessing = false;
            updateStatus("वाक्य वाचून झाले. पुढील वाक्य, पुन्हा, किंवा वाक्याचा क्रमांक सांगा.");
            startListening();
            return;
        }
        if (utteranceId.startsWith("notice_") || utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            updateStatus("पुढील सूचना ऐकत आहे…");
            handler.postDelayed(this::startListening, 200L);
        }
    }

    private void handleUtteranceFinishedWithError(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("sentence_") || utteranceId.startsWith("notice_") || utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            updateStatus("वाचन थांबले. पुन्हा ऐकत आहे…");
            handler.postDelayed(this::startListening, 500L);
        }
    }

    private void playErrorAndResume(String message) {
        isProcessing = false;
        isSpeaking = true;
        updateStatus("प्रश्नाचे उत्तर मिळाले नाही. सूचना सांगत आहे.");
        speakControlNotice(errorMessageInMarathi(message));
    }

    private String errorMessageInMarathi(String message) {
        String value = message == null ? "" : message.toLowerCase(Locale.ROOT);
        if (value.contains("503") || value.contains("temporarily busy") || value.contains("unavailable")) return "कृत्रिम बुद्धिमत्ता सेवा सध्या व्यस्त आहे. कृपया थोड्या वेळाने पुन्हा प्रयत्न करा.";
        if (value.contains("429") || value.contains("quota") || value.contains("request limit")) return "वापराची मर्यादा पूर्ण झाली असू शकते. कृपया थोड्या वेळाने पुन्हा प्रयत्न करा.";
        if (value.contains("401") || value.contains("403") || value.contains("api key") || value.contains("authorize")) return "Gemini API key आणि त्याची परवानगी तपासा.";
        if (value.contains("400") || value.contains("model name") || value.contains("model id")) return "Gemini मॉडेलचे नाव आणि सेटिंग्ज तपासा.";
        return "उत्तर मिळाले नाही. इंटरनेट जोडणी आणि API key तपासून प्रश्न पुन्हा विचारा.";
    }

    private HttpApiException makeHttpError(int code, String responseText) {
        String message = "";
        try { JSONObject err = new JSONObject(responseText).optJSONObject("error"); if (err != null) message = err.optString("message", "").trim(); }
        catch (Exception ignored) { }
        return new HttpApiException(code, message);
    }

    private String userFacingError(Exception e) {
        if (e instanceof HttpApiException) {
            HttpApiException apiError = (HttpApiException) e;
            if (apiError.httpCode == 503) return "कृत्रिम बुद्धिमत्ता सेवा सध्या व्यस्त आहे. कृपया थोड्या वेळाने पुन्हा प्रयत्न करा.";
            if (apiError.httpCode == 429) return "विनामूल्य वापराची मर्यादा पूर्ण झाली असू शकते. थोड्या वेळाने पुन्हा प्रयत्न करा.";
            if (apiError.httpCode == 400) return "विनंती स्वीकारली गेली नाही. Gemini मॉडेलचे नाव तपासा.";
            if (apiError.httpCode == 401 || apiError.httpCode == 403) return "API key ला परवानगी मिळाली नाही. key आणि API प्रवेश तपासा.";
            if (apiError.httpCode >= 500) return "AI सेवा सध्या उपलब्ध नाही. थोड्या वेळाने पुन्हा प्रयत्न करा.";
            return "विनंती पूर्ण झाली नाही. कृपया प्रश्न पुन्हा विचारा.";
        }
        String reason = e.getMessage();
        return (reason == null || reason.trim().isEmpty()) ? "उत्तर मिळाले नाही. इंटरनेट जोडणी आणि Gemini API सेटिंग्ज तपासा." : "उत्तर मिळवताना अडचण आली. कृपया पुन्हा प्रयत्न करा.";
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private String abbreviate(String text, int max) { if (text == null) return ""; return text.length() <= max ? text : text.substring(0, max) + "…"; }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getPackageName() + ":GeographyAnswerTeller");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(SESSION_LIMIT_MS + 30000L);
            }
        } catch (Exception e) { Log.w(TAG, "Could not acquire wakelock", e); }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "भूगोल उत्तरसहाय्यक सत्र", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("ऐकणे आणि वाक्यागणिक वाचनाची स्थिती दाखवते; येथे सत्र थांबवता येते.");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String status) {
        Intent stopIntent = new Intent(this, VoiceLoopService.class);
        stopIntent.setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 992, stopIntent, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("भूगोल उत्तरसहाय्यक सुरू आहे")
                .setContentText(status)
                .setStyle(new Notification.BigTextStyle().bigText(status))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "STOP", stopPendingIntent).build());
        return builder.build();
    }

    private void updateStatus(String status) {
        if (stopping || notificationManager == null) return;
        try { notificationManager.notify(NOTIFICATION_ID, buildNotification(status)); }
        catch (Exception e) { Log.w(TAG, "Could not update notification", e); }
    }

    private void stopLoop() {
        if (stopping) { stopSelf(); return; }
        stopping = true;
        started = false;
        answerGeneration++;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) { try { tts.stop(); } catch (Exception ignored) { } try { tts.shutdown(); } catch (Exception ignored) { } tts = null; }
        ttsReady = false;
        if (networkExecutor != null) { networkExecutor.shutdownNow(); networkExecutor = null; }
        if (wakeLock != null && wakeLock.isHeld()) { try { wakeLock.release(); } catch (Exception ignored) { } }
        wakeLock = null;
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override public void onDestroy() { if (!stopping) stopLoop(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }

    private static class HttpApiException extends Exception {
        final int httpCode;
        final String apiMessage;
        HttpApiException(int httpCode, String apiMessage) {
            super("Gemini HTTP " + httpCode + (apiMessage == null || apiMessage.isEmpty() ? "" : ": " + apiMessage));
            this.httpCode = httpCode;
            this.apiMessage = apiMessage == null ? "" : apiMessage;
        }
    }
}
