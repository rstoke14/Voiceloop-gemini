package com.example.voiceloop;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.OpenableColumns;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VoiceLoopService extends Service {
    public static final String ACTION_START = "com.example.voiceloop.START";
    public static final String ACTION_STOP = "com.example.voiceloop.STOP";
    public static final String EXTRA_API_KEY = "api_key";
    public static final String EXTRA_MODEL = "model";
    public static final String EXTRA_LANGUAGE = "language";
    public static final String EXTRA_TEXTBOOK_URI = "textbook_uri";

    private static final String TAG = "MarathiAnswerTeller";
    private static final String CHANNEL_ID = "marathi_answer_teller_session";
    private static final int NOTIFICATION_ID = 2461;
    private static final long SESSION_LIMIT_MS = 6L * 60L * 60L * 1000L;
    private static final long WORD_PAUSE_MS = 4000L;
    private static final int MAX_RETRIES = 3;
    private static final long MAX_PDF_BYTES = 50L * 1024L * 1024L;

    private static final String INSTRUCTIONS =
            "You are an expert Maharashtra State Board SSC Class 10 Marathi Kumarbharati (प्रथम भाषा) examiner, textbook researcher, and exam-answer writer. Your job is to solve spoken Marathi questions from a board-pattern question paper using the selected इयत्ता १० वी मराठी कुमारभारती textbook PDF as the primary source. Read the PDF carefully for exact chapter and poem names, facts, events, characters, poet/author names, themes, vocabulary, and exercise details. Never invent details or claim that the PDF contains something you could not verify. If a requested answer cannot be found or the PDF is absent, give a cautious, academically sound Marathi answer without pretending to quote the book.\n" +
            "\n" +
            "LANGUAGE AND VOICE RULES: This application is STRICTLY MARATHI-ONLY. The final spoken answer must be in clear, natural, grammatically correct standard Maharashtra Marathi in Devanagari, using familiar school-level words and a neutral, easy-to-understand Maharashtra Marathi register. Never answer in Hindi, English, or another language. Do not mix Hindi grammar or Hindi vocabulary into Marathi. Preserve Sanskrit/English text only when the question specifically requires quoting it or the requested exercise is about that text. Preserve textbook Sanskrit/English words only when the question requires them. Do not use Markdown, bullet symbols, hashtags, tables, ASCII diagrams, decorative formatting, or conversational filler. Start directly with the answer. Use natural punctuation suitable for text-to-speech. Any labels that help explain a diagram or sequence must be spoken naturally, for example प्रथम चौकट, दुसरी चौकट, पहिला टप्पा.\n" +
            "\n" +
            "ACTIVE_CHAPTER LOCK: The app provides the current ACTIVE_CHAPTER value in each request. If it is empty, the user must first announce a lesson, poem, or section; reply briefly asking them to name the पाठ/कविता/विभाग. When the user announces a chapter or poem, fuzzy-match the spoken title to the exact title in the selected PDF, update the active chapter, and confirm in concise Marathi: ठीक आहे, [पाठाचे नाव] उघडला आहे. प्रश्न विचारा. For every later question, consult ONLY that active chapter/poem in the PDF for chapter-specific facts until the user announces another chapter or explicitly switches to भाषाभ्यास/व्याकरण or उपयोजित लेखन. Do not silently change the active chapter because a question mentions another name. If the title has a minor speech-to-text error, infer the intended textbook title. If two titles remain genuinely ambiguous, ask one brief clarification. For विभाग-switch instructions, set the active chapter to भाषाभ्यास: व्याकरण, or उपयोजित लेखन as appropriate. Never read out or expose the internal ACTIVE_CHAPTER metadata.\n" +
            "\n" +
            "ANSWER METHODS AND LENGTH:\n" +
            "For आकृतिबंध, जाळे, चौकटी or a web diagram, identify the central phrase and chapter-relevant points, exclude boxes the user says are already filled, and say exactly the missing number of answers using spoken placement labels such as पहिली चौकट: ... दुसरी चौकट: ...\n" +
            "For ओघतक्ता or घटनाक्रम, verify the sequence from the active chapter and speak each step in order, using पहिला टप्पा, दुसरा टप्पा, तिसरा टप्पा.\n" +
            "For one-sentence answers, factual questions, causes, correlations, and tables, give the exact relevant fact in a complete Marathi sentence. For reasons, give the direct reason without unnecessary background.\n" +
            "For a 3-mark स्वमत, give 6 to 8 clear, flowing, exam-appropriate sentences: first establish the chapter context and central idea, then give a considered personal view and relevant real-life example, then finish with a conclusion. Stay connected to the asked topic and avoid generic filler.\n" +
            "For poem line meanings, explain the literal and implied meaning of the exact lines in about 4 simple sentences. For काव्यसौंदर्य, first identify the poet and poem if verifiable, then explain भावसौंदर्य and विचारसौंदर्य/image/message in a concise spoken passage without visible headings.\n" +
            "For पद्य रसग्रहण, answer only the sub-points requested and use the exact poet/poem/theme and word meanings from the PDF.\n" +
            "For स्थूलवाचन, answer a brief note or analytical question in about 5 to 6 relevant sentences.\n" +
            "For grammar and language study, answer with exact correctness: for समास give विग्रह first, then the समास type; for वाक्प्रचार state the meaning followed by a meaningful sentence; for synonyms, antonyms, spelling, punctuation, word formation, and sentence correction, give the requested answer accurately. When asked about spelling, describe the relevant मात्रा, वेलांटी, उकार, अनुस्वार, or रफार verbally and simply.\n" +
            "For उपयोजित लेखन, produce the complete requested composition in clean spoken Marathi. पत्रलेखन: dictate दिनांक, प्रति, विषय, संबोधन, two clear body paragraphs, and appropriate closing/name. जाहिरात: include a catchy phrase, key features, offer if supplied, and contact details only if supplied; never invent phone numbers. बातमी: provide a headline, date/place only if given or reliably inferable from the prompt, and a concise past-tense report. कथालेखन: create a coherent story using the given points and end with a fitting तात्पर्य. निबंध: write an organized, age-appropriate, exam-scoring essay with relevant examples and a conclusion. Do not invent personal details, dates, prices, or contact information.\n" +
            "\n" +
            "EXAM DISCIPLINE: Answer only the requested subquestion and preserve the spoken question number. Use length suited to marks and the user's specific instructions. Avoid unsupported claims. For a 1-mark answer, be brief; for a 2-mark answer, usually one or two complete sentences; for a 3-mark explanation, follow the specific method above. When the user says next/continue, continue from the next not-yet-spoken sentence/point instead of repeating what was already given. If speech-to-text slightly mishears a word, use fuzzy matching with the active chapter context; do not ask the user to repeat unless the question is genuinely unintelligible.\n" +
            "\n" +
            "MACHINE OUTPUT FORMAT (mandatory): Output exactly three lines. Line 1 must be [[VOICE=mr-IN]]. Line 2 must be [[CHAPTER=UNCHANGED]] if the active chapter stays the same, or [[CHAPTER=exact chapter/section title]] only when the user has announced a new chapter/poem or explicitly switched sections. Use [[CHAPTER=NONE]] only if the user explicitly asks to clear the chapter lock. Line 3 onward contains only the final spoken Marathi answer. The app removes both markers before speaking. Do not include any other metadata, reasoning, or sources.";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService networkExecutor;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;
    private String apiKey;
    private String model = "gemini-3.5-flash-lite";
    private String recognitionLanguageTag = "mr-IN";
    private String textbookUriString;
    private String cachedGeminiTextbookUri;
    private String activeChapter = "";
    private String[] answerWords = new String[0];
    private int wordIndex = 0;
    private int questionCount = 0;
    private long answerGeneration = 0L;
    private boolean ttsReady = false;
    private boolean isProcessing = false;
    private boolean isSpeaking = false;
    private boolean stopping = false;
    private boolean started = false;
    private NotificationManager notificationManager;

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();
        networkExecutor = Executors.newSingleThreadExecutor();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopLoop();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        apiKey = intent.getStringExtra(EXTRA_API_KEY);
        model = intent.getStringExtra(EXTRA_MODEL);
        // This app is Marathi-only: never accept another recognition language from the UI or intent.
        recognitionLanguageTag = "mr-IN";
        textbookUriString = intent.getStringExtra(EXTRA_TEXTBOOK_URI);
        if (apiKey == null || apiKey.trim().isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (model == null || model.trim().isEmpty()) model = "gemini-3.5-flash-lite";

        started = true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                        | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
                startForeground(NOTIFICATION_ID, buildNotification("Marathi Answer Teller सुरू होत आहे…"), types);
            } else {
                startForeground(NOTIFICATION_ID, buildNotification("Marathi Answer Teller सुरू होत आहे…"));
            }
        } catch (SecurityException | IllegalArgumentException ex) {
            Log.e(TAG, "Could not start foreground service", ex);
            stopLoop();
            return START_NOT_STICKY;
        }

        acquireWakeLock();
        handler.postDelayed(this::stopLoop, SESSION_LIMIT_MS);
        initialiseTts();
        updateStatus("मराठी आवाज आणि speech recognition तयार करत आहे…");
        return START_NOT_STICKY;
    }

    private void initialiseTts() {
        tts = new TextToSpeech(getApplicationContext(), status -> handler.post(() -> {
            if (stopping) return;
            if (status != TextToSpeech.SUCCESS || tts == null) {
                updateStatus("Text-to-speech could not start. Check Android text-to-speech settings.");
                handler.postDelayed(this::initialiseTts, 3000L);
                return;
            }
            tts.setSpeechRate(0.72f);
            tts.setPitch(0.98f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }
                @Override public void onDone(String utteranceId) {
                    handler.post(() -> handleUtteranceDone(utteranceId));
                }
                @Override public void onError(String utteranceId) {
                    handler.post(() -> handleUtteranceFinishedWithError(utteranceId));
                }
                @Override public void onError(String utteranceId, int errorCode) {
                    handler.post(() -> handleUtteranceFinishedWithError(utteranceId));
                }
            });
            // Only proceed if the selected TTS engine actually supports Marathi (India).
            // Never silently fall back to Hindi or English, because that mispronounces Marathi.
            boolean marathiVoiceReady = configureMarathiVoice();
            ttsReady = marathiVoiceReady;
            if (marathiVoiceReady) {
                updateStatus("मराठी आवाज तयार आहे. पहिला प्रश्न ऐकत आहे…");
                startListening();
            } else {
                updateStatus("मराठी आवाज उपलब्ध नाही. Text-to-speech सेटिंग्जमध्ये मराठी voice data स्थापित करा.");
            }
        }));
    }

    private boolean configureMarathiVoice() {
        if (tts == null) return false;
        // Hard-lock the output locale. A requested tag can never switch the voice to another language.
        Locale locale = Locale.forLanguageTag("mr-IN");
        int result;
        try {
            result = tts.setLanguage(locale);
        } catch (Exception e) {
            Log.w(TAG, "Marathi TTS locale could not be selected", e);
            return false;
        }
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED
                || result == TextToSpeech.ERROR) {
            Log.w(TAG, "The active TTS engine does not have Marathi (India) voice data. result=" + result);
            return false;
        }

        // Prefer the best-quality installed Marathi (India) voice. Never choose Hindi or English.
        try {
            Set<Voice> voices = tts.getVoices();
            Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            if (voices != null) {
                for (Voice voice : voices) {
                    Locale voiceLocale = voice.getLocale();
                    if (voiceLocale == null
                            || !"mr".equalsIgnoreCase(voiceLocale.getLanguage())
                            || (voiceLocale.getCountry() != null && !voiceLocale.getCountry().isEmpty()
                                && !"IN".equalsIgnoreCase(voiceLocale.getCountry()))) {
                        continue;
                    }
                    int score = voice.getQuality() * 10;
                    // Network voices are often more natural, so prefer them when quality is comparable.
                    if (voice.isNetworkConnectionRequired()) score += 3;
                    if (score > bestScore) {
                        bestScore = score;
                        best = voice;
                    }
                }
            }
            if (best != null) {
                int voiceResult = tts.setVoice(best);
                if (voiceResult == TextToSpeech.ERROR) {
                    Log.w(TAG, "Could not activate the selected Marathi voice; keeping the mr-IN locale voice");
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not select a specific Marathi TTS voice", e);
            // setLanguage(mr-IN) already succeeded; never switch to a different language.
        }
        tts.setSpeechRate(0.80f);
        tts.setPitch(1.0f);
        return true;
    }

    private void startListening() {
        if (stopping || !started || isProcessing || isSpeaking) return;
        if (!ttsReady) {
            handler.postDelayed(this::startListening, 500L);
            return;
        }
        destroyRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Speech recognition unavailable. Enable an Android speech service; retrying…");
            handler.postDelayed(this::startListening, 5000L);
            return;
        }
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { updateStatus("प्रश्न " + (questionCount + 1) + " ऐकत आहे…"); }
                @Override public void onBeginningOfSpeech() { updateStatus("तुमचा प्रश्न ऐकत आहे…"); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { updateStatus("प्रश्न ओळखत आहे…"); }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null
                            : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String question = (matches == null || matches.isEmpty()) ? "" : matches.get(0).trim();
                    destroyRecognizer();
                    if (question.isEmpty()) {
                        handler.postDelayed(VoiceLoopService.this::startListening, 700L);
                    } else {
                        processQuestion(question);
                    }
                }

                @Override
                public void onError(int error) {
                    destroyRecognizer();
                    if (stopping || isProcessing || isSpeaking) return;
                    long retryDelay = (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) ? 1800L : 1000L;
                    updateStatus("Speech recognition reset; listening again…");
                    handler.postDelayed(VoiceLoopService.this::startListening, retryDelay);
                }
            });

            Intent speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "mr-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "mr-IN");
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            recognizer.startListening(speechIntent);
        } catch (Exception e) {
            Log.e(TAG, "Could not start speech recognition", e);
            destroyRecognizer();
            updateStatus("Could not start listening; retrying…");
            handler.postDelayed(this::startListening, 1800L);
        }
    }

    private void processQuestion(String question) {
        if (stopping || isProcessing) return;
        isProcessing = true;
        isSpeaking = false;
        questionCount++;
        updateStatus("प्रश्न " + questionCount + ": पाठ्यपुस्तक तपासत आहे…");
        final String submittedQuestion = question;
        final String selectedModel = model;
        final String selectedKey = apiKey;
        final String chapterAtQuestionTime = activeChapter;
        if (networkExecutor == null || networkExecutor.isShutdown()) networkExecutor = Executors.newSingleThreadExecutor();
        networkExecutor.execute(() -> {
            try {
                String answer = requestAnswerWithRetry(selectedKey, selectedModel, submittedQuestion, chapterAtQuestionTime);
                handler.post(() -> {
                    if (stopping) return;
                    if (answer == null || answer.trim().isEmpty()) {
                        playErrorAndResume("Gemini returned an empty answer. Please ask that question again.");
                    } else {
                        applyChapterMarker(answer);
                        speakAnswerWordByWord(answer);
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "Gemini request failed", e);
                handler.post(() -> {
                    if (stopping) return;
                    String reason = userFacingError(e);
                    updateStatus("Request failed: " + abbreviate(reason, 150));
                    playErrorAndResume(reason);
                });
            }
        });
    }

    private String requestAnswerWithRetry(String key, String selectedModel, String question, String chapterContext) throws Exception {
        int retryNumber = 0;
        while (true) {
            try {
                return requestAnswerOnce(key, selectedModel, question, chapterContext);
            } catch (HttpApiException e) {
                boolean retryable = e.httpCode == 429 || e.httpCode == 500 || e.httpCode == 502
                        || e.httpCode == 503 || e.httpCode == 504;
                if (!retryable || retryNumber >= MAX_RETRIES) throw e;
                long delay = 2000L << retryNumber; // 2, 4, then 8 seconds
                retryNumber++;
                updateStatus("Gemini temporarily unavailable (HTTP " + e.httpCode + "). Retry "
                        + retryNumber + " of " + MAX_RETRIES + " in " + (delay / 1000L) + " seconds…");
                try {
                    Thread.sleep(delay);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw new Exception("Request cancelled while waiting to retry.", interrupted);
                }
            }
        }
    }

    private String requestAnswerOnce(String key, String selectedModel, String question, String chapterContext) throws Exception {
        String safeModel = selectedModel == null ? "" : selectedModel.trim();
        if (!safeModel.matches("[A-Za-z0-9._-]+")) {
            throw new Exception("Invalid Gemini model ID. Use gemini-3.5-flash-lite.");
        }
        if (textbookUriString != null && !textbookUriString.trim().isEmpty()
                && (cachedGeminiTextbookUri == null || cachedGeminiTextbookUri.isEmpty())) {
            updateStatus("मराठी पाठ्यपुस्तक Google Gemini कडे अपलोड करत आहे…");
            cachedGeminiTextbookUri = uploadTextbookToGemini(key, textbookUriString);
            updateStatus("पाठ्यपुस्तक तयार. उत्तर बनवत आहे…");
        }

        HttpURLConnection connection = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + safeModel + ":generateContent");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(90000);
            connection.setDoOutput(true);
            connection.setRequestProperty("x-goog-api-key", key);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            JSONObject payload = new JSONObject();
            JSONObject systemInstruction = new JSONObject();
            JSONArray systemParts = new JSONArray();
            systemParts.put(new JSONObject().put("text", INSTRUCTIONS));
            systemInstruction.put("parts", systemParts);
            payload.put("systemInstruction", systemInstruction);

            JSONArray contents = new JSONArray();
            JSONObject userContent = new JSONObject();
            userContent.put("role", "user");
            JSONArray userParts = new JSONArray();
            if (cachedGeminiTextbookUri != null && !cachedGeminiTextbookUri.isEmpty()) {
                JSONObject fileData = new JSONObject();
                fileData.put("mimeType", "application/pdf");
                fileData.put("fileUri", cachedGeminiTextbookUri);
                userParts.put(new JSONObject().put("fileData", fileData));
            }
            String chapterForPrompt = (chapterContext == null || chapterContext.trim().isEmpty()) ? "(none; user must announce a lesson/poem/section first)" : chapterContext;
            userParts.put(new JSONObject().put("text",
                    "Solve this Maharashtra SSC Class 10 Marathi Kumarbharati question according to all system instructions.\nACTIVE_CHAPTER currently stored by the app: " + chapterForPrompt + ".\nQuestion transcript (may contain small speech-to-text mistakes): " + question + "\nRemember: use the selected PDF as the primary reference; Marathi is the spoken answer language; update CHAPTER metadata only for an explicit new chapter/poem or section switch."));
            userContent.put("parts", userParts);
            contents.put(userContent);
            payload.put("contents", contents);

            JSONObject generationConfig = new JSONObject();
            generationConfig.put("maxOutputTokens", 1200);
            generationConfig.put("temperature", 0.15);
            payload.put("generationConfig", generationConfig);

            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(body.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(body); }

            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
            String responseText = readStream(stream);
            if (code < 200 || code >= 300) throw makeHttpError(code, responseText);

            JSONObject response = new JSONObject(responseText);
            JSONArray candidates = response.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) {
                throw new Exception("Gemini returned no answer. Check the question and try again.");
            }
            JSONObject candidate = candidates.optJSONObject(0);
            JSONObject content = candidate == null ? null : candidate.optJSONObject("content");
            JSONArray parts = content == null ? null : content.optJSONArray("parts");
            StringBuilder output = new StringBuilder();
            if (parts != null) {
                for (int i = 0; i < parts.length(); i++) {
                    JSONObject part = parts.optJSONObject(i);
                    if (part == null) continue;
                    String text = part.optString("text", "").trim();
                    if (!text.isEmpty()) {
                        if (output.length() > 0) output.append('\n');
                        output.append(text);
                    }
                }
            }
            return output.toString().trim();
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String uploadTextbookToGemini(String key, String uriString) throws Exception {
        byte[] pdfBytes = readTextbookPdf(uriString);
        if (pdfBytes.length == 0) throw new Exception("The selected textbook PDF is empty or could not be read.");

        HttpURLConnection startConnection = null;
        String uploadUrl;
        try {
            startConnection = (HttpURLConnection) new URL("https://generativelanguage.googleapis.com/upload/v1beta/files").openConnection();
            startConnection.setRequestMethod("POST");
            startConnection.setConnectTimeout(25000);
            startConnection.setReadTimeout(60000);
            startConnection.setDoOutput(true);
            startConnection.setRequestProperty("x-goog-api-key", key);
            startConnection.setRequestProperty("X-Goog-Upload-Protocol", "resumable");
            startConnection.setRequestProperty("X-Goog-Upload-Command", "start");
            startConnection.setRequestProperty("X-Goog-Upload-Header-Content-Length", String.valueOf(pdfBytes.length));
            startConnection.setRequestProperty("X-Goog-Upload-Header-Content-Type", "application/pdf");
            startConnection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] metadata = new JSONObject().put("file", new JSONObject().put("display_name", "Maharashtra_SSC_Class10_Marathi_Kumarbharati.pdf"))
                    .toString().getBytes(StandardCharsets.UTF_8);
            startConnection.setFixedLengthStreamingMode(metadata.length);
            try (OutputStream out = startConnection.getOutputStream()) { out.write(metadata); }
            int code = startConnection.getResponseCode();
            String response = readStream(code >= 200 && code < 300 ? startConnection.getInputStream() : startConnection.getErrorStream());
            if (code < 200 || code >= 300) throw makeHttpError(code, response);
            uploadUrl = startConnection.getHeaderField("X-Goog-Upload-URL");
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) uploadUrl = startConnection.getHeaderField("x-goog-upload-url");
            if (uploadUrl == null || uploadUrl.trim().isEmpty()) {
                throw new Exception("Gemini did not provide a textbook upload URL. Try without the PDF or choose it again.");
            }
        } finally {
            if (startConnection != null) startConnection.disconnect();
        }

        HttpURLConnection uploadConnection = null;
        try {
            uploadConnection = (HttpURLConnection) new URL(uploadUrl).openConnection();
            uploadConnection.setRequestMethod("POST");
            uploadConnection.setConnectTimeout(30000);
            uploadConnection.setReadTimeout(180000);
            uploadConnection.setDoOutput(true);
            uploadConnection.setRequestProperty("x-goog-api-key", key);
            uploadConnection.setRequestProperty("X-Goog-Upload-Offset", "0");
            uploadConnection.setRequestProperty("X-Goog-Upload-Command", "upload, finalize");
            uploadConnection.setRequestProperty("Content-Type", "application/pdf");
            uploadConnection.setFixedLengthStreamingMode(pdfBytes.length);
            try (OutputStream out = uploadConnection.getOutputStream()) { out.write(pdfBytes); }
            int code = uploadConnection.getResponseCode();
            String responseText = readStream(code >= 200 && code < 300 ? uploadConnection.getInputStream() : uploadConnection.getErrorStream());
            if (code < 200 || code >= 300) throw makeHttpError(code, responseText);
            JSONObject response = new JSONObject(responseText);
            JSONObject file = response.optJSONObject("file");
            String fileUri = file == null ? "" : file.optString("uri", "").trim();
            if (fileUri.isEmpty()) throw new Exception("Gemini uploaded the PDF but did not return its file URI.");
            return fileUri;
        } finally {
            if (uploadConnection != null) uploadConnection.disconnect();
        }
    }

    private byte[] readTextbookPdf(String uriString) throws Exception {
        Uri uri = Uri.parse(uriString);
        try (InputStream input = getContentResolver().openInputStream(uri);
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            if (input == null) throw new Exception("Cannot open the selected textbook PDF. Please choose it again.");
            byte[] buffer = new byte[16384];
            int read;
            long total = 0;
            while ((read = input.read(buffer)) != -1) {
                total += read;
                if (total > MAX_PDF_BYTES) throw new Exception("The textbook PDF is larger than 50 MB. Choose a smaller/compressed PDF.");
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        }
    }

    private HttpApiException makeHttpError(int code, String responseText) {
        String message = "";
        try {
            JSONObject err = new JSONObject(responseText).optJSONObject("error");
            if (err != null) message = err.optString("message", "").trim();
        } catch (Exception ignored) { }
        return new HttpApiException(code, message);
    }

    private String userFacingError(Exception e) {
        if (e instanceof HttpApiException) {
            HttpApiException apiError = (HttpApiException) e;
            if (apiError.httpCode == 503) return "Gemini is temporarily busy or unavailable (HTTP 503) after three retries. Please try again later.";
            if (apiError.httpCode == 429) return "Gemini's free-tier quota or request limit was reached (HTTP 429). Wait before asking again.";
            if (apiError.httpCode == 400) return "Gemini rejected the request (HTTP 400). Check the model name and selected textbook PDF.";
            if (apiError.httpCode == 401 || apiError.httpCode == 403) return "Gemini could not authorize this API key (HTTP " + apiError.httpCode + "). Check the key and its API access.";
            if (apiError.httpCode >= 500) return "Gemini's server is unavailable (HTTP " + apiError.httpCode + ") after retries. Please try again later.";
            return "Gemini request failed with HTTP " + apiError.httpCode + (apiError.apiMessage.isEmpty() ? "." : ". " + abbreviate(apiError.apiMessage, 130));
        }
        String reason = e.getMessage();
        return (reason == null || reason.trim().isEmpty())
                ? "I could not get an answer. Check internet access and your Gemini API settings."
                : abbreviate(reason, 210);
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) out.append(line);
        }
        return out.toString();
    }

    private String abbreviate(String text, int max) {
        if (text == null) return "";
        return text.length() <= max ? text : text.substring(0, max) + "…";
    }

    private void applyChapterMarker(String response) {
        if (response == null) return;
        java.util.regex.Matcher matcher = java.util.regex.Pattern
                .compile("(?m)^\\s*\\[\\[CHAPTER=(.*?)\\]\\]\\s*$")
                .matcher(response);
        if (!matcher.find()) return;
        String value = matcher.group(1) == null ? "" : matcher.group(1).trim();
        if ("UNCHANGED".equalsIgnoreCase(value)) return;
        if ("NONE".equalsIgnoreCase(value)) {
            activeChapter = "";
        } else if (!value.isEmpty()) {
            activeChapter = value;
            Log.i(TAG, "ACTIVE_CHAPTER updated to: " + activeChapter);
        }
    }

    private void speakAnswerWordByWord(String answer) {
        String clean = answer == null ? "" : answer.trim();
        // Strip the internal voice marker regardless of its value; the TTS locale stays mr-IN.
        clean = clean.replaceAll("(?m)^\\s*\\[\\[VOICE=.*?\\]\\]\\s*$", "").trim();
        if (!configureMarathiVoice()) {
            playErrorAndResume("Marathi TTS voice data is not installed");
            return;
        }
        clean = clean.replaceAll("(?m)^\\s*\\[\\[CHAPTER=.*?\\]\\]\\s*$", "");
        clean = clean.replaceAll("(?m)^\\s*#{1,6}\\s*", "")
                .replace("```", "")
                .replace("**", "")
                .replace("__", "")
                .replace("*", "")
                .replace("_", "")
                .replace("`", "")
                .replaceAll("\\s+", " ").trim();
        if (clean.isEmpty()) {
            playErrorAndResume("Gemini returned an empty answer. Please ask again.");
            return;
        }
        answerWords = clean.split(" ");
        wordIndex = 0;
        answerGeneration++;
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Speaking answer to question " + questionCount + " (" + answerWords.length + " words)…");
        speakCurrentWord(answerGeneration);
    }

    private void speakCurrentWord(long generation) {
        if (stopping || generation != answerGeneration) return;
        if (wordIndex >= answerWords.length) {
            isSpeaking = false;
            updateStatus("उत्तर पूर्ण. पुढील प्रश्न ऐकत आहे…");
            startListening();
            return;
        }
        String word = answerWords[wordIndex];
        if (word.trim().isEmpty()) {
            wordIndex++;
            handler.postDelayed(() -> speakCurrentWord(generation), WORD_PAUSE_MS);
            return;
        }
        String utteranceId = "word_" + generation + "_" + wordIndex;
        if (tts == null || !ttsReady) {
            handler.postDelayed(() -> speakCurrentWord(generation), 700L);
            return;
        }
        int result = tts.speak(word, TextToSpeech.QUEUE_FLUSH, new Bundle(), utteranceId);
        if (result == TextToSpeech.ERROR) {
            handler.postDelayed(() -> {
                if (generation != answerGeneration || stopping) return;
                wordIndex++;
                handler.postDelayed(() -> speakCurrentWord(generation), WORD_PAUSE_MS);
            }, 300L);
        }
    }

    private void handleUtteranceDone(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            handler.postDelayed(this::startListening, 1000L);
            return;
        }
        if (!utteranceId.startsWith("word_")) return;
        final long generation = answerGeneration;
        handler.postDelayed(() -> {
            if (stopping || generation != answerGeneration) return;
            wordIndex++;
            speakCurrentWord(generation);
        }, WORD_PAUSE_MS);
    }

    private void handleUtteranceFinishedWithError(String utteranceId) {
        // Treat an individual TTS failure like a completed word so the loop does not get stuck.
        handleUtteranceDone(utteranceId);
    }

    private String errorMessageInMarathi(String message) {
        String value = message == null ? "" : message.toLowerCase(Locale.ROOT);
        if (value.contains("503") || value.contains("temporarily busy") || value.contains("unavailable")) {
            return "सध्या एआय सेवा उपलब्ध नाही. कृपया थोड्या वेळाने पुन्हा प्रश्न विचारा.";
        }
        if (value.contains("429") || value.contains("quota") || value.contains("request limit")) {
            return "विनामूल्य वापराची मर्यादा पूर्ण झाली आहे. थोड्या वेळाने पुन्हा प्रयत्न करा.";
        }
        if (value.contains("401") || value.contains("403") || value.contains("api key") || value.contains("authorize")) {
            return "एपीआय की किंवा तिची परवानगी तपासा आणि पुन्हा प्रयत्न करा.";
        }
        if (value.contains("400") || value.contains("model name") || value.contains("model id")) {
            return "एआय मॉडेलचे नाव आणि निवडलेली पाठ्यपुस्तक पीडीएफ तपासा.";
        }
        if (value.contains("pdf") || value.contains("textbook")) {
            return "पाठ्यपुस्तकाची पीडीएफ उघडता आली नाही. योग्य पीडीएफ पुन्हा निवडा.";
        }
        return "या प्रश्नाचे उत्तर मिळाले नाही. इंटरनेट आणि एपीआय की तपासून प्रश्न पुन्हा विचारा.";
    }

    private void playErrorAndResume(String message) {
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Problem with this question; listening again after the notice.");
        if (tts == null || !ttsReady) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 1500L);
            return;
        }
        // Keep all spoken feedback in Marathi. If Marathi TTS is unavailable, do not use another language.
        if (!configureMarathiVoice()) {
            isSpeaking = false;
            updateStatus("मराठी आवाज उपलब्ध नाही. Settings मध्ये मराठी voice data स्थापित करा.");
            handler.postDelayed(this::startListening, 3000L);
            return;
        }
        Bundle params = new Bundle();
        String id = "error_" + System.currentTimeMillis();
        int result = tts.speak(errorMessageInMarathi(message), TextToSpeech.QUEUE_FLUSH, params, id);
        if (result == TextToSpeech.ERROR) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 1500L);
        }
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null) {
                wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getPackageName() + ":MarathiAnswerTeller");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(SESSION_LIMIT_MS + 30000L);
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not acquire wakelock", e);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "Marathi Answer Teller session", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows listening, textbook upload and speech status, with a Stop action.");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String status) {
        Intent stopIntent = new Intent(this, VoiceLoopService.class);
        stopIntent.setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 991, stopIntent, flags);
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) builder = new Notification.Builder(this, CHANNEL_ID);
        else builder = new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Marathi Answer Teller active")
                .setContentText(status)
                .setStyle(new Notification.BigTextStyle().bigText(status))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "STOP", stopPendingIntent).build());
        return builder.build();
    }

    private void updateStatus(String status) {
        if (stopping || notificationManager == null) return;
        try { notificationManager.notify(NOTIFICATION_ID, buildNotification(status)); }
        catch (Exception e) { Log.w(TAG, "Could not update notification", e); }
    }

    private void stopLoop() {
        if (stopping) { stopSelf(); return; }
        stopping = true;
        started = false;
        answerGeneration++;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) { }
            try { tts.shutdown(); } catch (Exception ignored) { }
            tts = null;
        }
        ttsReady = false;
        if (networkExecutor != null) {
            networkExecutor.shutdownNow();
            networkExecutor = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) { }
        }
        wakeLock = null;
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (!stopping) stopLoop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private static class HttpApiException extends Exception {
        final int httpCode;
        final String apiMessage;
        HttpApiException(int httpCode, String apiMessage) {
            super("Gemini HTTP " + httpCode + (apiMessage == null || apiMessage.isEmpty() ? "" : ": " + apiMessage));
            this.httpCode = httpCode;
            this.apiMessage = apiMessage == null ? "" : apiMessage;
        }
    }
}
