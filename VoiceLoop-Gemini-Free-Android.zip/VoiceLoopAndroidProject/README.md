# VoiceLoop — free-tier Gemini Android prototype

VoiceLoop listens for one spoken question, transcribes it with the speech service installed on Android, sends the text to the Google Gemini Developer API, then reads the answer using Android TextToSpeech **one word at a time**. It waits **4 seconds after each word finishes** before speaking the next word. It only starts listening for the next question after the current answer is finished. The session stops after six hours or when you press Stop.

## Cost

- Android speech recognition and TextToSpeech use Android's installed speech services; online recognition may use mobile data.
- AI answers use the Gemini API. To keep this at no monetary cost, create/use a **Free Tier** project in Google AI Studio, do not enable paid billing, and use a model actually available to that free-tier project. The app defaults to `gemini-3.8-flash`.
- Free access is subject to model availability, quotas, rate limits, and Google's terms; it is not unlimited or guaranteed for 6 hours. Google says free-tier API content may be used to improve its products, so do not submit sensitive or private information.
- GitHub Actions can build from a public repository for free. Avoid adding any API key to GitHub or hard-coding it into the app.

## Get a Gemini API key (phone only)

1. Open `https://aistudio.google.com/apikey` in your Android browser and sign in.
2. Create/select a project that is on the **Free Tier**. Do not click a billing/upgrade button. If it asks to set up paid billing, back out and choose a free-tier project instead.
3. Create and copy an API key. Keep it private; do not paste it into a GitHub file, issue, or screenshot.
4. Once the APK is installed, paste the key into the app's key field. The app only holds the key for the session and does not intentionally save it.

## What the app does / limits

- Languages selectable in the app: English (India), Hindi (India), and Marathi (India).
- Each question is sent as a separate API request; the app does not keep a conversation history.
- This is an Android prototype, not a guarantee of a continuous six-hour session. Android's `SpeechRecognizer` is utterance-based, and the installed speech service, network, battery settings, or Poco background rules can interrupt it.
- Start the session while the app is visible and microphone permission is granted. Android 14 requires a microphone foreground service to start under the correct foreground conditions.
- A wake lock keeps the CPU awake for the session and can drain battery; keep the phone on charge. After testing, set the app's battery setting to Unrestricted/No restrictions if available.
- The API key is sent over HTTPS using the `x-goog-api-key` header. A key entered into a client app is not a secret from a determined device owner; only use this personal APK and never distribute it with your key.

## Build using only your Android phone

This archive contains the Android project. The accompanying workflow file is named `VoiceLoop-Gemini-Free-Build.yml`.

1. On GitHub, create a new **public** repository, for example `voiceloop-free`.
2. Upload this ZIP as a file named `voice-loop-source.zip` to the repository root.
3. In GitHub, use **Add file → Create new file** and enter this path: `.github/workflows/build.yml`.
4. Open the accompanying `VoiceLoop-Gemini-Free-Build.yml`, copy its whole contents, and paste them into `build.yml`. Commit the file.
5. Open the repository's **Actions** tab, select **Build VoiceLoop Android APK (Gemini Free Tier)**, then press **Run workflow**.
6. When the run succeeds, open it and download the `VoiceLoop-Gemini-debug-apk` artifact. Extract it on your phone and install `app-debug.apk`. Android may ask you to allow installation from your browser/file manager.
7. Open VoiceLoop, paste the Gemini key, keep model as `gemini-3.8-flash`, choose the language, tap Start, and grant microphone/notification permissions. Stop using either the notification's Stop action or the app's Stop button.

The project targets Android 14+ behaviour and compiles with Java 17, Android SDK 35, and Gradle 8.9. The build itself is handled by GitHub's cloud runner, so you do not need a PC.
