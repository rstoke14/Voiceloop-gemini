package com.example.voiceloop;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class VoiceLoopService extends Service {
    public static final String ACTION_START = "com.example.voiceloop.START";
    public static final String ACTION_STOP = "com.example.voiceloop.STOP";
    public static final String EXTRA_API_KEY = "api_key";
    public static final String EXTRA_MODEL = "model";
    public static final String EXTRA_LANGUAGE = "language";

    private static final String TAG = "VoiceLoop";
    private static final String CHANNEL_ID = "voiceloop_session";
    private static final int NOTIFICATION_ID = 2461;
    private static final long SESSION_LIMIT_MS = 6L * 60L * 60L * 1000L;
    private static final long WORD_PAUSE_MS = 4000L;
    private static final String INSTRUCTIONS = "You are a voice question-answer assistant. Answer accurately and directly in the same language as the question. For school questions, give a concise, exam-writable answer. Use natural spoken wording. Avoid preambles, markdown formatting, tables, and unnecessary follow-up questions.";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService networkExecutor;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private PowerManager.WakeLock wakeLock;
    private String apiKey;
    private String model = "gemini-3.8-flash";
    private String languageTag = "en-IN";
    private String[] answerWords = new String[0];
    private int wordIndex = 0;
    private int questionCount = 0;
    private long answerGeneration = 0L;
    private boolean ttsReady = false;
    private boolean isProcessing = false;
    private boolean isSpeaking = false;
    private boolean stopping = false;
    private boolean started = false;
    private NotificationManager notificationManager;

    @Override
    public void onCreate() {
        super.onCreate();
        notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        createNotificationChannel();
        networkExecutor = Executors.newSingleThreadExecutor();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopLoop();
            return START_NOT_STICKY;
        }
        if (started) return START_NOT_STICKY;
        if (intent == null || !ACTION_START.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }

        apiKey = intent.getStringExtra(EXTRA_API_KEY);
        model = intent.getStringExtra(EXTRA_MODEL);
        languageTag = intent.getStringExtra(EXTRA_LANGUAGE);
        if (apiKey == null || apiKey.trim().isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (model == null || model.trim().isEmpty()) model = "gemini-3.8-flash";
        if (languageTag == null || languageTag.trim().isEmpty()) languageTag = "en-IN";

        started = true;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                int types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                        | ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK;
                startForeground(NOTIFICATION_ID, buildNotification("Starting session…"), types);
            } else {
                startForeground(NOTIFICATION_ID, buildNotification("Starting session…"));
            }
        } catch (SecurityException | IllegalArgumentException ex) {
            Log.e(TAG, "Could not start foreground service", ex);
            stopLoop();
            return START_NOT_STICKY;
        }

        acquireWakeLock();
        handler.postDelayed(this::stopLoop, SESSION_LIMIT_MS);
        initialiseTts();
        updateStatus("Preparing speech services…");
        return START_NOT_STICKY;
    }

    private void initialiseTts() {
        tts = new TextToSpeech(getApplicationContext(), status -> handler.post(() -> {
            if (stopping) return;
            if (status != TextToSpeech.SUCCESS || tts == null) {
                updateStatus("Text-to-speech could not start. Check Android speech settings.");
                handler.postDelayed(this::initialiseTts, 3000L);
                return;
            }
            Locale locale = Locale.forLanguageTag(languageTag);
            int languageStatus = tts.setLanguage(locale);
            if (languageStatus == TextToSpeech.LANG_MISSING_DATA || languageStatus == TextToSpeech.LANG_NOT_SUPPORTED) {
                updateStatus("Selected TTS voice is unavailable. Install its voice data in Android settings.");
                // Keep the service alive so the user can stop it; try a broadly available fallback.
                tts.setLanguage(Locale.US);
            }
            tts.setSpeechRate(0.92f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String utteranceId) { }

                @Override
                public void onDone(String utteranceId) {
                    handler.post(() -> handleUtteranceDone(utteranceId));
                }

                @Override
                public void onError(String utteranceId) {
                    handler.post(() -> handleUtteranceFinishedWithError(utteranceId));
                }

                @Override
                public void onError(String utteranceId, int errorCode) {
                    handler.post(() -> handleUtteranceFinishedWithError(utteranceId));
                }
            });
            ttsReady = true;
            updateStatus("Listening for question 1…");
            startListening();
        }));
    }

    private void startListening() {
        if (stopping || !started || isProcessing || isSpeaking) return;
        if (!ttsReady) {
            handler.postDelayed(this::startListening, 500L);
            return;
        }
        destroyRecognizer();
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Speech recognition unavailable. Enable an Android speech service; retrying…");
            handler.postDelayed(this::startListening, 5000L);
            return;
        }
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(getApplicationContext());
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { updateStatus("Listening for question " + (questionCount + 1) + "…"); }
                @Override public void onBeginningOfSpeech() { updateStatus("Hearing your question…"); }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { updateStatus("Transcribing question…"); }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }

                @Override
                public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null
                            : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String question = (matches == null || matches.isEmpty()) ? "" : matches.get(0).trim();
                    destroyRecognizer();
                    if (question.isEmpty()) {
                        handler.postDelayed(VoiceLoopService.this::startListening, 700L);
                    } else {
                        processQuestion(question);
                    }
                }

                @Override
                public void onError(int error) {
                    destroyRecognizer();
                    if (stopping || isProcessing || isSpeaking) return;
                    long retryDelay = (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) ? 1800L : 900L;
                    updateStatus("Speech recognition reset; listening again…");
                    handler.postDelayed(VoiceLoopService.this::startListening, retryDelay);
                }
            });

            Intent speechIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag);
            speechIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag);
            speechIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            speechIntent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            recognizer.startListening(speechIntent);
        } catch (Exception e) {
            Log.e(TAG, "Could not start speech recognition", e);
            destroyRecognizer();
            updateStatus("Could not start listening; retrying…");
            handler.postDelayed(this::startListening, 1800L);
        }
    }

    private void processQuestion(String question) {
        if (stopping || isProcessing) return;
        isProcessing = true;
        isSpeaking = false;
        questionCount++;
        updateStatus("Question " + questionCount + ": asking AI…");
        final String submittedQuestion = question;
        final String selectedModel = model;
        final String selectedKey = apiKey;
        if (networkExecutor == null || networkExecutor.isShutdown()) {
            networkExecutor = Executors.newSingleThreadExecutor();
        }
        networkExecutor.execute(() -> {
            try {
                String answer = requestAnswer(selectedKey, selectedModel, submittedQuestion);
                handler.post(() -> {
                    if (stopping) return;
                    if (answer == null || answer.trim().isEmpty()) {
                        playErrorAndResume("The AI returned an empty answer. Please ask again.");
                    } else {
                        speakAnswerWordByWord(answer);
                    }
                });
            } catch (Exception e) {
                Log.e(TAG, "AI request failed", e);
                handler.post(() -> {
                    if (stopping) return;
                    String reason = (e.getMessage() == null || e.getMessage().trim().isEmpty())
                            ? "Check your connection and Gemini API settings." : abbreviate(e.getMessage(), 180);
                    playErrorAndResume("I could not get an answer. " + reason);
                });
            }
        });
    }

    private String requestAnswer(String key, String selectedModel, String question) throws Exception {
        HttpURLConnection connection = null;
        try {
            String safeModel = selectedModel == null ? "" : selectedModel.trim();
            if (!safeModel.matches("[A-Za-z0-9._-]+")) {
                throw new Exception("Invalid Gemini model ID. Use gemini-3.8-flash.");
            }
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/"
                    + safeModel + ":generateContent");
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(20000);
            connection.setReadTimeout(60000);
            connection.setDoOutput(true);
            connection.setRequestProperty("x-goog-api-key", key);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");

            JSONObject payload = new JSONObject();
            JSONObject systemInstruction = new JSONObject();
            JSONArray systemParts = new JSONArray();
            systemParts.put(new JSONObject().put("text", INSTRUCTIONS));
            systemInstruction.put("parts", systemParts);
            payload.put("systemInstruction", systemInstruction);

            JSONArray contents = new JSONArray();
            JSONObject userContent = new JSONObject();
            userContent.put("role", "user");
            JSONArray userParts = new JSONArray();
            userParts.put(new JSONObject().put("text", question));
            userContent.put("parts", userParts);
            contents.put(userContent);
            payload.put("contents", contents);

            JSONObject generationConfig = new JSONObject();
            generationConfig.put("maxOutputTokens", 180);
            generationConfig.put("temperature", 0.2);
            payload.put("generationConfig", generationConfig);

            byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream out = connection.getOutputStream()) {
                out.write(body);
            }

            int code = connection.getResponseCode();
            InputStream stream = code >= 200 && code < 300
                    ? connection.getInputStream() : connection.getErrorStream();
            String responseText = readStream(stream);
            if (code < 200 || code >= 300) {
                String detail = "Gemini API error HTTP " + code + ".";
                try {
                    JSONObject err = new JSONObject(responseText).optJSONObject("error");
                    if (err != null) {
                        String msg = err.optString("message", "").trim();
                        if (!msg.isEmpty()) detail += " " + abbreviate(msg, 180);
                    }
                } catch (Exception ignored) { }
                throw new Exception(detail);
            }

            JSONObject response = new JSONObject(responseText);
            JSONArray candidates = response.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0) {
                throw new Exception("Gemini returned no answer. Try asking again.");
            }
            JSONObject candidate = candidates.optJSONObject(0);
            JSONObject content = candidate == null ? null : candidate.optJSONObject("content");
            JSONArray parts = content == null ? null : content.optJSONArray("parts");
            StringBuilder output = new StringBuilder();
            if (parts != null) {
                for (int i = 0; i < parts.length(); i++) {
                    JSONObject part = parts.optJSONObject(i);
                    if (part == null) continue;
                    String text = part.optString("text", "").trim();
                    if (!text.isEmpty()) {
                        if (output.length() > 0) output.append(' ');
                        output.append(text);
                    }
                }
            }
            return output.toString().trim();
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String readStream(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line);
            }
        }
        return out.toString();
    }

    private String abbreviate(String text, int max) {
        if (text == null) return "";
        return text.length() <= max ? text : text.substring(0, max) + "…";
    }

    private void speakAnswerWordByWord(String answer) {
        String clean = answer.replaceAll("(?m)^\\s*#{1,6}\\s*", "")
                .replace("```", "")
                .replace("**", "")
                .replace("__", "")
                .replace("*", "")
                .replace("_", "")
                .replace("`", "")
                .replaceAll("\\s+", " ").trim();
        if (clean.isEmpty()) {
            playErrorAndResume("The AI returned an empty answer. Please ask again.");
            return;
        }
        answerWords = clean.split(" ");
        wordIndex = 0;
        answerGeneration++;
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Speaking answer to question " + questionCount + " (" + answerWords.length + " words)…");
        speakCurrentWord(answerGeneration);
    }

    private void speakCurrentWord(long generation) {
        if (stopping || generation != answerGeneration) return;
        if (wordIndex >= answerWords.length) {
            isSpeaking = false;
            updateStatus("Answer finished. Listening for question " + (questionCount + 1) + "…");
            startListening();
            return;
        }
        String word = answerWords[wordIndex];
        if (word.trim().isEmpty()) {
            wordIndex++;
            handler.postDelayed(() -> speakCurrentWord(generation), WORD_PAUSE_MS);
            return;
        }
        String utteranceId = "word_" + generation + "_" + wordIndex;
        if (tts == null || !ttsReady) {
            handler.postDelayed(() -> speakCurrentWord(generation), 700L);
            return;
        }
        int result = tts.speak(word, TextToSpeech.QUEUE_FLUSH, new Bundle(), utteranceId);
        if (result == TextToSpeech.ERROR) {
            handler.postDelayed(() -> {
                if (generation != answerGeneration || stopping) return;
                wordIndex++;
                handler.postDelayed(() -> speakCurrentWord(generation), WORD_PAUSE_MS);
            }, 300L);
        }
    }

    private void handleUtteranceDone(String utteranceId) {
        if (stopping || utteranceId == null) return;
        if (utteranceId.startsWith("error_")) {
            isSpeaking = false;
            isProcessing = false;
            handler.postDelayed(this::startListening, 900L);
            return;
        }
        if (!utteranceId.startsWith("word_")) return;
        final long generation = answerGeneration;
        handler.postDelayed(() -> {
            if (stopping || generation != answerGeneration) return;
            wordIndex++;
            speakCurrentWord(generation);
        }, WORD_PAUSE_MS);
    }

    private void handleUtteranceFinishedWithError(String utteranceId) {
        // Treat an individual TTS failure like a completed word so the loop does not get stuck.
        handleUtteranceDone(utteranceId);
    }

    private void playErrorAndResume(String message) {
        isProcessing = false;
        isSpeaking = true;
        updateStatus("Problem with this question; will listen again after the notice.");
        if (tts == null || !ttsReady) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 1500L);
            return;
        }
        Bundle params = new Bundle();
        String id = "error_" + System.currentTimeMillis();
        int result = tts.speak(message, TextToSpeech.QUEUE_FLUSH, params, id);
        if (result == TextToSpeech.ERROR) {
            isSpeaking = false;
            handler.postDelayed(this::startListening, 1500L);
        }
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Exception ignored) { }
            try { recognizer.destroy(); } catch (Exception ignored) { }
            recognizer = null;
        }
    }

    private void acquireWakeLock() {
        try {
            PowerManager powerManager = (PowerManager) getSystemService(POWER_SERVICE);
            if (powerManager != null) {
                wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                        getPackageName() + ":VoiceLoopSession");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(SESSION_LIMIT_MS + 30000L);
            }
        } catch (Exception e) {
            Log.w(TAG, "Could not acquire wakelock", e);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                    "VoiceLoop session", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows VoiceLoop listening and playback status, with a Stop action.");
            notificationManager.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String status) {
        Intent stopIntent = new Intent(this, VoiceLoopService.class);
        stopIntent.setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 991, stopIntent, flags);
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder = new Notification.Builder(this, CHANNEL_ID);
        } else {
            builder = new Notification.Builder(this);
        }
        builder.setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("VoiceLoop session active")
                .setContentText(status)
                .setStyle(new Notification.BigTextStyle().bigText(status))
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "STOP", stopPendingIntent).build());
        return builder.build();
    }

    private void updateStatus(String status) {
        if (stopping || notificationManager == null) return;
        try {
            notificationManager.notify(NOTIFICATION_ID, buildNotification(status));
        } catch (Exception e) {
            Log.w(TAG, "Could not update notification", e);
        }
    }

    private void stopLoop() {
        if (stopping) {
            stopSelf();
            return;
        }
        stopping = true;
        started = false;
        answerGeneration++;
        handler.removeCallbacksAndMessages(null);
        destroyRecognizer();
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) { }
            try { tts.shutdown(); } catch (Exception ignored) { }
            tts = null;
        }
        ttsReady = false;
        if (networkExecutor != null) {
            networkExecutor.shutdownNow();
            networkExecutor = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Exception ignored) { }
        }
        wakeLock = null;
        try { stopForeground(STOP_FOREGROUND_REMOVE); } catch (Exception ignored) { }
        stopSelf();
    }

    @Override
    public void onDestroy() {
        if (!stopping) stopLoop();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
